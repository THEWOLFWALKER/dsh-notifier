# Source Map

## Original reports

- `original-reports/dsh-notifier-dev-postfix-review-2026-10-03.md` — exact 201 current issue/risks table and sections A–J.
- `original-reports/dsh-notifier-dev-recheck-and-review-2026-10-03.md` — previous 61 recheck, DSH-F01–F16, cross-cutting review and evidence references.

## Parsed inventories

- `inventories/current-201-issues.json`
- `inventories/previous-61-recheck.json`
- `inventories/deep-findings-F01-F16.json`
- `inventories/assistant-independent-findings.json`

## Synthesis

- `analysis/MASTER_SYNTHESIS.md`
- `analysis/ASSISTANT_INDEPENDENT_REVIEW.md`
- `analysis/PLANNING_REQUIREMENTS.md`
- `analysis/RECOMMENDED_PLANNING_WORKSTREAMS.md`
- `handoff/NEXT_MODEL_HANDOFF.md`
