# dsh-notifier v0.15 — Review Complete Handoff

Review baseline: `dev@2542a3107e7d3795e6ba5b294a7a5b82052c3431`.

This ZIP is for the **next planning model**. It is not an implementation taskpack and not a release package.

## No-omission design

- Both uploaded reports are preserved verbatim under `original-reports/`.
- The exact 201-row current issue table is parsed into `inventories/current-201-issues.json`.
- The previous 61-item recheck is parsed into `inventories/previous-61-recheck.json`.
- DSH-F01 through DSH-F16 are preserved separately.
- This assistant's direct post-Stage-4 findings are `MY-R01` through `MY-R16`.
- `FULL_CONTEXT.md` concatenates the generated synthesis and both raw reports into one readable file.

Do **not** add 201 + 61 + 16 + 16 as a unique-issue count. Many are rechecks or overlaps. Preserve IDs while deduplicating by root cause.

The next model should plan first, not code first.
