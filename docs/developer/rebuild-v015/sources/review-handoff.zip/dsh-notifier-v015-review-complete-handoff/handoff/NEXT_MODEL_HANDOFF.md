# Handoff to the Next Planning Model

You are taking over architecture/planning for `THEWOLFWALKER/dsh-notifier`.

Current review baseline: `dev@2542a3107e7d3795e6ba5b294a7a5b82052c3431`.

Previous implementation stages are complete, but post-RC adversarial review shows the project is **not release-ready yet**.

You are **not being asked to code yet**.

## Read order

1. `00_START_HERE.md`
2. `analysis/MASTER_SYNTHESIS.md`
3. `analysis/ASSISTANT_INDEPENDENT_REVIEW.md`
4. `analysis/PLANNING_REQUIREMENTS.md`
5. `analysis/RECOMMENDED_PLANNING_WORKSTREAMS.md`
6. `inventories/current-201-issues.json`
7. `inventories/previous-61-recheck.json`
8. `inventories/deep-findings-F01-F16.json`
9. both files under `original-reports/`

Do not skip the original reports. They are preserved verbatim so no source detail is lost.

## Your job

Produce the next complete implementation plan, not a shallow checklist.

You must:
- deduplicate without losing source IDs;
- find common root causes;
- distinguish actual bugs from product mismatch, architecture debt, evidence gaps and stale documentation;
- prioritize by user/data/security impact;
- design difficult interfaces/state transitions before delegation;
- specify migrations and backward-compatibility behavior;
- specify race/failure tests;
- state what old code must be deleted;
- combine work into a small number of coherent stages for a fresh implementation Agent.

The plan must be detailed enough that the implementation Agent does not need to re-research the architecture or external contracts.

## Facts that must not be missed

- Telegram notification config can implicitly activate Telegram inbound/private transport.
- Closing private chat is not guaranteed to immediately revoke live admission.
- Interaction terminate/markUncertain still have stale RMW windows.
- dsh-im v1 `account.fingerprint` is misread; local mock duplicates the wrong shape.
- Cloudflare YAML-only token/reference and job failure-state recovery need redesign.
- Account-aware migration is incomplete in several state domains.
- Directed public notifier results/types/fakes are not fully aligned with accepted/confirmed/unknown semantics.
- Native multi-owner read/write behavior conflicts.
- “稍后处理” currently means terminal reject/decline.
- Unknown non-QQ chatType is fail-open as private.
- The source master report has 201 current issues/risks; do not plan from summary alone.

## Product constraints

- dsh-notifier is the project; dsh-im is reference/compat input.
- private-only / no group support.
- Native-first.
- Recovery Console only.
- user-facing UI/docs stay simple and non-technical.
- no Big-Bang rewrite.
- Store async rewrite is not a goal by itself.
- no fake verification.

## Future implementation rules

When the user later hands your plan to an implementation Agent:
- only `dev`
- Author/Committer `THEWOLFWALKER`
- no force push
- no main
- no tags/releases/npm publish until final approval.

End your output with a proposed taskpack structure for the fresh implementation Agent.
