# Master Synthesis

## Source hierarchy

This file is a planning entry point, not a replacement for raw evidence.

- Exact 201 current issues: `original-reports/dsh-notifier-dev-postfix-review-2026-10-03.md`
- Previous 61-item recheck + F01–F16: `original-reports/dsh-notifier-dev-recheck-and-review-2026-10-03.md`
- Parsed exact source rows: `inventories/current-201-issues.json`
- Direct independent findings: `inventories/assistant-independent-findings.json`

Source master issue table records **201** current issues/risks: P1=69, P2=130, P3=2.

Status distribution:
- 残留: 138
- 新发现: 51
- 证据缺口: 10
- 文档漂移: 2

Section distribution:
- A. 产品边界与 Native v2: 30
- B. Control Core / 私聊安全边界: 21
- C. 路由 / Conversation / 当前任务: 16
- D. 通知路由 / Runtime / Health: 25
- E. state.json / 持久化 / 并发: 23
- F. Cloudflare / 自动部署 / Tunnel: 24
- G. Provider 层残留与真机证据: 23
- H. Secondary Surface / dsh-im Bridge: 9
- I. Recovery Console / Admin Server: 5
- J. CI / 发布门禁 / 文档: 25

## High-confidence release blockers / planning anchors

### 1. Product capability boundary

- `MY-R01`: Telegram outbound notification credentials can implicitly start Telegram inbound/private transport.
- `MY-R05`: closing private chat changes persisted desired state but does not guarantee immediate live admission revocation.
- `MY-R12` / F13 / #31–#32: unknown non-QQ chat type is not fail-closed.
- Source #1: positive group-support paths remain while the user product rule is private-only/no group support.

### 2. Interaction state integrity

- `MY-R03/R04` / A03: terminate and markUncertain still have stale read→write windows.
- `MY-R06`: “稍后处理” is actually terminal reject/decline.
- `MY-R07` / A04: stale import guard does not equally protect destructive secret clear.

### 3. Account / identity isolation

- `MY-R08` / F06 / #16/#29: multi-owner read/write contradiction.
- E07–E11, F08/F09 and source routing/control rows show account-aware migration is incomplete across pending keys, owner fallback, `/log`, dedup and throttles.
- Missing accountId still falls back to `default` in some paths rather than failing closed.

### 4. External contract correctness

- `MY-R02` / F01/F02: real dsh-im v1 returns `account.fingerprint`; notifier and its mock read the wrong flat field.
- dsh-im checked target digest and failure semantics must match upstream exactly, not approximately.
- Host/dsh-im compatibility documentation and freshness gates are stale in parts of the repo.

### 5. Public notifier API semantics

- `MY-R09` / E03: directed public push can collapse unknown/uncertain into legacy failure semantics.
- `MY-R10` / E01/E02/E04/E05: runtime, TypeScript and testing fake disagree.
- `MY-R11`: public sent-event evidence should be re-audited so accepted/confirmed/unknown is not lost.

### 6. Cloudflare state machine

- `MY-R15` / F03: YAML-only Telegram token can be cut off by its own secretReference.
- `MY-R16` / F04/F05: failed vs recovery-required is not actually separated; permanent failures can re-enter recovery.
- Source #116–#139 adds link/unbind asymmetry, apply-state ordering, stale health, startup recovery side effects, cancel failure, retained cloud resources and tunnel lifecycle issues.

## Cross-cutting root-cause patterns

1. **Fail-open empty-state projection** — exceptions become `[]`, `false`, `default`, `private` or “not configured”. Unknown/unavailable must remain first-class.
2. **Account-aware migration stopped halfway** — one canonical `(channel, accountId, userId)` principal model has not reached every state domain.
3. **Desired/live/evidence conflation** — configured, admitted/live, provider accepted and confirmed are still mixed in several paths.
4. **Tests can duplicate local assumptions** — dsh-im fingerprint is the clearest example.
5. **Hidden is not deleted** — Recovery routes are safer, but old implementation and unreachable daily methods still exist.
6. **Success bookkeeping can turn real success into reported failure** — activity/revision writes after external side effects are a repeated risk in source review.

## Fixed work that must not regress

- loopback-only Recovery server
- Recovery daily CRUD routes removed
- native.selectTask exact registration invariant
- current-task key includes channel/accountId/userId
- implicit latest/unique task auto-selection removed
- runtime generation no longer advances on every state transition
- durable Cloud job checkpoints/recovery exist
- Cloud deployment metadata no longer duplicates botToken/gatewayKey plaintext
- guessed dsh-im importer removed
- unchecked dsh-im send fallback removed
- fake cloud-store production module removed
- legacy daily Native controller/navigation pruned
- known group messages are rejected before control routing

## Planning principle

Do not create 201 independent patches. Cluster by authority/state-machine/root cause, preserve every source ID, and make one coherent repair sequence.
