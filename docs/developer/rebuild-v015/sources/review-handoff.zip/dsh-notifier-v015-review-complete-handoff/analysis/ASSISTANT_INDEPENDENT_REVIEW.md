# Assistant Independent Review

Baseline: `dev@2542a3107e7d3795e6ba5b294a7a5b82052c3431`.

These findings come from direct source inspection after Stage 4. Overlaps are preserved explicitly.

## MY-R01 — P0 — 仅配置 Telegram 出站通知也会隐式启动入站私聊 transport

**Theme:** 产品边界 / Telegram

**Locations:** `src/assembly/inbound-signals.mjs`, `src/index.mjs`, `src/assembly/inbound-channels.mjs`

**Finding:** resolveInboundSignals() 的 inboundBotToken 会回落到出站 Telegram botToken；只要 token 非空，index 装配就把 Telegram 视为 inbound-ready 并启动长轮询。空身份时还可能进入 guided pairing。

**Impact:** “通知”和“私聊”不是独立能力。用户只想收通知时也可能启动私聊控制面，与 v0.15 用户显式开启私聊的产品模型冲突。

**Overlap:** 上传报告没有以该完整因果链明确列出。

## MY-R02 — P0 — dsh-im v1 fingerprint 字段读取错误

**Theme:** dsh-im 契约

**Locations:** `src/control-plane/dsh-im-bridge.mjs`, `test/v015-stage-s14-dsh-im-bridge.test.mjs`

**Finding:** bridge 读取 description.accountFingerprint / description.fingerprint，而当前 upstream v1 返回 description.account.fingerprint；测试桩也复制了错误扁平 shape。

**Impact:** 真实支持 checked delivery 的 dsh-im bot 可能被判 not-supported；CI 绿但锁定了错误契约。

**Overlap:** 对应 DSH-F01 / F02。

## MY-R03 — P0 — terminate() 仍是事务外 stale read → whole-row durable write

**Theme:** Interaction 并发

**Locations:** `src/interaction/ledger.mjs`

**Finding:** terminate 先 get pending，再 setDurable terminal；并发 resolve 可能先成功，随后被旧 pending 快照覆盖成 terminated。

**Impact:** 真实回答/审批结果可能被迟到取消路径覆盖，违反 first-winner 与 durable state machine 约束。

**Overlap:** 对应上一轮 DSH-A03。

## MY-R04 — P0 — markUncertain() 存在同类 stale read/write 覆盖窗口

**Theme:** Interaction 并发

**Locations:** `src/interaction/ledger.mjs`

**Finding:** markUncertain 仍先读旧 row 再整行 setDurable；若期间 row 已 resolved，迟到失败路径可把终态写回 uncertain。

**Impact:** 已完成操作可能被重新标记为结果未知，破坏终态单调性。

**Overlap:** 与 DSH-A03 同根，但需单独测试。

## MY-R05 — P0 — “关闭私聊”删除持久化配置，但当前 transport/admission 不立即关闭

**Theme:** 私聊关闭 / 权限状态

**Locations:** `src/native/actions.mjs`, `src/inbound/channel-config.mjs`, `src/assembly/inbound-channels.mjs`

**Finding:** Native remove inbound 主要删除 `<type>:account`；入站配置明确 restart-pending，registry 只有整体 dispose，没有 per-channel immediate stop/admission revoke。

**Impact:** UI 可以显示已关闭，而当前进程仍继续接收并处理手机指令直到重启，形成 UI 权限状态与真实权限状态不一致。

**Overlap:** 上传报告没有以该完整链明确列出。

## MY-R06 — P1 — “稍后处理”按钮实际映射 reject/decline 终态

**Theme:** 问题 UX

**Locations:** `src/native/private-chat-view.mjs`, `src/native/actions.mjs`, `src/questions/router.mjs`

**Finding:** 用户文案“稍后处理”对应 action/reject，最终 adminSettle 走 decline 并终结问题，不是 defer。

**Impact:** 用户以为稍后再处理，实际永久跳过问题；属于明确用户语义错误。

**Overlap:** 上传报告未明确列出。

## MY-R07 — P1 — stale preview guard 不覆盖 secret clear

**Theme:** Portability 并发

**Locations:** `src/control-plane/config-portability.mjs`

**Finding:** stale-field 检查主要比较 patch 字段，对 clear[] 中 secret 的旧预览没有同等 compare-current guard。

**Impact:** 预览后别人更新了 secret，旧预览仍可能把新 secret 清掉。

**Overlap:** 对应 DSH-A04。

## MY-R08 — P1 — 私聊读模型允许任意第一个 owner，写动作却要求全局恰好一个 owner

**Theme:** Native 多 owner

**Locations:** `src/native/private-chat-view.mjs`, `src/native/actions.mjs`

**Finding:** ownerOf(rows) 取第一个 owner；selectTask 则要求 owners.length === 1。

**Impact:** 存在多个 owner binding 时 UI 显示已确认，但所有任务选择都会失败。

**Overlap:** 对应 DSH-F06 / 201 清单 #16/#29。

## MY-R09 — P1 — 定向 public push(channel) 把 accepted/confirmed/unknown 压回旧二态

**Theme:** Public notifier evidence

**Locations:** `src/notify.mjs`, `src/public.mjs`, `types/index.d.ts`, `PLUGINS.md`, `PLUGINS.en.md`

**Finding:** notifyAll 已有 accepted/confirmed/unknown；定向 notify/public adaptSingle 仍主要返回 legacy delivered/failed 形状，unknown timeout 可被外部消费者理解为普通失败。

**Impact:** 第三方插件可能基于 !ok 重试一个实际上可能已被 provider 接受的通知，造成重复。

**Overlap:** 对应 DSH-E03/E04，并补充真实后果。

## MY-R10 — P1 — runtime / TypeScript / testing fake 的返回契约仍不一致

**Theme:** Public API contract

**Locations:** `src/public.mjs`, `types/index.d.ts`, `src/testing.mjs`, `test/public.test.mjs`

**Finding:** 真实 flush 与类型/fake 返回形状不一致；PushResult types 缺 accepted/confirmed/unknown；部分 fake 的 ok 语义与生产不同。

**Impact:** 测试消费者可以通过 fake，但真实运行时出现不同控制流；TS 类型不能表达当前 evidence 模型。

**Overlap:** 对应 DSH-E01/E02/E04/E05。

## MY-R11 — P1 — dsh-notifier/sent 事件 evidence 需要重新核对

**Theme:** Public event contract

**Locations:** `src/public.mjs`, `public event emission path`, `PLUGINS.md`, `PLUGINS.en.md`

**Finding:** 内部 delivery 已区分 accepted/confirmed/unknown，但公开 sent 事件仍可能通过 legacy/脱敏投影丢失 evidence。

**Impact:** 跨插件观察者可能无法区分确定失败、provider accepted 和结果未知。

**Overlap:** 201 清单未以该表述明确列出；下一规划模型必须重新核实当前 payload。

## MY-R12 — P1 — 非 QQ 未知/缺失 chatType 默认当 private

**Theme:** Private-only fail-closed

**Locations:** `src/control/session-arbiter.mjs`

**Finding:** known group 值返回 group，其余非 QQ 直接 private；只有 QQ unknown 被特殊 fail-closed。

**Impact:** provider 协议演进或缺字段时，无法证明 private 的消息可能获得 private-control 资格。

**Overlap:** 对应 DSH-F13 / 201 #31/#32。

## MY-R13 — P1 — Recovery HTTP surface 已收窄，但 shipped Admin JS/API 仍保留大量旧管理台逻辑

**Theme:** Recovery dead code

**Locations:** `src/admin/ui/client.mjs`, `src/admin/api.mjs`, `src/admin/events.mjs`, `src/admin/ui.mjs`

**Finding:** server routes 已 read-only，但大体量旧 channels/members/sessions/bindings/questions/SSE 逻辑仍随源码维护；/api/events 已删但旧 SSE/管理代码仍存在。

**Impact:** 维护面、审计面和包体仍背负已退出产品的旧控制台实现，容易被误接回。

**Overlap:** 与 201 Recovery/包体问题相关，但本条强调 shipped dead implementation。

## MY-R14 — P1 — user-copy lint 只覆盖部分字符串来源，真实 UI 技术词可漏检

**Theme:** 用户文案门禁

**Locations:** `test/user-copy-lint.test.mjs`, `client.js`

**Finding:** lint 主要依赖特定字符串构造模式，真实可见的“隧道/cloudflared/入站控制/Access 应用 ID”等可以逃过 gate。

**Impact:** CI 绿不能证明用户界面满足“无内部技术术语、低认知负担”的硬要求。

**Overlap:** 与上传报告 UX/文档问题相关，但这里是测试机制缺陷。

## MY-R15 — P1 — YAML-only Telegram token 在 Cloud deployment claim 后可能被 secretReference 自己切断

**Theme:** Cloudflare / Telegram

**Locations:** `src/cloudflare/deployment.mjs`

**Finding:** 首次 token() 可从 outbound YAML 读取，但 record.secretReference 会设为 state key；该 row 不存在时后续 token() 不再 fallback YAML，fingerprint 比较立即失败。

**Impact:** 合法 YAML-only 配置可在同一轮自动部署中自我失效。

**Overlap:** 对应 DSH-F03。

## MY-R16 — P1 — recovery-required 与 failed 未真正区分，永久失败可形成重复恢复/不可取消循环

**Theme:** Cloud job state machine

**Locations:** `src/cloudflare/deployment.mjs`

**Finding:** 代码预留 failed terminal，但异常基本都写 recovery-required；内存 job 清空后 cancel 不一定能处理 durable recovery row，deploy 会优先 resume 非终态 row。

**Impact:** 确定性冲突也会被当作可恢复不确定态，跨重试/重启反复执行恢复链。

**Overlap:** 对应 DSH-F04/F05，并与 201 #128/#129/#130 同域。
