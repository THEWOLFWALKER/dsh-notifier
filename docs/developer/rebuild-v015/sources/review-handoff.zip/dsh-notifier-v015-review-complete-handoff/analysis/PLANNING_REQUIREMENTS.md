# Planning Requirements for the Next Model

The next model should **plan only** unless the user separately authorizes implementation.

## Non-negotiable constraints

- The project is `dsh-notifier`; `dsh-im` is reference/compatibility input only.
- Product direction: **private-only / no group support**.
- Native-first; Advanced Console remains Recovery-only.
- Bad legacy internals may be deleted/replaced; do not preserve accidental architecture.
- Preserve proven provider protocol knowledge and actually-public contracts.
- No Big-Bang rewrite.
- Do not make a Store async rewrite the goal by itself.
- Real-device evidence must not be faked; absence of evidence is `unknown`.
- User-facing UI/docs must stay simple and avoid internal implementation jargon.
- Telegram automatic connection: one-click, same Bot Token, custom address allowed, internal Worker/gateway details hidden.
- One account/channel is default UX; internal account IDs must remain stable/correct.

## The plan must contain

1. Deduplicated issue map with all source IDs preserved.
2. Classification: release blocker / correctness / security / product mismatch / architecture debt / evidence gap / stale docs.
3. Root-cause clusters rather than one patch per issue.
4. Concrete module/interface ownership.
5. Migration and compatibility rules.
6. Race/failure matrices for interaction, runtime, cloud jobs, import and account identity.
7. Behavior/fault/integration tests; static grep only as supplemental invariant.
8. Upstream-derived fixtures for external contracts.
9. KEEP / REPLACE / DELETE / RECOVERY_ONLY ledger.
10. Stage sequencing, commit boundaries and integration checkpoints.
11. Explicit deferred list with reasons.
12. A release-readiness definition stronger than “tests green”.
13. A final taskpack layout for a fresh implementation Agent.

## The plan must not

- revive Sessions/Bindings/Members internal IA;
- re-add group control/support;
- restore old architecture just to satisfy stale tests;
- blindly treat every source P1 as equal without re-evaluating evidence;
- silently drop duplicated issues—merge them while retaining source IDs;
- automatically rewrite the Store to async or replace persistence wholesale without a concrete migration case.
