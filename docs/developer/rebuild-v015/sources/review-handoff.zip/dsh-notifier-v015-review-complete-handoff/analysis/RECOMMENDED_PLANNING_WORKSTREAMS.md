# Recommended Planning Workstreams

This is a decomposition aid, not the final implementation plan.

## A — Release-blocking semantic integrity
- notification vs private-chat admission
- private-chat immediate revoke semantics
- interaction terminal monotonicity
- “稍后处理” semantics
- secret-clear stale guard
- account isolation

## B — External/public contracts
- dsh-im v1 fixtures/bridge
- public notifier accepted/confirmed/unknown model
- TypeScript/fake/runtime parity
- public sent-event semantics
- host compatibility freshness

## C — Cloud/runtime state machine
- Cloud token source/reference
- failed vs recovery-required
- link/unbind/apply recovery
- tunnel lifecycle
- runtime/health generation fences

## D — Native truthfulness / product completion
- error vs empty state
- multi-owner model
- truncation totals/pagination
- member/pairing reachability
- attention sorting
- user-copy lint coverage

## E — Store/routing/core hardening
- reference escape and stale merge
- routing validation/dedup/retry
- remaining account-aware keys
- async lifecycle contracts
- bounded caches/timers

## F — Provider robustness
- QQ buttons / lifecycle
- Telegram offset/poison-update/stop
- Feishu legacy card rules
- DingTalk ACK/ambiguous reply
- callback reference lifetime

## G — CI/release/evidence
- CI + release guard composition
- host compat continuous gate
- reproducible DOM deps
- Windows/Node-version decision
- branch protection
- package exports/internal/testing surface
- docs truth cleanup
- real-host/provider evidence matrix

The final plan should order dependencies; these workstreams are not meant to run independently without coordination.
