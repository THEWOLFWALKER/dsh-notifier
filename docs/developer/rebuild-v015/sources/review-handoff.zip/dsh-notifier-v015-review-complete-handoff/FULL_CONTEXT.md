

# ===== FILE: 00_START_HERE.md =====

# dsh-notifier v0.15 — Review Complete Handoff

Review baseline: `dev@2542a3107e7d3795e6ba5b294a7a5b82052c3431`.

This ZIP is for the **next planning model**. It is not an implementation taskpack and not a release package.

## No-omission design

- Both uploaded reports are preserved verbatim under `original-reports/`.
- The exact 201-row current issue table is parsed into `inventories/current-201-issues.json`.
- The previous 61-item recheck is parsed into `inventories/previous-61-recheck.json`.
- DSH-F01 through DSH-F16 are preserved separately.
- This assistant's direct post-Stage-4 findings are `MY-R01` through `MY-R16`.
- `FULL_CONTEXT.md` concatenates the generated synthesis and both raw reports into one readable file.

Do **not** add 201 + 61 + 16 + 16 as a unique-issue count. Many are rechecks or overlaps. Preserve IDs while deduplicating by root cause.

The next model should plan first, not code first.


# ===== FILE: 01_CURRENT_BASELINE.md =====

# Current Baseline

- Repository: `THEWOLFWALKER/dsh-notifier`
- Branch: `dev`
- Review HEAD: `2542a3107e7d3795e6ba5b294a7a5b82052c3431`
- HEAD message: `docs(workstream): record P5 commit`
- Latest dev CI observed: GitHub Actions run `37100165531`, success
- `dev` vs `main`: **diverged**, ahead 111 / behind 1
- observed merge-base: `803e37de2957a04bf563a60fdff88f0ac76b64d3`

Previous Stage 4 recorded: Node 2447/2447, DOM 41/41, release guard, 28-channel matrix, Host compatibility check.

Those gates prove repository-defined checks are green, not that all cross-layer/external contracts are correct.

## Future implementation Git rules

- Work from execution-time latest `origin/dev`.
- Push only `dev`.
- No force push.
- No main merge/push during repair stages.
- No tag / GitHub Release / npm publish before final approval.
- Author = `THEWOLFWALKER`.
- Committer = `THEWOLFWALKER`.
- Reuse the repository's existing THEWOLFWALKER email.


# ===== FILE: analysis/MASTER_SYNTHESIS.md =====

# Master Synthesis

## Source hierarchy

This file is a planning entry point, not a replacement for raw evidence.

- Exact 201 current issues: `original-reports/dsh-notifier-dev-postfix-review-2026-10-03.md`
- Previous 61-item recheck + F01–F16: `original-reports/dsh-notifier-dev-recheck-and-review-2026-10-03.md`
- Parsed exact source rows: `inventories/current-201-issues.json`
- Direct independent findings: `inventories/assistant-independent-findings.json`

Source master issue table records **201** current issues/risks: P1=69, P2=130, P3=2.

Status distribution:
- 残留: 138
- 新发现: 51
- 证据缺口: 10
- 文档漂移: 2

Section distribution:
- A. 产品边界与 Native v2: 30
- B. Control Core / 私聊安全边界: 21
- C. 路由 / Conversation / 当前任务: 16
- D. 通知路由 / Runtime / Health: 25
- E. state.json / 持久化 / 并发: 23
- F. Cloudflare / 自动部署 / Tunnel: 24
- G. Provider 层残留与真机证据: 23
- H. Secondary Surface / dsh-im Bridge: 9
- I. Recovery Console / Admin Server: 5
- J. CI / 发布门禁 / 文档: 25

## High-confidence release blockers / planning anchors

### 1. Product capability boundary

- `MY-R01`: Telegram outbound notification credentials can implicitly start Telegram inbound/private transport.
- `MY-R05`: closing private chat changes persisted desired state but does not guarantee immediate live admission revocation.
- `MY-R12` / F13 / #31–#32: unknown non-QQ chat type is not fail-closed.
- Source #1: positive group-support paths remain while the user product rule is private-only/no group support.

### 2. Interaction state integrity

- `MY-R03/R04` / A03: terminate and markUncertain still have stale read→write windows.
- `MY-R06`: “稍后处理” is actually terminal reject/decline.
- `MY-R07` / A04: stale import guard does not equally protect destructive secret clear.

### 3. Account / identity isolation

- `MY-R08` / F06 / #16/#29: multi-owner read/write contradiction.
- E07–E11, F08/F09 and source routing/control rows show account-aware migration is incomplete across pending keys, owner fallback, `/log`, dedup and throttles.
- Missing accountId still falls back to `default` in some paths rather than failing closed.

### 4. External contract correctness

- `MY-R02` / F01/F02: real dsh-im v1 returns `account.fingerprint`; notifier and its mock read the wrong flat field.
- dsh-im checked target digest and failure semantics must match upstream exactly, not approximately.
- Host/dsh-im compatibility documentation and freshness gates are stale in parts of the repo.

### 5. Public notifier API semantics

- `MY-R09` / E03: directed public push can collapse unknown/uncertain into legacy failure semantics.
- `MY-R10` / E01/E02/E04/E05: runtime, TypeScript and testing fake disagree.
- `MY-R11`: public sent-event evidence should be re-audited so accepted/confirmed/unknown is not lost.

### 6. Cloudflare state machine

- `MY-R15` / F03: YAML-only Telegram token can be cut off by its own secretReference.
- `MY-R16` / F04/F05: failed vs recovery-required is not actually separated; permanent failures can re-enter recovery.
- Source #116–#139 adds link/unbind asymmetry, apply-state ordering, stale health, startup recovery side effects, cancel failure, retained cloud resources and tunnel lifecycle issues.

## Cross-cutting root-cause patterns

1. **Fail-open empty-state projection** — exceptions become `[]`, `false`, `default`, `private` or “not configured”. Unknown/unavailable must remain first-class.
2. **Account-aware migration stopped halfway** — one canonical `(channel, accountId, userId)` principal model has not reached every state domain.
3. **Desired/live/evidence conflation** — configured, admitted/live, provider accepted and confirmed are still mixed in several paths.
4. **Tests can duplicate local assumptions** — dsh-im fingerprint is the clearest example.
5. **Hidden is not deleted** — Recovery routes are safer, but old implementation and unreachable daily methods still exist.
6. **Success bookkeeping can turn real success into reported failure** — activity/revision writes after external side effects are a repeated risk in source review.

## Fixed work that must not regress

- loopback-only Recovery server
- Recovery daily CRUD routes removed
- native.selectTask exact registration invariant
- current-task key includes channel/accountId/userId
- implicit latest/unique task auto-selection removed
- runtime generation no longer advances on every state transition
- durable Cloud job checkpoints/recovery exist
- Cloud deployment metadata no longer duplicates botToken/gatewayKey plaintext
- guessed dsh-im importer removed
- unchecked dsh-im send fallback removed
- fake cloud-store production module removed
- legacy daily Native controller/navigation pruned
- known group messages are rejected before control routing

## Planning principle

Do not create 201 independent patches. Cluster by authority/state-machine/root cause, preserve every source ID, and make one coherent repair sequence.


# ===== FILE: analysis/ASSISTANT_INDEPENDENT_REVIEW.md =====

# Assistant Independent Review

Baseline: `dev@2542a3107e7d3795e6ba5b294a7a5b82052c3431`.

These findings come from direct source inspection after Stage 4. Overlaps are preserved explicitly.

## MY-R01 — P0 — 仅配置 Telegram 出站通知也会隐式启动入站私聊 transport

**Theme:** 产品边界 / Telegram

**Locations:** `src/assembly/inbound-signals.mjs`, `src/index.mjs`, `src/assembly/inbound-channels.mjs`

**Finding:** resolveInboundSignals() 的 inboundBotToken 会回落到出站 Telegram botToken；只要 token 非空，index 装配就把 Telegram 视为 inbound-ready 并启动长轮询。空身份时还可能进入 guided pairing。

**Impact:** “通知”和“私聊”不是独立能力。用户只想收通知时也可能启动私聊控制面，与 v0.15 用户显式开启私聊的产品模型冲突。

**Overlap:** 上传报告没有以该完整因果链明确列出。

## MY-R02 — P0 — dsh-im v1 fingerprint 字段读取错误

**Theme:** dsh-im 契约

**Locations:** `src/control-plane/dsh-im-bridge.mjs`, `test/v015-stage-s14-dsh-im-bridge.test.mjs`

**Finding:** bridge 读取 description.accountFingerprint / description.fingerprint，而当前 upstream v1 返回 description.account.fingerprint；测试桩也复制了错误扁平 shape。

**Impact:** 真实支持 checked delivery 的 dsh-im bot 可能被判 not-supported；CI 绿但锁定了错误契约。

**Overlap:** 对应 DSH-F01 / F02。

## MY-R03 — P0 — terminate() 仍是事务外 stale read → whole-row durable write

**Theme:** Interaction 并发

**Locations:** `src/interaction/ledger.mjs`

**Finding:** terminate 先 get pending，再 setDurable terminal；并发 resolve 可能先成功，随后被旧 pending 快照覆盖成 terminated。

**Impact:** 真实回答/审批结果可能被迟到取消路径覆盖，违反 first-winner 与 durable state machine 约束。

**Overlap:** 对应上一轮 DSH-A03。

## MY-R04 — P0 — markUncertain() 存在同类 stale read/write 覆盖窗口

**Theme:** Interaction 并发

**Locations:** `src/interaction/ledger.mjs`

**Finding:** markUncertain 仍先读旧 row 再整行 setDurable；若期间 row 已 resolved，迟到失败路径可把终态写回 uncertain。

**Impact:** 已完成操作可能被重新标记为结果未知，破坏终态单调性。

**Overlap:** 与 DSH-A03 同根，但需单独测试。

## MY-R05 — P0 — “关闭私聊”删除持久化配置，但当前 transport/admission 不立即关闭

**Theme:** 私聊关闭 / 权限状态

**Locations:** `src/native/actions.mjs`, `src/inbound/channel-config.mjs`, `src/assembly/inbound-channels.mjs`

**Finding:** Native remove inbound 主要删除 `<type>:account`；入站配置明确 restart-pending，registry 只有整体 dispose，没有 per-channel immediate stop/admission revoke。

**Impact:** UI 可以显示已关闭，而当前进程仍继续接收并处理手机指令直到重启，形成 UI 权限状态与真实权限状态不一致。

**Overlap:** 上传报告没有以该完整链明确列出。

## MY-R06 — P1 — “稍后处理”按钮实际映射 reject/decline 终态

**Theme:** 问题 UX

**Locations:** `src/native/private-chat-view.mjs`, `src/native/actions.mjs`, `src/questions/router.mjs`

**Finding:** 用户文案“稍后处理”对应 action/reject，最终 adminSettle 走 decline 并终结问题，不是 defer。

**Impact:** 用户以为稍后再处理，实际永久跳过问题；属于明确用户语义错误。

**Overlap:** 上传报告未明确列出。

## MY-R07 — P1 — stale preview guard 不覆盖 secret clear

**Theme:** Portability 并发

**Locations:** `src/control-plane/config-portability.mjs`

**Finding:** stale-field 检查主要比较 patch 字段，对 clear[] 中 secret 的旧预览没有同等 compare-current guard。

**Impact:** 预览后别人更新了 secret，旧预览仍可能把新 secret 清掉。

**Overlap:** 对应 DSH-A04。

## MY-R08 — P1 — 私聊读模型允许任意第一个 owner，写动作却要求全局恰好一个 owner

**Theme:** Native 多 owner

**Locations:** `src/native/private-chat-view.mjs`, `src/native/actions.mjs`

**Finding:** ownerOf(rows) 取第一个 owner；selectTask 则要求 owners.length === 1。

**Impact:** 存在多个 owner binding 时 UI 显示已确认，但所有任务选择都会失败。

**Overlap:** 对应 DSH-F06 / 201 清单 #16/#29。

## MY-R09 — P1 — 定向 public push(channel) 把 accepted/confirmed/unknown 压回旧二态

**Theme:** Public notifier evidence

**Locations:** `src/notify.mjs`, `src/public.mjs`, `types/index.d.ts`, `PLUGINS.md`, `PLUGINS.en.md`

**Finding:** notifyAll 已有 accepted/confirmed/unknown；定向 notify/public adaptSingle 仍主要返回 legacy delivered/failed 形状，unknown timeout 可被外部消费者理解为普通失败。

**Impact:** 第三方插件可能基于 !ok 重试一个实际上可能已被 provider 接受的通知，造成重复。

**Overlap:** 对应 DSH-E03/E04，并补充真实后果。

## MY-R10 — P1 — runtime / TypeScript / testing fake 的返回契约仍不一致

**Theme:** Public API contract

**Locations:** `src/public.mjs`, `types/index.d.ts`, `src/testing.mjs`, `test/public.test.mjs`

**Finding:** 真实 flush 与类型/fake 返回形状不一致；PushResult types 缺 accepted/confirmed/unknown；部分 fake 的 ok 语义与生产不同。

**Impact:** 测试消费者可以通过 fake，但真实运行时出现不同控制流；TS 类型不能表达当前 evidence 模型。

**Overlap:** 对应 DSH-E01/E02/E04/E05。

## MY-R11 — P1 — dsh-notifier/sent 事件 evidence 需要重新核对

**Theme:** Public event contract

**Locations:** `src/public.mjs`, `public event emission path`, `PLUGINS.md`, `PLUGINS.en.md`

**Finding:** 内部 delivery 已区分 accepted/confirmed/unknown，但公开 sent 事件仍可能通过 legacy/脱敏投影丢失 evidence。

**Impact:** 跨插件观察者可能无法区分确定失败、provider accepted 和结果未知。

**Overlap:** 201 清单未以该表述明确列出；下一规划模型必须重新核实当前 payload。

## MY-R12 — P1 — 非 QQ 未知/缺失 chatType 默认当 private

**Theme:** Private-only fail-closed

**Locations:** `src/control/session-arbiter.mjs`

**Finding:** known group 值返回 group，其余非 QQ 直接 private；只有 QQ unknown 被特殊 fail-closed。

**Impact:** provider 协议演进或缺字段时，无法证明 private 的消息可能获得 private-control 资格。

**Overlap:** 对应 DSH-F13 / 201 #31/#32。

## MY-R13 — P1 — Recovery HTTP surface 已收窄，但 shipped Admin JS/API 仍保留大量旧管理台逻辑

**Theme:** Recovery dead code

**Locations:** `src/admin/ui/client.mjs`, `src/admin/api.mjs`, `src/admin/events.mjs`, `src/admin/ui.mjs`

**Finding:** server routes 已 read-only，但大体量旧 channels/members/sessions/bindings/questions/SSE 逻辑仍随源码维护；/api/events 已删但旧 SSE/管理代码仍存在。

**Impact:** 维护面、审计面和包体仍背负已退出产品的旧控制台实现，容易被误接回。

**Overlap:** 与 201 Recovery/包体问题相关，但本条强调 shipped dead implementation。

## MY-R14 — P1 — user-copy lint 只覆盖部分字符串来源，真实 UI 技术词可漏检

**Theme:** 用户文案门禁

**Locations:** `test/user-copy-lint.test.mjs`, `client.js`

**Finding:** lint 主要依赖特定字符串构造模式，真实可见的“隧道/cloudflared/入站控制/Access 应用 ID”等可以逃过 gate。

**Impact:** CI 绿不能证明用户界面满足“无内部技术术语、低认知负担”的硬要求。

**Overlap:** 与上传报告 UX/文档问题相关，但这里是测试机制缺陷。

## MY-R15 — P1 — YAML-only Telegram token 在 Cloud deployment claim 后可能被 secretReference 自己切断

**Theme:** Cloudflare / Telegram

**Locations:** `src/cloudflare/deployment.mjs`

**Finding:** 首次 token() 可从 outbound YAML 读取，但 record.secretReference 会设为 state key；该 row 不存在时后续 token() 不再 fallback YAML，fingerprint 比较立即失败。

**Impact:** 合法 YAML-only 配置可在同一轮自动部署中自我失效。

**Overlap:** 对应 DSH-F03。

## MY-R16 — P1 — recovery-required 与 failed 未真正区分，永久失败可形成重复恢复/不可取消循环

**Theme:** Cloud job state machine

**Locations:** `src/cloudflare/deployment.mjs`

**Finding:** 代码预留 failed terminal，但异常基本都写 recovery-required；内存 job 清空后 cancel 不一定能处理 durable recovery row，deploy 会优先 resume 非终态 row。

**Impact:** 确定性冲突也会被当作可恢复不确定态，跨重试/重启反复执行恢复链。

**Overlap:** 对应 DSH-F04/F05，并与 201 #128/#129/#130 同域。


# ===== FILE: analysis/PLANNING_REQUIREMENTS.md =====

# Planning Requirements for the Next Model

The next model should **plan only** unless the user separately authorizes implementation.

## Non-negotiable constraints

- The project is `dsh-notifier`; `dsh-im` is reference/compatibility input only.
- Product direction: **private-only / no group support**.
- Native-first; Advanced Console remains Recovery-only.
- Bad legacy internals may be deleted/replaced; do not preserve accidental architecture.
- Preserve proven provider protocol knowledge and actually-public contracts.
- No Big-Bang rewrite.
- Do not make a Store async rewrite the goal by itself.
- Real-device evidence must not be faked; absence of evidence is `unknown`.
- User-facing UI/docs must stay simple and avoid internal implementation jargon.
- Telegram automatic connection: one-click, same Bot Token, custom address allowed, internal Worker/gateway details hidden.
- One account/channel is default UX; internal account IDs must remain stable/correct.

## The plan must contain

1. Deduplicated issue map with all source IDs preserved.
2. Classification: release blocker / correctness / security / product mismatch / architecture debt / evidence gap / stale docs.
3. Root-cause clusters rather than one patch per issue.
4. Concrete module/interface ownership.
5. Migration and compatibility rules.
6. Race/failure matrices for interaction, runtime, cloud jobs, import and account identity.
7. Behavior/fault/integration tests; static grep only as supplemental invariant.
8. Upstream-derived fixtures for external contracts.
9. KEEP / REPLACE / DELETE / RECOVERY_ONLY ledger.
10. Stage sequencing, commit boundaries and integration checkpoints.
11. Explicit deferred list with reasons.
12. A release-readiness definition stronger than “tests green”.
13. A final taskpack layout for a fresh implementation Agent.

## The plan must not

- revive Sessions/Bindings/Members internal IA;
- re-add group control/support;
- restore old architecture just to satisfy stale tests;
- blindly treat every source P1 as equal without re-evaluating evidence;
- silently drop duplicated issues—merge them while retaining source IDs;
- automatically rewrite the Store to async or replace persistence wholesale without a concrete migration case.


# ===== FILE: analysis/RECOMMENDED_PLANNING_WORKSTREAMS.md =====

# Recommended Planning Workstreams

This is a decomposition aid, not the final implementation plan.

## A — Release-blocking semantic integrity
- notification vs private-chat admission
- private-chat immediate revoke semantics
- interaction terminal monotonicity
- “稍后处理” semantics
- secret-clear stale guard
- account isolation

## B — External/public contracts
- dsh-im v1 fixtures/bridge
- public notifier accepted/confirmed/unknown model
- TypeScript/fake/runtime parity
- public sent-event semantics
- host compatibility freshness

## C — Cloud/runtime state machine
- Cloud token source/reference
- failed vs recovery-required
- link/unbind/apply recovery
- tunnel lifecycle
- runtime/health generation fences

## D — Native truthfulness / product completion
- error vs empty state
- multi-owner model
- truncation totals/pagination
- member/pairing reachability
- attention sorting
- user-copy lint coverage

## E — Store/routing/core hardening
- reference escape and stale merge
- routing validation/dedup/retry
- remaining account-aware keys
- async lifecycle contracts
- bounded caches/timers

## F — Provider robustness
- QQ buttons / lifecycle
- Telegram offset/poison-update/stop
- Feishu legacy card rules
- DingTalk ACK/ambiguous reply
- callback reference lifetime

## G — CI/release/evidence
- CI + release guard composition
- host compat continuous gate
- reproducible DOM deps
- Windows/Node-version decision
- branch protection
- package exports/internal/testing surface
- docs truth cleanup
- real-host/provider evidence matrix

The final plan should order dependencies; these workstreams are not meant to run independently without coordination.


# ===== FILE: handoff/NEXT_MODEL_HANDOFF.md =====

# Handoff to the Next Planning Model

You are taking over architecture/planning for `THEWOLFWALKER/dsh-notifier`.

Current review baseline: `dev@2542a3107e7d3795e6ba5b294a7a5b82052c3431`.

Previous implementation stages are complete, but post-RC adversarial review shows the project is **not release-ready yet**.

You are **not being asked to code yet**.

## Read order

1. `00_START_HERE.md`
2. `analysis/MASTER_SYNTHESIS.md`
3. `analysis/ASSISTANT_INDEPENDENT_REVIEW.md`
4. `analysis/PLANNING_REQUIREMENTS.md`
5. `analysis/RECOMMENDED_PLANNING_WORKSTREAMS.md`
6. `inventories/current-201-issues.json`
7. `inventories/previous-61-recheck.json`
8. `inventories/deep-findings-F01-F16.json`
9. both files under `original-reports/`

Do not skip the original reports. They are preserved verbatim so no source detail is lost.

## Your job

Produce the next complete implementation plan, not a shallow checklist.

You must:
- deduplicate without losing source IDs;
- find common root causes;
- distinguish actual bugs from product mismatch, architecture debt, evidence gaps and stale documentation;
- prioritize by user/data/security impact;
- design difficult interfaces/state transitions before delegation;
- specify migrations and backward-compatibility behavior;
- specify race/failure tests;
- state what old code must be deleted;
- combine work into a small number of coherent stages for a fresh implementation Agent.

The plan must be detailed enough that the implementation Agent does not need to re-research the architecture or external contracts.

## Facts that must not be missed

- Telegram notification config can implicitly activate Telegram inbound/private transport.
- Closing private chat is not guaranteed to immediately revoke live admission.
- Interaction terminate/markUncertain still have stale RMW windows.
- dsh-im v1 `account.fingerprint` is misread; local mock duplicates the wrong shape.
- Cloudflare YAML-only token/reference and job failure-state recovery need redesign.
- Account-aware migration is incomplete in several state domains.
- Directed public notifier results/types/fakes are not fully aligned with accepted/confirmed/unknown semantics.
- Native multi-owner read/write behavior conflicts.
- “稍后处理” currently means terminal reject/decline.
- Unknown non-QQ chatType is fail-open as private.
- The source master report has 201 current issues/risks; do not plan from summary alone.

## Product constraints

- dsh-notifier is the project; dsh-im is reference/compat input.
- private-only / no group support.
- Native-first.
- Recovery Console only.
- user-facing UI/docs stay simple and non-technical.
- no Big-Bang rewrite.
- Store async rewrite is not a goal by itself.
- no fake verification.

## Future implementation rules

When the user later hands your plan to an implementation Agent:
- only `dev`
- Author/Committer `THEWOLFWALKER`
- no force push
- no main
- no tags/releases/npm publish until final approval.

End your output with a proposed taskpack structure for the fresh implementation Agent.


# ===== ORIGINAL REPORT: dsh-notifier-dev-postfix-review-2026-10-03.md =====

# dsh-notifier dev 修复复核 + 第二轮继续 Review

> 审查对象：`THEWOLFWALKER/dsh-notifier` **dev**  
> 当前 HEAD：`2542a3107e7d3795e6ba5b294a7a5b82052c3431`（`docs(workstream): record P5 commit`）  
> 对比上一轮基线：`c890d2c154f237b255ac925e00ab019016692de0` → 当前 dev，共 **16 个提交**。  
> 最新 GitHub Actions：run #187 **success**。当前记录：Node **2447/2447**、DOM **41/41**。  
> 本报告只汇报当前仍成立、修复后新出现、以及证据仍未闭环的问题；**不提供修复方案**。

## 结论

这次修复是实质性的，上一轮多个核心 P1 已确认消失；但当前 dev 仍检出 **201 项**当前问题/隐患，其中 **P1 69 项、P2 130 项、P3 2 项**。

特别需要区分：当前实现完成的是“**入站控制只允许私聊**”，并没有完成“**项目不再支持任何群聊**”；出站群聊通知仍明确保留。

## 已确认修掉的上一轮核心问题（不计入本轮问题数）

| 项目 | 证据 | 当前复核 |
|---|---|---|
| Advanced Console 日常写操作面 | `31352579 / 6c9e72c` | 已收敛为 Recovery read-only，旧日常 sessions/bindings/members/pairing RPC 被移除/拦截。 |
| Recovery server 可被 caller 绑定 0.0.0.0 | `3154f618` | factory 现硬编码 127.0.0.1，并有 override 回归测试。 |
| Native selectTask 漏注册 | `e70b42a0` | method table 已注册 native.selectTask 并锁 exact-set invariant。 |
| Runtime state transition 每次推进 epoch | `6f33b87e` | 普通 update 不再推进 generation；replace/remove/replaceAll 才推进。 |
| 已识别群聊进入控制链 | `7d2cc85c` | privateControlAdmission 已在 identity/task routing 前拒绝已识别 group。 |
| 无显式任务自动挑最近/唯一会话 | `Stage 3` | agent-router 已移除 implicit latest/unique fallback。 |
| current-task 绑定不含 accountId | `6f33b87e` | 键已升级为 channel+accountId+userId。 |
| Cloud job 纯进程内、重启即丢 | `6f33b87e / 845699b3` | 已有 durable claim/checkpoint/startup recovery。 |
| Cloud deployment metadata 直接重复保存 botToken/gatewayKey | `6f33b87e` | record 改为 secretReference/fingerprint。 |
| dsh-im 猜测式 API/import fallback | `128ff9a9` | 仅接受 checked contract v1，guessed importer 已删。 |
| 未发货 cloud-storage fake/未来契约 | `6b9109b3` | 已从 package/docs 删除。 |
| Pairing mint/revoke 锁外整表覆盖 | `当前 pairing.mjs` | 代码已走 commitCodes + fresh transaction；仅文档仍旧。 |
| route:sessions sibling lost update | `Stage 3` | router/session-registry 已在 transaction fresh merge。 |
| Native 旧 daily controller | `6c9e72c` | 旧 browser controller/state/nav 已删除。 |

## 本轮统计

| 维度 | 数量 |
|---|---:|
| 总计 | **201** |
| P1 | **69** |
| P2 | **130** |
| P3 | **2** |
| 残留 | 138 |
| 新发现 | 51 |
| 证据缺口 | 10 |
| 文档漂移 | 2 |

## 当前问题清单

### A. 产品边界与 Native v2

| # | 级别 | 状态 | 类型 | 位置 | 当前问题 | 影响 |
|---:|:---:|:---:|---|---|---|---|
| 1 | P1 | 残留 | 产品偏差 | `HANDOFF.md + src/inbound/qq-gw.mjs` | 当前只禁止入站群聊控制；交接文档仍明确保留 outbound group notifications，QQ 仍有 notifyGroups 与 /v2/groups 路径。 | 与项目“后续仅私聊、不再支持任何群聊”的既定边界不一致。 |
| 2 | P1 | 新发现 | 状态错误 | `src/native/channel-view.mjs::rows` | channels.list() 抛错被 catch 成空数组。 | 真实读取故障会伪装成“尚未配置渠道”。 |
| 3 | P1 | 新发现 | 状态错误 | `src/native/channel-view.mjs::memberRows` | members.list() 抛错被 catch 成空数组。 | 真实成员故障会伪装成“没有使用者/默认账号”。 |
| 4 | P1 | 新发现 | 状态错误 | `src/native/private-chat-view.mjs::safeList` | members/questions/tasks 任一读源抛错都返回 []。 | 私聊页把系统故障伪装成无成员、无待处理、无任务。 |
| 5 | P1 | 新发现 | 状态错误 | `src/native/read-model.mjs::storageView` | storageStatus() 抛错回退 {}，随后 canSave=true。 | 无法判断存储状态时反而宣称“设置会保存”。 |
| 6 | P2 | 新发现 | 状态错误 | `src/native/read-model.mjs::isEnabled` | 读取 channels 失败时返回 false。 | 真实私聊故障会显示成“私聊未开启”。 |
| 7 | P1 | 新发现 | 状态聚合 | `src/native/channel-view.mjs::channelState` | 通知和私聊同时配置时，只要任一方向 active 就可进入 ready。 | 一个方向已坏、另一个方向正常时，整体状态可掩盖局部故障。 |
| 8 | P2 | 新发现 | 投影错误 | `src/native/channel-view.mjs::accountIdsOf` | 账号集合只从 member rows 推导；读不到成员时强制补 default。 | 真实非 default 账号可被投影成 default。 |
| 9 | P2 | 新发现 | 隐私/UX | `src/native/channel-view.mjs::accountView` | 非 default accountId 直接进入浏览器 payload 并作为 displayName。 | 内部账号标识成为浏览器和 UI 可见文本。 |
| 10 | P2 | 新发现 | 静默截断 | `src/native/read-model.mjs` | 已配置渠道 rail 上限固定 12，而产品支持 28 个出站渠道。 | 同时配置超过 12 个渠道时必然截断。 |
| 11 | P1 | 新发现 | 契约失效 | `client.js` | 服务端返回 snapshot.truncated，但当前客户端没有任何 truncated 消费逻辑。 | 服务端虽声明显式截断，用户端实际上仍静默丢数据。 |
| 12 | P1 | 新发现 | 计数错误 | `client.js::Overview` | 待处理横幅使用 native.pending.length，而 pending 本身最多 20。 | 待处理超过 20 条时主页会低报真实数量。 |
| 13 | P2 | 新发现 | API契约 | `src/native/read-model.mjs::pending` | native.pending 截到 20 条但不返回 total/truncated。 | 单独调用时调用方不知道还有更多事项。 |
| 14 | P2 | 新发现 | 静默截断 | `src/native/private-chat-view.mjs::taskCandidates` | 私聊首次向导候选任务固定 slice(0,10)，没有 total/truncated。 | 活跃任务超过 10 个时其余任务消失。 |
| 15 | P2 | 新发现 | UX | `client.js::PrivateChat` | 任务选择页没有“还有更多”提示。 | TASK_CAP 截断对用户不可见。 |
| 16 | P1 | 新发现 | 跨层冲突 | `private-chat-view.mjs + actions.mjs::selectTask` | 读模型找到任意第一个 owner 就 verified=true；写动作要求 owners.length===1。 | 存在两个 owner 行时 UI 显示已确认，但所有任务选择都失败。 |
| 17 | P2 | 新发现 | ID碰撞 | `src/native/private-chat-view.mjs::users` | 成员缺 key 时仍生成 opaqueUserId(空字符串)。 | 多个损坏成员会得到相同浏览器 ID。 |
| 18 | P2 | 新发现 | ID碰撞 | `src/native/private-chat-view.mjs::setup` | pending member 缺 key 时也用空字符串生成 ID。 | 多个损坏待确认身份不可区分。 |
| 19 | P2 | 新发现 | 不可操作项 | `src/native/private-chat-view.mjs::memberKeyOf` | UI 可展示缺 key 的成员，但 memberKeyOf 明确跳过空 key。 | 会出现“看得到但永远无法操作”的成员行。 |
| 20 | P2 | 新发现 | 信息暴露 | `src/native/private-chat-view.mjs::titleOf` | task 无 workspace 时直接把完整 taskRef 作为标题。 | 内部任务引用进入浏览器与 UI。 |
| 21 | P2 | 新发现 | 快照不一致 | `src/native/read-model.mjs::snapshot` | privateChat.summary 与 pendingItems 分别重复读取上游，不在同一快照。 | 数据变化时 pendingCount、列表、verified/currentTask 可彼此矛盾。 |
| 22 | P1 | 新发现 | 参数校验 | `src/native/actions.mjs::removeChannel` | direction 只有精确 inbound 才走入站，其他任意值都当 outbound。 | 未知/拼错 direction 可能删除错误方向配置。 |
| 23 | P1 | 新发现 | 审计语义 | `src/native/actions.mjs::testChannel` | 测试 unknown 仍记 channel-test-ok/status:ok；只有 failed 才记失败。 | 结果未知在活动记录里被写成成功。 |
| 24 | P2 | 残留 | 测试错位 | `src/native/actions.mjs::testChannel` | desired config 与 active runtime diverged 时，测试对象不一定是当前实际运行配置。 | 测试成功不能证明正在运行的 runtime 正常。 |
| 25 | P1 | 残留 | 世代污染 | `src/control-surface/health.mjs::recordTest` | 测试健康证据不携带 runtime generation。 | hot replace 竞速时旧配置测试结果可落入新 runtime 健康。 |
| 26 | P2 | 新发现 | 审计语义 | `src/native/actions.mjs::settlePending` | alreadyHandled 与实际 settle 都会写 question-settled/status:ok。 | “别人已经处理”会伪装成本次成功处理。 |
| 27 | P2 | 新发现 | 观测噪声 | `src/native/actions.mjs save/remove inbound` | saved:false / deleted:false 也会 touch revision 并写 activity。 | 失败/无变化同样制造成功风格的更新信号。 |
| 28 | P2 | 新发现 | 结果忽略 | `src/native/actions.mjs member actions` | 成员动作主要只看是否抛错，不统一检查 false/失败返回。 | authority 若用返回值表达失败，Native 仍可能返回成功。 |
| 29 | P2 | 新发现 | 多身份冲突 | `src/native/actions.mjs::selectTask` | 任务选择要求全局恰好一个 owner。 | 同一 owner 在多个渠道/账号有多条 owner 绑定时 Native 无法选任务。 |
| 30 | P2 | 残留 | 观测丢失 | `src/native/actions.mjs` | revision/activity 写失败全部吞掉。 | 业务已成功时客户端仍可能没有更新/活动证据。 |

### B. Control Core / 私聊安全边界

| # | 级别 | 状态 | 类型 | 位置 | 当前问题 | 影响 |
|---:|:---:|:---:|---|---|---|---|
| 31 | P1 | 残留 | fail-open | `src/control/session-arbiter.mjs::chatScopeOf` | 非 QQ 只识别少数群聊枚举；其他未知/空 chatType 一律 private。 | 新 provider 群类型或缺字段可能绕过仅私聊入口。 |
| 32 | P1 | 残留 | fail-open | `src/control/session-arbiter.mjs::privateControlAdmission` | 只有 QQ unknown chat scope 会 fail-closed。 | 不同 provider 的私聊安全边界强度不一致。 |
| 33 | P1 | 残留 | fail-open | `src/control/entry.mjs::paired` | identity 为 null/undefined 时直接 paired=true。 | 身份服务装配遗漏时配对层完全失效。 |
| 34 | P1 | 残留 | 账号隔离 | `src/control/entry.mjs::paired` | paired 仅比较 channel+userId，不比较 accountId。 | 同渠道多账号下同 userId 可通过这一层。 |
| 35 | P1 | 残留 | 去重碰撞 | `src/control/entry.mjs::eventIdOf` | 缺 provider eventId 时合成 ID 不包含 accountId/sessionId。 | 不同账号/会话在同毫秒可共用 dedup key。 |
| 36 | P2 | 残留 | 编码碰撞 | `src/control/entry.mjs::eventIdOf` | 合成 ID 用冒号直接拼字段，分量不转义。 | 字段含冒号时 tuple 编码存在碰撞。 |
| 37 | P1 | 残留 | 有效期放宽 | `src/control/entry.mjs::pendingMeta` | pending 缺时间戳时合成 now-1 与新的 10 分钟 expiresAt。 | 损坏/旧记录会重新获得有效窗口。 |
| 38 | P2 | 残留 | 策略版本放宽 | `src/control/entry.mjs::pendingMeta` | policyVersion 缺失时最终可回落字面量 1。 | 旧/损坏记录可能被当成当前策略。 |
| 39 | P2 | 残留 | 来源伪装 | `src/control/entry.mjs::pendingMeta` | source 缺失默认 mobile。 | 不完整来源被审计成明确 mobile。 |
| 40 | P1 | 残留 | 策略降级 | `src/control/entry.mjs resolver selection` | 注入两个不同 resolver 时静默禁用动态 resolver，回落 base policy。 | 预期会话级限制可能被悄悄丢弃。 |
| 41 | P1 | 残留 | 策略降级 | `src/control/entry.mjs::resolverOverlay` | 畸形 overlay 只记 ignored，随后继续使用 base policy。 | 坏掉的更严格 overlay 可导致权限面扩大。 |
| 42 | P1 | 残留 | 异步契约 | `src/control/session-arbiter.mjs::handle` | onSettle 按同步函数处理，Promise 会立即被视为成功。 | 异步 reject 捕不到，可出现已接受但真实结算失败。 |
| 43 | P2 | 残留 | 内存 | `src/control/session-arbiter.mjs` | settled 是无容量/TTL Set。 | 长生命周期会话持续积累 eventId。 |
| 44 | P2 | 残留 | 静默截断 | `src/control/session-arbiter.mjs::normalizeApprovalMembers` | approvalMembers 超过 64 直接截断。 | 第 65 个以后权限无显式失败。 |
| 45 | P1 | 残留 | 默认权限 | `src/control/session-arbiter.mjs::normalizeSessionPolicy` | 缺失 capabilities 时 observe/approve/stop 默认 true。 | 部分损坏策略可能比预期更宽。 |
| 46 | P2 | 残留 | 授权寿命 | `src/control/session-arbiter.mjs` | expiresAt 默认 null。 | 长期 session 可长期保留控制授权。 |
| 47 | P2 | 残留 | 注册覆盖 | `src/control/entry.mjs::register` | 同 command 再注册会覆盖旧 handler。 | 重复装配时 owner 取决于最后注册者。 |
| 48 | P2 | 残留 | 内部旁路 | `src/control/entry.mjs` | input 自带 settle 可替代注册 spec.settle。 | 内部调用者可以改变规范结算路径。 |
| 49 | P2 | 残留 | 重放窗口 | `src/control/handled-events.mjs` | handled event 仍只在进程内。 | 重启后该层已处理 ID 全部丢失。 |
| 50 | P2 | 残留 | 重放窗口 | `src/control/handled-events.mjs` | 去重有固定 TTL。 | TTL 后同一 provider event 可再次进入处理链。 |
| 51 | P2 | 残留 | 重放窗口 | `src/control/handled-events.mjs` | 去重表有容量上限。 | 高流量可在 TTL 前提前淘汰旧 eventId。 |

### C. 路由 / Conversation / 当前任务

| # | 级别 | 状态 | 类型 | 位置 | 当前问题 | 影响 |
|---:|:---:|:---:|---|---|---|---|
| 52 | P1 | 残留 | fail-silent | `src/routing/agent-router.mjs::safeGet` | store 读取异常统一回落 fallback/空表。 | 真实持久化故障可表现为没有绑定/没有默认路由。 |
| 53 | P2 | 残留 | 数据丢失 | `src/routing/agent-router.mjs::readMap` | 损坏 route 表被当成 {}。 | 后续合法写可能以空表为基底丢掉畸形 sibling 数据。 |
| 54 | P1 | 新发现 | 账号隔离 | `src/routing/agent-router.mjs::resolveInbound` | accountId 缺省仍是 default。 | 调用链遗漏 accountId 时会落入 default 绑定空间而不是拒绝。 |
| 55 | P2 | 新发现 | 规范化不一致 | `src/routing/agent-router.mjs` | current-task key 会 lower/trim channel，但 route:channels 默认路由读取使用原始 channel。 | 大小写/空白漂移可导致显式默认路由查不到。 |
| 56 | P2 | 新发现 | 裂键 | `src/routing/agent-router.mjs::setChannelDefault` | 只校验非空，不把 channel/agentKey trim 后存储。 | 带前后空白的等价值可形成不同 route key。 |
| 57 | P2 | 新发现 | 裂键 | `src/routing/agent-router.mjs::setAgentBinding` | agent/workspace key 同样保留原始空白。 | 同名工作区可被分裂成多条记录。 |
| 58 | P2 | 新发现 | 裂键 | `src/routing/agent-router.mjs::normalizeAgentsTable` | 整表替换也保留原始 key。 | CLI/Admin 整表写与其他路径可形成不同键语义。 |
| 59 | P2 | 新发现 | 宽容误解析 | `src/routing/agent-router.mjs::normalizeQuiet` | 字符串仅 true 视为 true，其他任意字符串都静默变 false。 | 拼错配置不会报错而会改变静音语义。 |
| 60 | P2 | 残留 | 兼容半提交 | `src/routing/agent-router.mjs::replaceBindings` | legacy/no-transact store 同时替换两张表仍可能部分提交。 | 函数返回失败但状态可能已经写了一半。 |
| 61 | P2 | 残留 | copy-on-read失效 | `src/routing/agent-router.mjs::deepCopyPlain` | JSON clone 失败时直接返回原 value。 | 非 JSON/损坏数据下 snapshot 可泄露 live 引用。 |
| 62 | P2 | 残留 | 双重行为 | `src/inbound/conversation.mjs::handleCommand` | 未知 /command 会先回未识别，再返回 false 让原文本继续进入模型。 | 一次输入同时产生控制回执与模型消息。 |
| 63 | P2 | 残留 | 命令歧义 | `src/inbound/conversation.mjs` | 普通文本以 ! 开头仍可触发 steer。 | 代码片段/感叹文本与控制命令共用前缀。 |
| 64 | P2 | 残留 | 本地化 | `src/inbound/conversation.mjs` | 当前仍存在硬编码中文失败文案。 | 英文环境出现混合语言。 |
| 65 | P2 | 残留 | 顺序语义 | `src/inbound/conversation.mjs::fireAsync` | 总线无法 await 的投递继续 fire-and-forget。 | 下载/路由耗时不同的消息不保证最终注入顺序。 |
| 66 | P2 | 残留 | 降级改变语义 | `src/inbound/conversation.mjs registry/router wrappers` | registry/router 异常被吞成 undefined/降级链。 | 内部故障可改变目标会话却只表现成无路由。 |
| 67 | P2 | 残留 | 内部ID暴露 | `src/inbound/conversation.mjs commands` | /status、/agent、/tasks 等会在私聊返回 session/task 引用或前缀。 | 聊天记录/截图包含内部标识。 |

### D. 通知路由 / Runtime / Health

| # | 级别 | 状态 | 类型 | 位置 | 当前问题 | 影响 |
|---:|:---:|:---:|---|---|---|---|
| 68 | P1 | 残留 | 配置语义 | `src/routing.mjs::routeTargets` | 某 level 显式空数组仍走 entries.length===0 -> 广播全部渠道。 | 无法表达“这个级别不发送”。 |
| 69 | P1 | 残留 | 配置语义 | `src/routing.mjs::resolveRouting` | 未知 channel 名仍会把 routing 标成 configured。 | 拼写错误可把该 level 变成 0 个目标而非配置错误。 |
| 70 | P1 | 残留 | 重复发送 | `src/routing.mjs::routeTargets` | 同 level 重复 channel entry 不去重。 | 重复配置会真实重复发送。 |
| 71 | P1 | 残留 | 消息覆写 | `src/routing.mjs` | entry overrides 不限键，直接浅合并 message。 | 路由项可覆盖 title/content/level/group 等核心字段。 |
| 72 | P2 | 残留 | 静默归一 | `src/routing.mjs::normalizeLevel` | 未知 level 静默归 active。 | 拼写错误被隐藏。 |
| 73 | P1 | 残留 | 参数错误 | `src/routing.mjs::retryPolicyOf` | retry.attempts 没有数值/整数校验，非法字符串可变 NaN。 | sendWithRetry 循环可一次都不执行并抛 undefined。 |
| 74 | P2 | 残留 | 参数错误 | `src/routing.mjs::retryPolicyOf` | 非法 retry.backoffMs 可变 NaN。 | 退避可退化成无等待。 |
| 75 | P2 | 残留 | 可用性 | `src/routing.mjs::sendWithRetry` | provider retryAfterMs 无最大上限。 | 异常值可让发送 Promise 挂很久。 |
| 76 | P2 | 残留 | 惊群 | `src/routing.mjs::sendWithRetry` | 指数退避无 jitter。 | 多实例故障时易同步重试。 |
| 77 | P2 | 残留 | 生命周期 | `src/routing.mjs::sendWithRetry` | retry sleep 没有 AbortSignal。 | 关闭/取消期间仍需等退避。 |
| 78 | P2 | 残留 | 重试分类 | `src/routing.mjs::retryAdviceOf` | 未知错误默认 SAFE。 | 未标 noRetry 的确定性认证/参数错误会被重试。 |
| 79 | P1 | 残留 | 世代误推进 | `src/runtime/channel-manager.mjs::replaceAll` | replaceAll 对所有 live type 推进 epoch，不判断该 runtime 是否实际变化。 | 批量收敛可无条件清空各渠道旧健康证据。 |
| 80 | P1 | 残留 | 迟到状态 | `src/runtime/channel-manager.mjs::setState` | generation 仅在调用方提供时做 fence。 | 未携 generation 的迟到异步状态仍可覆盖当前状态。 |
| 81 | P2 | 残留 | revision fence | `src/runtime/channel-manager.mjs::update` | appliedRevision 只在 incoming revision 存在时检查。 | 无 revision update 可覆盖已有较新 revision 状态。 |
| 82 | P2 | 残留 | 观察重复 | `src/runtime/channel-manager.mjs::subscribe` | 每个 manager listener 都再向 source 注册，同时 manager 也发 runtime event。 | 观察者面对两类事件，source listener 数线性增长。 |
| 83 | P1 | 残留 | 健康语义 | `src/control-surface/health.mjs` | provider accepted 仍足以把渠道标 healthy。 | 平台接受请求被提升为整体健康。 |
| 84 | P2 | 残留 | 陈旧健康 | `src/control-surface/health.mjs` | 成功证据默认保留 24h，且无主动探测。 | 渠道早已断开但无新发送时仍可能 healthy。 |
| 85 | P2 | 残留 | 重启失忆 | `src/control-surface/health.mjs` | 健康历史纯进程内。 | 重启会清除近期失败/unknown。 |
| 86 | P2 | 残留 | 时间污染 | `src/control-surface/health.mjs::recordSend` | 可解析的未来 record.time 不做上限钳制。 | 未来时间可长期压过正常证据。 |
| 87 | P2 | 残留 | 窗口消耗 | `src/control-surface/health.mjs::recordSend` | confirmed send 会同时插入 accepted 与 delivered 两条记录。 | 一次真实发送占两个 history 槽。 |
| 88 | P2 | 残留 | 世代边界 | `src/control-surface/health.mjs::recordSend` | 只拒绝 carried epoch < current，未来 epoch 不拒绝也不推进。 | 观察者乱序时可短暂接纳不属于当前世代的证据。 |
| 89 | P1 | 残留 | 生命周期异步 | `src/adapters/sender.mjs` | stateful start/stop/dispose 经同步 invoke 调用，不 await Promise。 | 异步生命周期 rejection 无法被当前 try/catch 正确处理。 |
| 90 | P2 | 残留 | 契约漂移 | `src/adapters/sender.mjs` | 注释写 retire 后旧 resolved 可重建新 epoch；代码 WeakSet 永久拒绝旧 resolved。 | 实现与维护说明相反。 |
| 91 | P1 | 残留 | 结果分类 | `src/adapters/sender.mjs late result` | provider 可能已产生外部效果后，retire 把晚到结果改成 CHANNEL_RETIRED + noRetry。 | 上层更像确定失败处理，但外部效果可能已经发生。 |
| 92 | P2 | 残留 | 诊断失真 | `src/adapters/sender.mjs::activeCount` | retire 立即递减 activeCount，即使异步清理实际仍未完成/失败。 | 资源统计可能比真实生命周期更乐观。 |

### E. state.json / 持久化 / 并发

| # | 级别 | 状态 | 类型 | 位置 | 当前问题 | 影响 |
|---:|:---:|:---:|---|---|---|---|
| 93 | P1 | 残留 | 引用逃逸 | `src/inbound/store.mjs::get` | get() 仍直接返回 state[key] 对象引用。 | 调用方可绕过事务与落盘直接修改进程内 canonical state。 |
| 94 | P1 | 残留 | 性能 | `src/inbound/store.mjs` | 核心 store 仍大量使用同步 fs API。 | state IO 直接阻塞 DSH Node 事件循环。 |
| 95 | P1 | 残留 | 性能 | `src/inbound/store.mjs::acquireLock` | 锁竞争用 Atomics.wait 同步 sleep。 | 并发写时宿主主线程可停顿数百毫秒。 |
| 96 | P1 | 残留 | 写放大 | `src/inbound/store.mjs::transact` | 单键变化仍序列化并 rename 整个 state.json。 | state 增长后高频小写的 IO/CPU 放大明显。 |
| 97 | P1 | 残留 | durability语义 | `src/inbound/store.mjs::transact` | temp+rename 后直接 durable:true，没有 fsync 文件和目录。 | durable 不等价于掉电级持久化保证。 |
| 98 | P1 | 残留 | 隔离失效 | `src/inbound/store.mjs::cloneState` | JSON clone 失败退化浅拷贝。 | 嵌套引用可穿透 detached draft 边界。 |
| 99 | P2 | 残留 | 跨进程陈旧 | `src/inbound/store.mjs::size` | size() 不 refreshIfChanged。 | 其他进程写 state 后 size 可返回旧值。 |
| 100 | P2 | 残留 | 返回语义 | `src/inbound/store.mjs::delete` | delete() 返回调用前 existed，不表达事务是否成功。 | 误用时落盘失败也可被当成删除成功。 |
| 101 | P2 | 残留 | 错误不可区分 | `src/inbound/store.mjs::sweepPrefix` | 无过期数据和事务失败都返回 0。 | 清理失败从返回值不可识别。 |
| 102 | P2 | 残留 | 跨进程检测 | `src/inbound/store.mjs::refreshIfChanged` | 变化主要依赖 mtimeMs。 | 低时间分辨率/同时间戳写入存在漏刷风险。 |
| 103 | P1 | 残留 | 状态复活 | `src/inbound/store.mjs::transact` | 运行中 state 文件被外部删除时用内存 state 作为 base 重建。 | 管理员删除 state.json 重置可能把旧状态重新写回来。 |
| 104 | P1 | 残留 | 权限 | `src/inbound/store.mjs` | chmod 0600 失败仍只告警并继续。 | 凭证文件实际权限可能比安全假设更宽。 |
| 105 | P2 | 残留 | 取证缺口 | `src/inbound/store.mjs` | 损坏文件超过 8MB 时跳过 forensic copy。 | 最大型异常损坏没有自动副本。 |
| 106 | P2 | 残留 | 备份陈旧 | `src/inbound/store.mjs::backup` | 同 label 已有历史 backup 就直接复用。 | 后续同 label 迁移的备份可能不是本次操作前状态。 |
| 107 | P2 | 残留 | 资源上限 | `src/inbound/store.mjs` | state.json 没有全局字节上限。 | 漏掉局部 cap 的业务域可拖慢整个 store。 |
| 108 | P2 | 残留 | 锁恢复 | `src/inbound/store.mjs::recoverableLock` | 锁 owner 只用 PID 探活；PID 被 OS 复用后陈锁会被当活锁。 | 写路径可能长期 STATE_BUSY。 |
| 109 | P1 | 残留 | 恢复覆盖 | `src/inbound/store.mjs::transact` | 运行期磁盘损坏会移走坏文件并用当前内存 state 重建。 | 内存若陈旧，恢复会固化陈旧快照。 |
| 110 | P1 | 新发现 | 兼容语义错误 | `src/inbound/store.mjs::mergeDurable` | 无 transact 的 legacy 分支直接 setDurable(key,patch)，并没有 merge 原值。 | 兼容分支会丢兄弟字段，违背函数字段合并契约。 |
| 111 | P2 | 残留 | schema | `src/inbound/store.mjs` | store 顶层只验证 JSON object，不做全局 per-key schema。 | 旧版/手工畸形值延迟到业务层才爆。 |
| 112 | P2 | 新发现 | 恢复语义不一致 | `src/inbound/store.mjs::loadBoot/tryLoad` | 启动时空文件视为正常空态；运行期读空文件则视为 corrupt。 | 同一磁盘状态在启动/运行中得到不同结论。 |
| 113 | P2 | 新发现 | 错误分类 | `src/inbound/store.mjs::acquireLock` | 创建/打开 lockfile 的各种异常统一进入抢锁重试。 | 权限/文件系统错误可能先表现成锁忙。 |
| 114 | P2 | 残留 | 故障域 | `src/inbound/store.mjs` | 身份、路由、凭证、interaction、Cloud job、cursor 等仍共享一个 state.json。 | 单文件损坏/权限/锁争用同时影响多个业务域。 |
| 115 | P2 | 残留 | 兼容语义 | `src/inbound/store.mjs::setDurable/deleteDurable` | legacy store 仍允许用 undefined 返回或简单 delete 调用推断 durable 成功。 | 非标准 store 可获得过于乐观的持久化结论。 |

### F. Cloudflare / 自动部署 / Tunnel

| # | 级别 | 状态 | 类型 | 位置 | 当前问题 | 影响 |
|---:|:---:|:---:|---|---|---|---|
| 116 | P1 | 残留 | 回滚不完整 | `src/cloudflare/deployment.mjs::link/unbind` | Telegram link 写 apiBase/gatewayKey/botToken/可能 chatId，但 backup/恢复范围并非完全对称。 | 解绑不保证恢复部署前全部 Telegram 凭证与目标状态。 |
| 117 | P1 | 残留 | 回滚不完整 | `src/cloudflare/deployment.mjs inbound link` | 入站 Telegram 也可能写 botToken，解绑主要围绕网关字段。 | 入站凭证可能在“已解绑”后仍保留部署时值。 |
| 118 | P1 | 残留 | 状态先行 | `src/cloudflare/deployment.mjs::link` | durable record 可先 bound:true，后续才 applyCommitted。 | runtime apply 失败时磁盘仍可能宣称已绑定。 |
| 119 | P1 | 残留 | 状态先行 | `src/cloudflare/deployment.mjs::unbind` | 持久化先清 bound，再做 runtime 收敛。 | apply 失败时 UI/磁盘已显示解绑，旧 runtime 可能仍在使用网关。 |
| 120 | P1 | 残留 | 健康误判 | `src/cloudflare/deployment.mjs` | Telegram Worker 健康主要验证 /healthz 模板/部署标识。 | Worker ready 不代表 Telegram upstream/token/真实投递可用。 |
| 121 | P2 | 残留 | 状态陈旧 | `src/cloudflare/deployment.mjs::status` | 持久化 health:ready 不会因后续 bot token 删除/轮换自动失效。 | 页面可继续显示陈旧健康。 |
| 122 | P1 | 残留 | secret ref陈旧 | `src/cloudflare/deployment.mjs token resolution` | 存在 secretReference 时优先读该引用；引用存在但值缺失可压住其他有效来源。 | 残留 ref 会让部署认为没有 token。 |
| 123 | P2 | 残留 | 本地垃圾 | `src/cloudflare/deployment.mjs` | 部署工作目录长期保留。 | 重复部署/失败会累积模板和 Wrangler 配置。 |
| 124 | P2 | 残留 | 公网面 | `Cloudflare worker config` | 自动部署固定 workers.dev 公网端点。 | 默认创建额外公网攻击面。 |
| 125 | P2 | 残留 | 供应链 | `src/cloudflare/wrangler-runner.mjs::prepare` | 运行时动态 npm install 固定版本 Wrangler，且无 lockfile。 | 结果依赖当时 npm 网络和传递依赖解析。 |
| 126 | P2 | 残留 | 可写目录 | `src/cloudflare/wrangler-runner.mjs` | Wrangler 安装到插件目录 tools。 | 只读/受管插件目录会让功能失败。 |
| 127 | P2 | 残留 | 脆弱解析 | `src/cloudflare/deployment.mjs::loginDevice` | 设备登录依赖 Wrangler CLI 文案/授权 URL 形状。 | CLI 文案或 Cloudflare 登录流程变化会打断自动化。 |
| 128 | P2 | 新发现 | 自动副作用 | `src/cloudflare/deployment.mjs startup recovery` | 宿主启动会自动继续未完成 durable cloud job。 | 旧的不确定云操作可在下次启动继续产生外部副作用。 |
| 129 | P2 | 新发现 | 重复恢复 | `src/cloudflare/deployment.mjs recovery-required` | recovery-required 非终态，可跨重启持续进入恢复链。 | 长期失败作业可能每次启动都被再次处理。 |
| 130 | P1 | 新发现 | 取消失败 | `src/cloudflare/deployment.mjs::cancel` | 先 saveJob 再 controller.abort；saveJob 抛错时 abort 不执行。 | 用户点击取消但外部部署仍继续。 |
| 131 | P2 | 残留 | dispose | `src/cloudflare/deployment.mjs::dispose` | cli/tunnel dispose 没有等待异步完成。 | 插件已 dispose 后外部清理仍可能继续。 |
| 132 | P2 | 残留 | 认证状态 | `src/cloudflare/deployment.mjs` | Cloudflare account/login 投影主要进程内。 | 重启后 deployment record 与当前管理身份状态暂时分裂。 |
| 133 | P2 | 残留 | 账号锁定 | `src/cloudflare/deployment.mjs` | existing deployment 绑定原 accountId。 | Cloudflare 账号所有权变化后旧记录易僵化。 |
| 134 | P2 | 残留 | 资源泄漏/费用 | `src/cloudflare/deployment.mjs` | 失败、解绑、取消都保留已创建 Worker/D1 等资源。 | 反复尝试会积累云资源。 |
| 135 | P1 | 残留 | 状态误报 | `extensions/cloudflare-tunnel/src/supervisor.mjs` | cloudflared 只要触发 spawn 就立即标 running。 | running 只证明进程启动，不证明 tunnel 连通。 |
| 136 | P1 | 残留 | 停止误报 | `extensions/cloudflare-tunnel/src/supervisor.mjs::stop` | drain 超时时先 finishStop(true) 再 SIGKILL。 | 强杀失败也可能已向调用方报告 stopped。 |
| 137 | P2 | 残留 | 错误隐藏 | `extensions/cloudflare-tunnel/src/supervisor.mjs::killProc` | kill 异常全部吞掉。 | 无法确认 cloudflared 是否真正终止。 |
| 138 | P2 | 残留 | 退避历史污染 | `extensions/cloudflare-tunnel/src/supervisor.mjs` | restartCount 成功 spawn 后不清零。 | 历史故障会持续抬高以后重连退避。 |
| 139 | P2 | 残留 | 未处理Promise | `extensions/cloudflare-tunnel/src/supervisor.mjs::scheduleReconnect` | timer 中 void start(lastConfig)，没有 catch。 | 自动重连 start rejection 可能成为未处理 Promise rejection。 |

### G. Provider 层残留与真机证据

| # | 级别 | 状态 | 类型 | 位置 | 当前问题 | 影响 |
|---:|:---:|:---:|---|---|---|---|
| 140 | P1 | 残留 | QQ真机 | `#26 + src/inbound/qq-gw.mjs::postMarkdownWithKeyboard` | QQ markdown+keyboard 仍不携带 msg_id，而普通被动回复支持 msg_id。 | 当前仍没有关闭“正文有、按钮无”的真机证据。 |
| 141 | P1 | 残留 | 能力过宣称 | `src/inbound/qq-gw.mjs` | 仍硬编码 capabilities.buttons=true。 | 上层把未完成真机闭环的 QQ keyboard 当确定能力。 |
| 142 | P2 | 残留 | 截断 | `src/inbound/qq-gw.mjs::postMarkdownWithKeyboard` | 超长 markdown 只取首块，没有显式截断标记。 | 审批/问题上下文会静默丢后半段。 |
| 143 | P2 | 残留 | 连接竞态 | `src/inbound/qq-gw.mjs::connect` | open/message 有 ws===conn guard，但 close handler 没有同等旧连接 guard。 | 旧连接迟到 close 可能触发 cleanup/reconnect 干扰新连接。 |
| 144 | P2 | 残留 | 错误假设 | `src/inbound/qq-gw.mjs` | WebSocket error 处理器假定随后一定 close。 | 不产生预期 close 的异常形态缺直接重连触发。 |
| 145 | P2 | 残留 | 僵尸连接 | `src/inbound/qq-gw.mjs heartbeat` | 心跳 sendFrame 失败不会总是立刻关闭 socket。 | OPEN 但不可写的连接可能更晚才被淘汰。 |
| 146 | P2 | 证据缺口 | 真机 | `docs/developer/memory/risks.md` | QQ HELLO watchdog、mention/media payload、keyboard rendering 仍被列为 provider-level evidence gap。 | 本地契约测试不能替代真实 QQ 客户端。 |
| 147 | P1 | 残留 | 状态误报 | `src/inbound/telegram-bot.mjs::clientState` | running=true 就返回 connected，第一次 getUpdates 尚未成功也一样。 | 持续网络失败期间仍可显示 connected。 |
| 148 | P1 | 残留 | 热循环 | `src/inbound/telegram-bot.mjs::loop` | update 已处理但 offset 落盘失败只 break 内层 for，不进入 catch/backoff。 | 持久化故障时可高频重复拉取/处理同批 update。 |
| 149 | P1 | 残留 | poison update | `src/inbound/telegram-bot.mjs::loop` | 单个 update 持续处理失败会阻止 offset 跨过它。 | 后续消息可能长期被同一坏 update 阻塞/重复带回。 |
| 150 | P2 | 残留 | 限流退避 | `src/inbound/telegram-bot.mjs` | api 解析 429 retry_after，但 poll loop catch 使用固定 backoffMs。 | getUpdates 限流不能按 provider 指定窗口退避。 |
| 151 | P2 | 残留 | 生命周期 | `src/inbound/telegram-bot.mjs::stop` | stop 不 abort 在途 getUpdates，最长等待约 35 秒。 | 热重载/卸载资源释放延迟明显。 |
| 152 | P2 | 残留 | 进程内卡片 | `src/inbound/callback-refs.mjs` | Telegram callback 短引用只保存在内存。 | 重启前已发按钮仍可见，但点击引用已失效。 |
| 153 | P2 | 残留 | 容量 | `src/inbound/callback-refs.mjs` | callback refs 有硬容量上限。 | 高并发审批/问题卡片会提前淘汰或降级。 |
| 154 | P2 | 残留 | 旧卡片放宽 | `src/inbound/feishu-bot.mjs::sourceChatAllowed` | 旧卡片缺 srcChat 时仍明确兼容放行。 | 遗留卡片来源会话校验弱于新卡片。 |
| 155 | P2 | 残留 | 旧卡片放宽 | `src/inbound/feishu-bot.mjs CARD_TTL` | 旧卡片缺 iat 时没有新卡片同等 15 分钟 TTL。 | 遗留卡片交互窗口更长。 |
| 156 | P2 | 残留 | SDK形状假设 | `src/inbound/feishu-bot.mjs::createTimedHttpInstance` | 只检查 base.request，随后无条件调用 get/delete/head/options/post/put/patch。 | SDK 导出形状变化时运行期才失败。 |
| 157 | P2 | 证据缺口 | 真机 | `docs/developer/memory/risks.md` | Feishu P2P payload path 仍是 provider evidence gap。 | operator/open_chat_id 等关键字段未由当前工作树证明真机一致。 |
| 158 | P2 | 残留 | ACK先行 | `src/inbound/dingtalk-stream.mjs::handleFrame` | 业务帧先 ack，再解析/处理 data。 | 二次 parse/业务处理失败后服务端已不会重推。 |
| 159 | P2 | 证据缺口 | 真机 | `docs/developer/memory/risks.md` | DingTalk Stream soak 仍是 provider evidence gap。 | ACK/重连/长时间运行主要由本地契约覆盖。 |
| 160 | P2 | 残留 | 重复副作用 | `src/inbound/dingtalk-stream.mjs::sendReply` | sessionWebhook 异常后立即主动 push；前一次请求若已被接受但响应丢失无法证明没发送。 | 同一回复可能重复出现。 |
| 161 | P2 | 证据缺口 | 安全 | `docs/developer/memory/risks.md` | WxPusher forged-UID provider behavior 仍明确未闭环。 | 身份来源强度缺真实对抗样本。 |
| 162 | P2 | 证据缺口 | 验收 | `docs/developer/v015-final-acceptance.md` | 当前验收明确没有 live Telegram/APNs device 和完整 DSH host。 | Stage 4 本地通过不能当真机/完整宿主闭环。 |

### H. Secondary Surface / dsh-im Bridge

| # | 级别 | 状态 | 类型 | 位置 | 当前问题 | 影响 |
|---:|:---:|:---:|---|---|---|---|
| 163 | P1 | 新发现 | 部分成功误报 | `src/control-surface/secondary-service.mjs::portability.commit` | 配置 commit 后 revision.touch/activity.record 若抛错，外层统一返回失败。 | 用户可能重试已经成功提交的导入。 |
| 164 | P1 | 新发现 | 外部副作用误报 | `src/control-surface/secondary-service.mjs::dshIm.send` | 外部 send 完成后同步 activity.record；activity 抛错会让 RPC 整体失败。 | 消息可能已发送，客户端却重试。 |
| 165 | P2 | 新发现 | 能力探测不足 | `src/control-surface/secondary-service.mjs portability` | 所有 portability 方法只以 exportConfig 存在作为总 gate。 | 部分实现缺其他方法时变成内部错误而非 not-supported。 |
| 166 | P2 | 新发现 | 资源上限 | `src/control-plane/dsh-im-bridge.mjs::listBots` | host 返回 bots 数量没有 cap。 | 异常 service 可制造巨大响应和大量 describe 调用。 |
| 167 | P2 | 新发现 | 资源上限 | `src/control-plane/dsh-im-bridge.mjs::listTargets` | targets 数量也没有 cap。 | 巨大列表直接进入 RPC/浏览器。 |
| 168 | P2 | 新发现 | 延迟放大 | `src/control-plane/dsh-im-bridge.mjs::listBots` | 每个 bot 串行 describeBot，单个调用各有 timeout。 | 大 bot 列表可放大到 N×timeout。 |
| 169 | P2 | 新发现 | 超时后副作用 | `src/control-plane/dsh-im-bridge.mjs::withDeadline` | Promise.race 超时只发 abort signal；host service 若忽略 signal，底层仍继续。 | RPC 已返回 timeout/unknown 后 sendChecked 仍可能稍后真实发送。 |
| 170 | P2 | 新发现 | 字段上限 | `src/control-plane/dsh-im-bridge.mjs projections` | bot/target label、targetId 等字符串没有长度 cap。 | 异常 host service 可把超长文本推向 UI。 |
| 171 | P2 | 证据缺口 | 上游兼容 | `docs/developer/memory/risks.md` | checked v1 bridge 尚未用当前真实 dsh-im host 验证。 | 本仓库模拟契约不能证明当前上游兼容。 |

### I. Recovery Console / Admin Server

| # | 级别 | 状态 | 类型 | 位置 | 当前问题 | 影响 |
|---:|:---:|:---:|---|---|---|---|
| 172 | P2 | 残留 | 额外服务面 | `cordis.patch.yml + src/admin/server.mjs` | Advanced Console 已 read-only，但默认安装仍启动独立 loopback HTTP server。 | 仍有独立 ticket/session/cookie/Origin/Host 生命周期与攻击面。 |
| 173 | P2 | 新发现 | 降级契约 | `src/admin/server.mjs ticket exchange` | session 创建能力缺失时，票据交换存在“accepted 但没有可用 session”的降级形态。 | UI 可看到认证交换成功但 diagnostics 仍不可用。 |
| 174 | P2 | 残留 | 缓存隐私 | `src/admin/server.mjs` | Recovery HTML/diagnostics 没有统一显式 no-store。 | 浏览器或反代可能缓存诊断内容。 |
| 175 | P3 | 残留 | 请求面 | `src/admin/server.mjs` | GET 路由仍走通用 body 读取。 | 本地 server 接受不必要的 GET body。 |
| 176 | P3 | 残留 | Origin范围 | `src/admin/server.mjs` | loopback allowlist 同时接受 http/https origin 变体。 | 实际 transport 外仍多接受一组本地 Origin 组合。 |

### J. CI / 发布门禁 / 文档

| # | 级别 | 状态 | 类型 | 位置 | 当前问题 | 影响 |
|---:|:---:|:---:|---|---|---|---|
| 177 | P1 | 残留 | CI覆盖 | `.github/workflows/ci.yml` | 注释写三平台，matrix 实际只有 Ubuntu/macOS。 | Windows 仍无 CI。 |
| 178 | P1 | 残留 | CI覆盖 | `.github/workflows/ci.yml + package.json` | engines 是 >=22，CI 只跑 Node 22。 | Node 23+ 回归不会被默认 CI 拦截。 |
| 179 | P1 | 残留 | 门禁断裂 | `.github/workflows/ci.yml` | CI 仍不执行 npm run verify:release。 | npm pack、exports、发布边界可在 Actions 全绿时完全没跑。 |
| 180 | P1 | 残留 | 门禁断裂 | `.github/workflows/ci.yml` | CI 也不执行 verify-host-compat。 | 交接里的 host compatibility 是手工证据，不是持续强制门禁。 |
| 181 | P1 | 残留 | 真实依赖缺口 | `.github/workflows/ci.yml` | 根测试不 npm install optionalDependencies。 | 真实 Feishu SDK/qrcode-terminal 安装链不由核心 CI 证明。 |
| 182 | P2 | 残留 | 不可复现 | `test/dom CI` | DOM workspace 使用 npm install --no-package-lock。 | 同一提交不同日期可解析出不同测试依赖。 |
| 183 | P2 | 残留 | 覆盖率 | `.github/workflows/ci.yml` | 没有 coverage threshold。 | 2447 tests 数量不能证明关键跨层路径覆盖。 |
| 184 | P2 | 残留 | 默认测试不完整 | `scripts/run-tests.mjs` | npm test 明确排除 test/dom。 | 本地只跑默认测试不会跑 41 个真实 React DOM 用例。 |
| 185 | P2 | 残留 | 质量计数口径 | `package.json` | dshQuality.testCount=2447 只对应根 Node suite，不含 DOM。 | 单一 testCount 不能代表 CI 实际测试总量。 |
| 186 | P1 | 残留 | 分支治理 | `GitHub dev branch protection` | dev protected，但 required status checks enforcement=off，contexts/checks 为空。 | CI 不是写入 dev 的强制前置条件。 |
| 187 | P2 | 残留 | 来源完整性 | `GitHub dev HEAD` | 当前 HEAD commit 为 unsigned。 | 没有提交签名这一层来源证明。 |
| 188 | P2 | 残留 | 版本识别 | `package.json` | dev 已是大规模 v0.15 工作，但 package version 仍 0.13.1。 | 直接打包/本地安装 dev 的版本诊断会带稳定版旧号。 |
| 189 | P2 | 新发现 | manifest重复 | `package.json::files` | docs/user/README.md 在 files 数组出现两次。 | 发布清单已经出现维护漂移。 |
| 190 | P2 | 残留 | 公开兼容面 | `package.json::exports` | 仍公开 ./internal -> ./src/index.mjs。 | 外部消费者可依赖内部实现，形成事实兼容负担。 |
| 191 | P2 | 残留 | 公开兼容面 | `package.json::exports` | ./testing 仍是正式 exports。 | 测试 helper 也成为外部可依赖 surface。 |
| 192 | P2 | 残留 | 元数据证据 | `package.json::dshWorkshop.evidence` | install/failureIsolation/hotReload/remove 全部为 null。 | lifecycle 宣称与机器可读 evidence 未闭环。 |
| 193 | P1 | 新发现 | 门禁语义 | `scripts/run-tests.mjs --count` | --count 只取测试总数，不以测试失败作为退出依据。 | 单独 verify:release 不能证明测试通过，只能证明计数相等。 |
| 194 | P1 | 新发现 | 门禁组合 | `CI + verify-release` | CI 跑测试但不跑 release guard；release guard 算数量但不要求测试成功。 | 两套门禁只有人工按正确顺序运行时才形成完整闭环。 |
| 195 | P2 | 文档漂移 | 技术事实 | `docs/developer/state-writer-registry.md` | Deferrals 仍写 pairing mint/revoke 为旧 read-modify-write；当前 pairing 已事务化。 | writer registry 对当前代码事实过期。 |
| 196 | P1 | 新发现 | 文档损坏 | `docs/developer/state-writer-registry.md writer-fitness` | src/routing/task-selection.mjs 行后混入 Cloud deployment 表格字段，Markdown 行结构损坏。 | 机器/人工读取 allowlist 会得到错误 authority 记录。 |
| 197 | P2 | 文档漂移 | 自相矛盾 | `docs/developer/state-writer-registry.md` | 正文说所有 multi-owner keys 已 converged，同时又保留 pairing deferral pending。 | 同一文档不能作为一致的收口状态摘要。 |
| 198 | P2 | 证据缺口 | 验收 | `docs/developer/v015-final-acceptance.md` | P5 明确没有 live Cloudflare、Telegram/APNs device 或完整 DSH host。 | 当前 dev 不能视为真实环境全闭环。 |
| 199 | P2 | 证据缺口 | 视觉 | `docs/developer/memory/risks.md` | Native v2 仍缺真实 DSH host dark/light/mobile walkthrough。 | fixture React 截图不等价真实宿主视觉验收。 |
| 200 | P2 | 证据缺口 | 宿主事件 | `docs/developer/memory/risks.md` | Host scoped error delivery 仍有 outstanding real-host regression。 | 宿主事件作用域关键行为仍缺真实回归。 |
| 201 | P2 | 证据缺口 | 兼容 | `docs/developer/memory/risks.md` | optional peer range 的 in-range/out-of-range real boot preflight 仍窄于源码兼容检查。 | 声明兼容的宿主版本未逐一真实 boot 闭环。 |

## 已明确不再重复计入的旧问题

- Advanced Console 仍承担日常 Members / Sessions / Bindings / Pairing 写操作：当前已收口为 Recovery read-only。
- Recovery server 可被 caller 改成 `0.0.0.0`：当前已硬编码 loopback。
- RuntimeChannelManager 每一次 starting/online 都推进 epoch：当前已修。
- current-task 不区分 accountId / 无选择自动挑最近会话：主路径已修。
- Cloud deployment record 直接保存 botToken/gatewayKey：当前已改 secretReference/fingerprint。
- pairing mint/revoke 旧锁外 read-modify-write：代码已修，本轮只保留文档漂移。
- dsh-im guessed importer / 普通 send fallback：当前已删除。

## 审查边界

依据当前 dev 源码、`c890d2c...dev` 16 提交差异、HANDOFF / acceptance / risks / writer registry、最新 Actions 与 branch protection 状态。没有把 fixture/mock 当真机证据；仓库 acceptance 自己也明确没有 live Cloudflare、Telegram/APNs device 与完整 DSH host，因此这些按“证据缺口”记录。


# ===== ORIGINAL REPORT: dsh-notifier-dev-recheck-and-review-2026-10-03.md =====

# dsh-notifier dev 修复复验 + 第四轮深度审查

> 审查对象：`THEWOLFWALKER/dsh-notifier`  
> 分支：`dev`  
> 当前 HEAD：`2542a3107e7d3795e6ba5b294a7a5b82052c3431`  
> 上一轮基线：`c890d2c154f237b255ac925e00ab019016692de0`  
> 审查日期：2026-10-03  
> 竞品 `dsh-im` **只作为参考和对照**，主审对象始终是 `dsh-notifier`。  
> 本文只汇报：**修复是否真实闭环、仍存在的问题、新发现的 bug / 隐患 / 错误前提 / 测试幻觉 / UX 断层 / 发布风险**。  
> **不提供修复方案。**

---

# 0. 当前事实

## 0.1 dev 不是“只补了几处”，而是做了一轮结构修复

从上一轮基线 `c890d2c1` 到当前 `2542a310`：

- 前进 **16 commits**；
- 主要覆盖 account identity、runtime generation、Cloudflare durable recovery、Native daily surface 收口、private-only admission、dsh-im checked contract、Recovery-only Admin 等；
- 当前工作线不是 main release：`package.json` 仍为 `0.13.1`。

## 0.2 当前 CI

当前 HEAD 的 GitHub Actions run `37100165531`：

- `test (ubuntu-latest, 22)`：success
- `test (macos-latest, 22)`：success
- root tests：执行
- DOM workspace tests：执行
- runtime dependency gate：执行
- channel matrix：执行

但 **Windows runner 仍不存在**。

## 0.3 当前分支关系

当前：

```text
dev ahead main: 111 commits
dev behind main: 1 commit
```

main-only commit：

```text
9d69dd7a  更新 README.md (#47)
```

即当前已经不是“dev 单向领先 main”，而是**双向 diverged**。

## 0.4 竞品基准

当前读取到 `xmanrui/dsh-im`：

```text
version: 4.34.2
latest inspected main commit: ecf6c85b
```

本轮只用它核对公开 Host service / checked delivery 等契约，不审查它本身。

---

# 1. 上一轮 61 项逐条复验

| ID | 当前状态 | 复验结论 |
|---|---|---|
| DSH-A01 | ✅ dev 已修 | dev runtime 已分 live config / frozen projection；#45/#46 仍是已发布 main 0.13.1 的问题，不再算当前 dev bug |
| DSH-A02 | ❌ 仍存在 | Store `get()` 仍直接返回 `state[key]` 的活引用 |
| DSH-A03 | ❌ 仍存在 | Ledger `terminate()` / `markUncertain()` 仍是事务外 get + whole-row durable set |
| DSH-A04 | ❌ 仍存在 | portability stale guard 仍只检查 patch，不检查 secret clear |
| DSH-A05 | ❌ 仍存在 | Remote URL 仍不查 fragment；`sessionId` lower-case 后与 Set 中混合大小写项不匹配 |
| DSH-A06 | ✅ 已修 | Cloudflare deployment 已去除 metadata 中 botToken/gatewayKey 明文重复持久化，并做旧记录迁移 |
| DSH-A07 | ❌ 仍存在 | Tunnel supervisor 仍把 child `spawn` 事件当 running |
| DSH-A08 | ❌ 仍存在 | stateful sender 在 send resolve 后发现 runtime retired，仍抛确定性 CHANNEL_RETIRED，无 uncertain |
| DSH-A09 | ❌ 仍存在 | store durable helper 仍无 fsync/fdatasync/目录 sync |
| DSH-A10 | ❌ 仍存在 | stale lock 活性最终仍依赖 PID probe；PID 复用可把陈锁视为活锁 |
| DSH-A11 | ❌ 仍存在 | Admin server `closePromise` 首次 stop 后不复位，start-stop-start-stop 仍不闭合 |
| DSH-A12 | ❌ 仍存在 | Tunnel persisted config 仍在 `start()` 前不进入 process-local config，重启初始 status 可报未配置 |
| DSH-A13 | ❌ 仍存在 | portability 默认 scope 仍写 `notificationPreferences`，normalize 后丢弃，文档仍输出空对象 |
| DSH-A14 | ✅ 已修 | dsh-im bridge 已有 bounded deadline + AbortSignal |
| DSH-A15 | ✅ 已纠正/收口 | bridge 真实契约已确认；猜测 importer 已删除。上一轮把 bridge 整体称 simulated 过宽 |
| DSH-A16 | ❌ 仍开放 | QQ C2C markdown + keyboard #26 仍 open，缺新的真机按钮闭环 |
| DSH-B01 | ❌ 仍存在 | CI 注释仍称三平台，matrix 只有 Ubuntu/macOS；Windows 没有 runner |
| DSH-B02 | ❌ 仍存在 | dev branch protection 仍无 required status check enforcement |
| DSH-B03 | ❌ 更明显 | 当前 dev/main 双向 diverged：dev ahead 111、behind 1 |
| DSH-B04 | ❌ 仍存在 | dev 已进入 v0.15 大量实现，package version 仍 0.13.1 |
| DSH-B05 | ✅ 已修 | 无生产实现的 cloud-store placeholder 已整个删除 |
| DSH-C01 | ❌ 仍存在 | Tunnel `protected` 仍基于配置声明，不是实际 Cloudflare Access 网络验证 |
| DSH-C02 | ❌ 仍存在 | Store live-reference 仍是 API 级边界问题 |
| DSH-D01 | ❌ 仍存在 | duplicate channel type：resolveConfig 全收、yamlRows first-wins、OutboundSource last-wins |
| DSH-D02 | ❌ 仍存在 | 重复 type 下 channel test raw 仍可能来自 first row，runtime 为 last row |
| DSH-D03 | ⚪ 明确产品约束 | `type -> 单实例` 仍是底层模型；ROADMAP 明确“不做单渠道多机器人”，不再当实现 bug，但仍是对 dsh-im 的结构性差距 |
| DSH-D04 | ✅ 已修 | bridge 现在读取 dsh-im `channel` 字段 |
| DSH-D05 | ✅ 已修 | bridge 要求 `contractVersion === 1` |
| DSH-D06 | ✅ 已修 | bridge 只走 `sendChecked()`，不再降级普通 send |
| DSH-D07 | ✅ 已修 | bridge list/describe/send 都有 deadline/abort 包装 |
| DSH-D08 | 🟡 仍未产品闭环 | dshIm backend 仍无 Native client 调用；而方法仍在 daily allowlist 中 |
| DSH-D09 | ✅ 已修 | 猜测格式的 dsh-im importer 与测试均删除 |
| DSH-D10 | ✅ 重新判定为非当前缺陷 | 官方 Host 明确 `connection.admit()` 成功即代表 operator；当前又增加精确 method allowlist。之前把“缺 notifier 独立 role gate”直接当漏洞过重 |
| DSH-D11 | ✅ Native 新链已修 | Native test receipt 已把 accepted/confirmed/timeout/确定失败分成四态 |
| DSH-D12 | 🟡 部分修 | dsh-im unknown 的 detail status 已改 unknown，但 Activity title/level 仍显示“Sent via dsh-im” + info |
| DSH-D13 | ❌ 仍存在 | Recovery-only Admin server 在 cordis.patch.yml 新安装默认仍 enabled:true |
| DSH-D14 | 🟡 有改善但仍存在 | client.js 从约 3085 行降到约 2516 行，仍是单文件大前端 |
| DSH-D15 | ❌ 仍是产品融合差距 | 仍以 main/sidebar/plugins bundle slots 为主，无 settings.section 风格的宿主 Settings IA |
| DSH-D16 | ✅ 已修 | Native channel-view 已加入 brand/name/group/usage 品牌元数据 |
| DSH-D17 | 🟡 被新形态替代 | 旧 home 前5已移除；新 rail 改为前12，但仍先截断后展示、没有 attention 优先排序 |
| DSH-D18 | ⚪ 撤回为明确 bug | 当前 ROADMAP 的“不做流式/多 bot/新增 inbound”与当前实现并无直接硬冲突；不再把它列为代码问题 |
| DSH-D19 | ❌ 仍存在 | risks.md 仍保留“DNS validate→fetch rebinding race”旧描述，与当前 pinned request 实现冲突 |
| DSH-E01 | ❌ 仍存在 | 真实 `flush()` 返回 `{ok:true}`，types 声明 Promise<void>，fake 返回 undefined |
| DSH-E02 | ❌ 仍存在 | testing fake 的 disabled/rate-limited/budget/busy/malformed 仍默认 `ok:true`，生产为 `ok:false` |
| DSH-E03 | ❌ 仍存在 | 定向 public `push({channel})` 仍经 adaptSingle 丢失 unknown/uncertain |
| DSH-E04 | ❌ 仍存在 | PushResult types 仍缺 accepted/confirmed/unknown |
| DSH-E05 | ❌ 仍存在 | public types test 仍以字符串/正则自证为主，无法证明 runtime/type 等价 |
| DSH-E06 | ✅ 核心已修 | current-task / inbound binding 已升级为 account-aware principal key，并有受控 legacy migration |
| DSH-E07 | ❌ 仍存在 | task selection pending key 仍是 channel:userId:chatId，无 accountId |
| DSH-E08 | ❌ 仍存在 | approval owner 代决 helper 仍 `identity.list(channel)` + userId，不筛 accountId |
| DSH-E09 | ❌ 仍存在 | questions owner 代答 helper 同样忽略 accountId |
| DSH-E10 | ❌ 仍存在 | inbound dedup key 仍 `dedup:<channel>:<messageId>`，无 accountId |
| DSH-E11 | ❌ 仍存在 | 拒绝回执 throttle 仍未按 accountId 隔离 |
| DSH-E12 | ❌ 仍存在 | 清 required secret 后 resolve 失败时仍保留旧 live runtime，旧凭据可继续在本进程使用 |
| DSH-E13 | ❌ 风险扩大 | notifier peer 仍锁 0.1.7；官方 DSH master 当前已是 0.2.1-alpha.1，且 0.2.0-rc.2 已出现 |
| DSH-E14 | ❌ 仍存在 | compatibility matrix 仍写“没找到 dshIm send/listBots/listTargets upstream contract”，已与 dsh-im 4.34.2 事实冲突 |
| DSH-E15 | ❌ 仍存在 | host compat gate 只验证 repo 内 peer/matrix/workshop 三份声明一致，不检查 upstream freshness |
| DSH-E16 | ❌ 仍存在 | DOM CI 仍 `npm install --no-package-lock` + React/jsdom semver range，不可复现 |
| DSH-E17 | ❌ 仍是供应链边界 | Cloudflare opt-in 仍会运行时 npm 安装并执行 Wrangler，无 lock/integrity pin |
| DSH-E18 | ❌ 仍存在 | 仓库仍未见 SECURITY.md / Dependabot / CODEOWNERS / repo-defined CodeQL 安全工作流 |
| DSH-E19 | ❌ 仍存在 | Native 仍无自身更新检查/升级状态面 |

---

# 2. 本轮新增 / 新暴露问题

## DSH-F01 — P1 — dsh-im v1 checked contract 的 fingerprint 字段读错，真实 bridge 会把支持 bot 判成“不支持”

当前 notifier：

[`src/control-plane/dsh-im-bridge.mjs`](https://github.com/THEWOLFWALKER/dsh-notifier/blob/2542a3107e7d3795e6ba5b294a7a5b82052c3431/src/control-plane/dsh-im-bridge.mjs)

`botProjection()` 读取：

```js
const accountFingerprint = str(
  description?.accountFingerprint ?? description?.fingerprint
)
```

并据此判断：

```js
checked =
  accountFingerprint !== null
  && capabilities.includes('proactive-text-checked')
```

但当前 dsh-im `4.34.2` 的真实 contract v1 返回的是：

```js
{
  version: 1,
  botId,
  channel,
  connected,
  capabilities: ['proactive-text-checked'],
  account: {
    fingerprint
  }
}
```

dsh-im 自己的 `sendChecked()` 也明确校验：

```js
if (account.account?.fingerprint !== expectedFingerprint)
  throw deliveryError('account-changed')
```

证据：

- [dsh-im delivery-service.mjs](https://github.com/xmanrui/dsh-im/blob/ecf6c85b72b213bcc937e379cf125d210d447401/plugin-src/host/delivery-service.mjs)
- [dsh-im PROACTIVE_DELIVERY.md](https://github.com/xmanrui/dsh-im/blob/ecf6c85b72b213bcc937e379cf125d210d447401/PROACTIVE_DELIVERY.md)

真实 dsh-im service 的 `description.account.fingerprint` 有值，但 notifier 读取的两个字段都是 `undefined`，所以 `checked=false`。随后 `listTargets()` / `send()` 都会把真实支持 checked delivery 的 bot 当成 `not-supported`。

---

## DSH-F02 — P1 — dsh-im bridge 测试桩复制了错误 contract，CI 正在锁定错误字段

当前测试：

[`test/v015-stage-s14-dsh-im-bridge.test.mjs`](https://github.com/THEWOLFWALKER/dsh-notifier/blob/2542a3107e7d3795e6ba5b294a7a5b82052c3431/test/v015-stage-s14-dsh-im-bridge.test.mjs)

mock `describeBot()` 返回：

```js
{
  botId,
  channel: 'telegram',
  accountFingerprint: FP,
  connected: true,
  capabilities: ['proactive-text-checked']
}
```

这恰好就是 notifier 自己错误理解的 shape。

真实 dsh-im 返回：

```js
{
  ...
  account: { fingerprint: FP }
}
```

因此当前测试能证明的是：

> notifier bridge 与 notifier 自造 mock 一致。

不能证明：

> notifier bridge 与 dsh-im v1 一致。

这是“测试自证”问题的新现实样本。

---

## DSH-F03 — P1 — Cloudflare Telegram 使用 YAML-only token 时，`secretReference` 会在 claim 落盘后把自己的 token 来源切断

当前：

[`src/cloudflare/deployment.mjs`](https://github.com/THEWOLFWALKER/dsh-notifier/blob/2542a3107e7d3795e6ba5b294a7a5b82052c3431/src/cloudflare/deployment.mjs)

token 读取：

```js
const token = () => {
  const ref = store.get('cloudflare:deployment:telegram')?.secretReference
  return String(
    (ref ? store.get(ref)?.botToken
         : outboundConfig.raw('telegram')?.botToken) ?? ''
  ).trim()
}
```

首次 `deploy()` 会先从 `outboundConfig.raw('telegram')` 读到 YAML token；但 claim 持久化后：

```js
record.secretReference =
  payload.botToken
    ? 'telegram:account'
    : (previous?.secretReference ?? 'channel:telegram:outbound')
```

YAML-only 场景没有 `channel:telegram:outbound` state row，下一次 `token()` 因为已经有 ref，就不再 fallback 到 `outboundConfig.raw()`，直接得到空串。

而同一轮 deployment 后面马上比较：

```js
fingerprint(currentToken) !== current.configSecretGeneration
```

所以这个问题可在**同一次部署**里触发，不需要等重启。

现有 Cloudflare test rig 的 `yamlRows` 是空 Map，没有覆盖 YAML-only token。

---

## DSH-F04 — P1 — Cloudflare durable job 没有实际 `failed` 终态，永久错误被永久标成 `recovery-required`

代码多处把 terminal 定义为：

```text
done
failed
cancel-requested
```

但当前 deployment service 没有任何一处写：

```js
state: 'failed'
```

所有 durable exception，只要不是显式 cancel，都进入：

```js
state: 'recovery-required'
recoveryRequired: true
```

包括确定性本地冲突，例如 credential generation mismatch / bad-request / conflict。

因此“可恢复的不确定云状态”和“确定永久失败”没有被状态机真正分开。

---

## DSH-F05 — P1 — Cloudflare 永久失败 job 可形成不可取消的 retry livelock

`deploy()` 会优先找任何非 terminal job：

```js
if (pending) return resume(pending)
```

所以 durable `recovery-required` 会被每次重试继续 resume。

但公开 `cancel()` 只处理当前内存 `job`。当一次失败已经 settle 后：

```text
job = null
durable row = recovery-required
```

此时 cancel 不会改 durable row。下一次 deploy 又会把同一 row 捞回来。

如果失败原因是永久性的，例如 secret generation 已变化，就会形成同一 durable claim 的重复冲突循环。

---

## DSH-F06 — P1 — Native “当前任务”模型与项目允许多 owner 的身份模型互相冲突

读模型：

[`src/native/private-chat-view.mjs`](https://github.com/THEWOLFWALKER/dsh-notifier/blob/2542a3107e7d3795e6ba5b294a7a5b82052c3431/src/native/private-chat-view.mjs)

```js
const ownerOf = rows =>
  rows.find(row => row?.role === 'owner') ?? null
```

多个 owner 时，会取列表里的第一位当“已确认本人”。

但动作：

[`src/native/actions.mjs`](https://github.com/THEWOLFWALKER/dsh-notifier/blob/2542a3107e7d3795e6ba5b294a7a5b82052c3431/src/native/actions.mjs)

`selectTask()` 要求：

```js
const owners = members.list()
  .filter(row => row?.role === 'owner')

if (owners.length !== 1)
  throw badRequest('请先确认使用者')
```

身份层本身允许多个 owner，只阻止删除最后一个 owner。

所以两个 owner 时：

- summary 仍会显示 verified；
- current task 读模型会挑一个 owner；
- `native.selectTask` 永远拒绝。

现有 Native boundary tests 没有 multi-owner + selectTask 用例。

---

## DSH-F07 — P1 — Recovery 收口后，成员管理 / 删除成员 / 撤销配对码在产品 UI 中失去入口

Recovery server 当前明确只保留 read-only recovery routes；member CRUD / pairing revoke 等 daily routes 已删除。

但当前 `client.js`：

```text
native.updateUser    -> 0 次调用
native.removeUser    -> 0 次调用
native.revokePairing -> 0 次调用
```

服务端方法仍存在。

当前形成：

```text
后端能力存在
Native UI 不可达
Recovery UI 已删除
```

因此 Stage 4 的 Recovery 收口同时切掉了这一段用户操作闭环。

---

## DSH-F08 — P2 — Remote `/log` owner 判断仍是 channel-scoped，不是 account-scoped

[`src/inbound/conversation.mjs`](https://github.com/THEWOLFWALKER/dsh-notifier/blob/2542a3107e7d3795e6ba5b294a7a5b82052c3431/src/inbound/conversation.mjs)

```js
return identity.list(envelope.channel).some(
  row =>
    String(row?.userId) === String(envelope.userId)
    && row?.role === 'owner'
)
```

没有比较 `accountId`。

同一 channel 中，如果 user X 在 bot/account A 是 owner、在 B 不是 owner，B 的 `/log` gate 仍可能被 A 的 owner binding 满足。

---

## DSH-F09 — P2 — approval / question 的 owner fallback 仍存在同类跨 account 借权

Approval：

[`src/approval/router.mjs`](https://github.com/THEWOLFWALKER/dsh-notifier/blob/2542a3107e7d3795e6ba5b294a7a5b82052c3431/src/approval/router.mjs)

Questions：

[`src/questions/router.mjs`](https://github.com/THEWOLFWALKER/dsh-notifier/blob/2542a3107e7d3795e6ba5b294a7a5b82052c3431/src/questions/router.mjs)

两者 owner helper 都只做：

```text
identity.list(channel)
+ userId
+ role === owner
```

没有 accountId。

Control Core 的最终 source binding 已 account-aware，但 owner fallback 资格仍可从同 channel 的另一 account 借角色。

---

## DSH-F10 — P2 — Surface allowlist 与真实 UI call graph 仍不一致

当前 Stage 4 声称 daily backend 只保留当前 UI 真实方法，但 allowlist 仍含：

```text
dshIm.status
dshIm.listBots
dshIm.listTargets
dshIm.send
```

当前 `client.js` 对 `dshIm.*` 是 0 次调用。

Native method table 还存在但当前 client 不调用：

```text
native.updateUser
native.removeUser
native.revokePairing
native.wait
```

client 的更新等待实际走的是 `surface.wait`。

所以当前只做到了：

> 服务端方法表内部自洽。

还没有做到：

> 服务端 allowlist == 当前前端真实调用集合。

---

## DSH-F11 — P2 — dsh-im `unknown` 虽不再记成 failed/ok，但 Activity 仍用成功式标题 + info level

Secondary service 现在对 ambiguous send 记录 `status: unknown`，这是正确进步。

但 Activity title 固定为：

```text
Sent via dsh-im (accepted is not delivered)
已通过 dsh-im 发送（接受 ≠ 送达）
```

而 `status:'unknown'` 不会进入 error/warn，仍落为 info。

一个“是否已发出完全不确定”的结果仍显示成“已通过 dsh-im 发送”。

---

## DSH-F12 — P2 — Native rail 的截断顺序仍可隐藏需要处理的渠道

[`src/native/read-model.mjs`](https://github.com/THEWOLFWALKER/dsh-notifier/blob/2542a3107e7d3795e6ba5b294a7a5b82052c3431/src/native/read-model.mjs)

先：

```js
const rail = all.filter(row => row.state !== 'not-set')
```

再：

```js
rail.slice(0, 12)
```

而 channel list 没有按 `needs-attention` / `connecting` 排序。

配置渠道超过 12 时，第 13 个异常渠道可以被 rail 隐藏在 12 个 ready 渠道之后。

---

## DSH-F13 — P2 — Private-only admission 对非 QQ 的未知 chatType 是 fail-open

[`src/control/session-arbiter.mjs`](https://github.com/THEWOLFWALKER/dsh-notifier/blob/2542a3107e7d3795e6ba5b294a7a5b82052c3431/src/control/session-arbiter.mjs)

QQ 未知 chatType 会进入 unknown，并被拒绝。

但非 QQ：

```js
if (type 是已知 group 值) return 'group'
return 'private'
```

也就是说未来 provider 新增未识别 chat type 时，默认被当成 private，而不是 fail-closed。

当前 Telegram / Feishu / DingTalk 的已知 shape 能正确识别，所以这是协议演进风险，不是当前已知 provider 的现成群聊绕过。

---

## DSH-F14 — P2 — `dev` 与 `main` 已双向分叉

当前 main-only commit：

```text
9d69dd7a  更新 README.md (#47)
```

只改 README，不是运行时事故。

但发布分支关系已从“dev 单向领先”变成双向 diverged，后续机械同步存在 README 反向覆盖/merge conflict 风险。

---

## DSH-F15 — P2 — Host compatibility freshness 风险进一步扩大

当前官方 `deepseek-ai/deepseek-harness` master：

```text
package version = 0.2.1-alpha.1
```

notifier compatibility 仍只声明：

```text
0.1.7-alpha.1
0.1.7-alpha.2
0.1.7-rc.1
0.1.7-rc.2
```

compatibility matrix snapshot 仍是 `2026-09-25`。

---

## DSH-F16 — P3 — Compatibility matrix 的 dsh-im 说明仍与当前 4.34.2 公开契约相反

当前 notifier 文档仍写：

```text
No current upstream contract was found for
ctx.dshIm.send/listBots/listTargets
```

但 dsh-im 4.34.2 当前公开：

```text
contractVersion: 1
describeBot
sendChecked
send
listTargets
listBots
```

而 notifier 自己已经写了对应 bridge。

当前是：

```text
代码承认真实 contract
测试声称 contract v1
兼容文档仍说没找到 contract
```

三套事实冲突。

---

# 3. 修复确实做对的部分

- Runtime outbound freeze 回归：dev 已真正改掉。
- Cloudflare secret duplication：deployment metadata 已不再直接持久 botToken/gatewayKey。
- dsh-im unsafe 普通 send fallback：已删除，要求 checked contract。
- 猜测式 dsh-im importer：整个删除。
- Private-only group admission：主链已接通，不是只写测试。
- current-task authority：已升级为 account-aware principal。
- Native channel UX：已有 brand / 用户名 / usage / group / 四态用户状态 / secret presence-only。
- Recovery backend：daily CRUD 确实从 Recovery 路由表删除。

---

# 4. 当前最值得警惕的共同模式

## 4.1 修复测试仍会复制实现假设

本轮最典型：

```text
真实 dsh-im:
account.fingerprint

notifier mock:
accountFingerprint

notifier implementation:
accountFingerprint
```

测试全绿，但三者只有后两者彼此一致。

## 4.2 account-aware 迁移仍未贯穿所有状态域

已 account-aware：

```text
Identity
current-task principal
Control Core source
部分 delivery evidence
```

仍 account-blind：

```text
task-selection pending
approval owner fallback
question owner fallback
remote /log owner gate
dedup
reply throttle
```

## 4.3 Recovery-only 收口产生“后端存在 / UI 不可达”

当前：

```text
native.updateUser       后端有 / 前端无
native.removeUser       后端有 / 前端无
native.revokePairing    后端有 / 前端无
dshIm.*                 后端有 / 前端无
```

## 4.4 Cloudflare recovery 把“不确定”与“确定失败”混成一个 durable 状态

当前所有非 cancel 异常统一进 `recovery-required`，但代码预留的 `failed` 状态从不写入。

---

# 5. 本轮新问题索引

| ID | 严重度 | 主题 |
|---|---|---|
| DSH-F01 | P1 | dsh-im account fingerprint contract 接错 |
| DSH-F02 | P1 | dsh-im mock 测试锁定错误 contract |
| DSH-F03 | P1 | Cloudflare YAML-only token reference 自断 |
| DSH-F04 | P1 | durable job 无实际 failed 终态 |
| DSH-F05 | P1 | recovery-required 永久 job retry/cancel livelock |
| DSH-F06 | P1 | Native current-task 与 multi-owner 身份模型冲突 |
| DSH-F07 | P1 | Recovery 收口后成员管理/撤销配对 UI 断链 |
| DSH-F08 | P2 | `/log` owner gate 忽略 accountId |
| DSH-F09 | P2 | approval/question owner fallback 忽略 accountId |
| DSH-F10 | P2 | Surface allowlist 与真实前端 call graph 漂移 |
| DSH-F11 | P2 | dsh-im unknown 仍展示成功式 Activity |
| DSH-F12 | P2 | Native rail 截断可隐藏异常渠道 |
| DSH-F13 | P2 | 非 QQ 未知 chatType 在 private-only 策略下 fail-open |
| DSH-F14 | P2 | dev/main 双向分叉 |
| DSH-F15 | P2 | DSH compatibility freshness 进一步扩大 |
| DSH-F16 | P3 | compatibility matrix 的 dsh-im 事实已过时 |

---

# 6. 当前验收判断

这一批修复**确实有明显结构进步**，不是假修。

但当前 dev 仍不能视为“上一轮问题全部闭环”。

当前 CI green 能证明：

> 当前仓库定义的测试 / DOM / release guard / channel matrix 自洽。

不能证明：

> 真实 dsh-im v1 contract、Cloudflare YAML-only 路径、多 owner Native 路径、跨 account owner fallback 已正确。

---

# 7. 证据入口

当前 dsh-notifier：

- `https://github.com/THEWOLFWALKER/dsh-notifier/tree/2542a3107e7d3795e6ba5b294a7a5b82052c3431`
- `https://github.com/THEWOLFWALKER/dsh-notifier/commit/2542a3107e7d3795e6ba5b294a7a5b82052c3431`

关键文件：

- `https://github.com/THEWOLFWALKER/dsh-notifier/blob/2542a3107e7d3795e6ba5b294a7a5b82052c3431/src/control-plane/dsh-im-bridge.mjs`
- `https://github.com/THEWOLFWALKER/dsh-notifier/blob/2542a3107e7d3795e6ba5b294a7a5b82052c3431/test/v015-stage-s14-dsh-im-bridge.test.mjs`
- `https://github.com/THEWOLFWALKER/dsh-notifier/blob/2542a3107e7d3795e6ba5b294a7a5b82052c3431/src/cloudflare/deployment.mjs`
- `https://github.com/THEWOLFWALKER/dsh-notifier/blob/2542a3107e7d3795e6ba5b294a7a5b82052c3431/src/native/actions.mjs`
- `https://github.com/THEWOLFWALKER/dsh-notifier/blob/2542a3107e7d3795e6ba5b294a7a5b82052c3431/src/native/private-chat-view.mjs`
- `https://github.com/THEWOLFWALKER/dsh-notifier/blob/2542a3107e7d3795e6ba5b294a7a5b82052c3431/src/native/read-model.mjs`
- `https://github.com/THEWOLFWALKER/dsh-notifier/blob/2542a3107e7d3795e6ba5b294a7a5b82052c3431/src/inbound/conversation.mjs`
- `https://github.com/THEWOLFWALKER/dsh-notifier/blob/2542a3107e7d3795e6ba5b294a7a5b82052c3431/src/approval/router.mjs`
- `https://github.com/THEWOLFWALKER/dsh-notifier/blob/2542a3107e7d3795e6ba5b294a7a5b82052c3431/src/questions/router.mjs`
- `https://github.com/THEWOLFWALKER/dsh-notifier/blob/2542a3107e7d3795e6ba5b294a7a5b82052c3431/src/control/session-arbiter.mjs`
- `https://github.com/THEWOLFWALKER/dsh-notifier/blob/2542a3107e7d3795e6ba5b294a7a5b82052c3431/src/inbound/store.mjs`
- `https://github.com/THEWOLFWALKER/dsh-notifier/blob/2542a3107e7d3795e6ba5b294a7a5b82052c3431/src/interaction/ledger.mjs`
- `https://github.com/THEWOLFWALKER/dsh-notifier/blob/2542a3107e7d3795e6ba5b294a7a5b82052c3431/src/control-plane/config-portability.mjs`
- `https://github.com/THEWOLFWALKER/dsh-notifier/blob/2542a3107e7d3795e6ba5b294a7a5b82052c3431/src/control-plane/remote-url.mjs`
- `https://github.com/THEWOLFWALKER/dsh-notifier/blob/2542a3107e7d3795e6ba5b294a7a5b82052c3431/src/admin/server.mjs`
- `https://github.com/THEWOLFWALKER/dsh-notifier/blob/2542a3107e7d3795e6ba5b294a7a5b82052c3431/src/control-surface/surface-allowlist.mjs`
- `https://github.com/THEWOLFWALKER/dsh-notifier/blob/2542a3107e7d3795e6ba5b294a7a5b82052c3431/docs/developer/compatibility-matrix.md`

竞品契约参考（仅对照）：

- `https://github.com/xmanrui/dsh-im/blob/ecf6c85b72b213bcc937e379cf125d210d447401/plugin-src/host/delivery-service.mjs`
- `https://github.com/xmanrui/dsh-im/blob/ecf6c85b72b213bcc937e379cf125d210d447401/PROACTIVE_DELIVERY.md`

DSH Host operator/admission 参考：

- `https://github.com/deepseek-ai/deepseek-harness/blob/5badb15009ae1756c3afe0ae0cef1faafc290ccc/packages/client/connection/src/rpc-host.ts`
- `https://github.com/deepseek-ai/deepseek-harness/blob/5badb15009ae1756c3afe0ae0cef1faafc290ccc/packages/client/connection/README.md`
