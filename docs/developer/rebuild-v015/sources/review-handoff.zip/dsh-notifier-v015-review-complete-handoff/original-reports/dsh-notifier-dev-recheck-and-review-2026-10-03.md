# dsh-notifier dev 修复复验 + 第四轮深度审查

> 审查对象：`THEWOLFWALKER/dsh-notifier`  
> 分支：`dev`  
> 当前 HEAD：`2542a3107e7d3795e6ba5b294a7a5b82052c3431`  
> 上一轮基线：`c890d2c154f237b255ac925e00ab019016692de0`  
> 审查日期：2026-10-03  
> 竞品 `dsh-im` **只作为参考和对照**，主审对象始终是 `dsh-notifier`。  
> 本文只汇报：**修复是否真实闭环、仍存在的问题、新发现的 bug / 隐患 / 错误前提 / 测试幻觉 / UX 断层 / 发布风险**。  
> **不提供修复方案。**

---

# 0. 当前事实

## 0.1 dev 不是“只补了几处”，而是做了一轮结构修复

从上一轮基线 `c890d2c1` 到当前 `2542a310`：

- 前进 **16 commits**；
- 主要覆盖 account identity、runtime generation、Cloudflare durable recovery、Native daily surface 收口、private-only admission、dsh-im checked contract、Recovery-only Admin 等；
- 当前工作线不是 main release：`package.json` 仍为 `0.13.1`。

## 0.2 当前 CI

当前 HEAD 的 GitHub Actions run `37100165531`：

- `test (ubuntu-latest, 22)`：success
- `test (macos-latest, 22)`：success
- root tests：执行
- DOM workspace tests：执行
- runtime dependency gate：执行
- channel matrix：执行

但 **Windows runner 仍不存在**。

## 0.3 当前分支关系

当前：

```text
dev ahead main: 111 commits
dev behind main: 1 commit
```

main-only commit：

```text
9d69dd7a  更新 README.md (#47)
```

即当前已经不是“dev 单向领先 main”，而是**双向 diverged**。

## 0.4 竞品基准

当前读取到 `xmanrui/dsh-im`：

```text
version: 4.34.2
latest inspected main commit: ecf6c85b
```

本轮只用它核对公开 Host service / checked delivery 等契约，不审查它本身。

---

# 1. 上一轮 61 项逐条复验

| ID | 当前状态 | 复验结论 |
|---|---|---|
| DSH-A01 | ✅ dev 已修 | dev runtime 已分 live config / frozen projection；#45/#46 仍是已发布 main 0.13.1 的问题，不再算当前 dev bug |
| DSH-A02 | ❌ 仍存在 | Store `get()` 仍直接返回 `state[key]` 的活引用 |
| DSH-A03 | ❌ 仍存在 | Ledger `terminate()` / `markUncertain()` 仍是事务外 get + whole-row durable set |
| DSH-A04 | ❌ 仍存在 | portability stale guard 仍只检查 patch，不检查 secret clear |
| DSH-A05 | ❌ 仍存在 | Remote URL 仍不查 fragment；`sessionId` lower-case 后与 Set 中混合大小写项不匹配 |
| DSH-A06 | ✅ 已修 | Cloudflare deployment 已去除 metadata 中 botToken/gatewayKey 明文重复持久化，并做旧记录迁移 |
| DSH-A07 | ❌ 仍存在 | Tunnel supervisor 仍把 child `spawn` 事件当 running |
| DSH-A08 | ❌ 仍存在 | stateful sender 在 send resolve 后发现 runtime retired，仍抛确定性 CHANNEL_RETIRED，无 uncertain |
| DSH-A09 | ❌ 仍存在 | store durable helper 仍无 fsync/fdatasync/目录 sync |
| DSH-A10 | ❌ 仍存在 | stale lock 活性最终仍依赖 PID probe；PID 复用可把陈锁视为活锁 |
| DSH-A11 | ❌ 仍存在 | Admin server `closePromise` 首次 stop 后不复位，start-stop-start-stop 仍不闭合 |
| DSH-A12 | ❌ 仍存在 | Tunnel persisted config 仍在 `start()` 前不进入 process-local config，重启初始 status 可报未配置 |
| DSH-A13 | ❌ 仍存在 | portability 默认 scope 仍写 `notificationPreferences`，normalize 后丢弃，文档仍输出空对象 |
| DSH-A14 | ✅ 已修 | dsh-im bridge 已有 bounded deadline + AbortSignal |
| DSH-A15 | ✅ 已纠正/收口 | bridge 真实契约已确认；猜测 importer 已删除。上一轮把 bridge 整体称 simulated 过宽 |
| DSH-A16 | ❌ 仍开放 | QQ C2C markdown + keyboard #26 仍 open，缺新的真机按钮闭环 |
| DSH-B01 | ❌ 仍存在 | CI 注释仍称三平台，matrix 只有 Ubuntu/macOS；Windows 没有 runner |
| DSH-B02 | ❌ 仍存在 | dev branch protection 仍无 required status check enforcement |
| DSH-B03 | ❌ 更明显 | 当前 dev/main 双向 diverged：dev ahead 111、behind 1 |
| DSH-B04 | ❌ 仍存在 | dev 已进入 v0.15 大量实现，package version 仍 0.13.1 |
| DSH-B05 | ✅ 已修 | 无生产实现的 cloud-store placeholder 已整个删除 |
| DSH-C01 | ❌ 仍存在 | Tunnel `protected` 仍基于配置声明，不是实际 Cloudflare Access 网络验证 |
| DSH-C02 | ❌ 仍存在 | Store live-reference 仍是 API 级边界问题 |
| DSH-D01 | ❌ 仍存在 | duplicate channel type：resolveConfig 全收、yamlRows first-wins、OutboundSource last-wins |
| DSH-D02 | ❌ 仍存在 | 重复 type 下 channel test raw 仍可能来自 first row，runtime 为 last row |
| DSH-D03 | ⚪ 明确产品约束 | `type -> 单实例` 仍是底层模型；ROADMAP 明确“不做单渠道多机器人”，不再当实现 bug，但仍是对 dsh-im 的结构性差距 |
| DSH-D04 | ✅ 已修 | bridge 现在读取 dsh-im `channel` 字段 |
| DSH-D05 | ✅ 已修 | bridge 要求 `contractVersion === 1` |
| DSH-D06 | ✅ 已修 | bridge 只走 `sendChecked()`，不再降级普通 send |
| DSH-D07 | ✅ 已修 | bridge list/describe/send 都有 deadline/abort 包装 |
| DSH-D08 | 🟡 仍未产品闭环 | dshIm backend 仍无 Native client 调用；而方法仍在 daily allowlist 中 |
| DSH-D09 | ✅ 已修 | 猜测格式的 dsh-im importer 与测试均删除 |
| DSH-D10 | ✅ 重新判定为非当前缺陷 | 官方 Host 明确 `connection.admit()` 成功即代表 operator；当前又增加精确 method allowlist。之前把“缺 notifier 独立 role gate”直接当漏洞过重 |
| DSH-D11 | ✅ Native 新链已修 | Native test receipt 已把 accepted/confirmed/timeout/确定失败分成四态 |
| DSH-D12 | 🟡 部分修 | dsh-im unknown 的 detail status 已改 unknown，但 Activity title/level 仍显示“Sent via dsh-im” + info |
| DSH-D13 | ❌ 仍存在 | Recovery-only Admin server 在 cordis.patch.yml 新安装默认仍 enabled:true |
| DSH-D14 | 🟡 有改善但仍存在 | client.js 从约 3085 行降到约 2516 行，仍是单文件大前端 |
| DSH-D15 | ❌ 仍是产品融合差距 | 仍以 main/sidebar/plugins bundle slots 为主，无 settings.section 风格的宿主 Settings IA |
| DSH-D16 | ✅ 已修 | Native channel-view 已加入 brand/name/group/usage 品牌元数据 |
| DSH-D17 | 🟡 被新形态替代 | 旧 home 前5已移除；新 rail 改为前12，但仍先截断后展示、没有 attention 优先排序 |
| DSH-D18 | ⚪ 撤回为明确 bug | 当前 ROADMAP 的“不做流式/多 bot/新增 inbound”与当前实现并无直接硬冲突；不再把它列为代码问题 |
| DSH-D19 | ❌ 仍存在 | risks.md 仍保留“DNS validate→fetch rebinding race”旧描述，与当前 pinned request 实现冲突 |
| DSH-E01 | ❌ 仍存在 | 真实 `flush()` 返回 `{ok:true}`，types 声明 Promise<void>，fake 返回 undefined |
| DSH-E02 | ❌ 仍存在 | testing fake 的 disabled/rate-limited/budget/busy/malformed 仍默认 `ok:true`，生产为 `ok:false` |
| DSH-E03 | ❌ 仍存在 | 定向 public `push({channel})` 仍经 adaptSingle 丢失 unknown/uncertain |
| DSH-E04 | ❌ 仍存在 | PushResult types 仍缺 accepted/confirmed/unknown |
| DSH-E05 | ❌ 仍存在 | public types test 仍以字符串/正则自证为主，无法证明 runtime/type 等价 |
| DSH-E06 | ✅ 核心已修 | current-task / inbound binding 已升级为 account-aware principal key，并有受控 legacy migration |
| DSH-E07 | ❌ 仍存在 | task selection pending key 仍是 channel:userId:chatId，无 accountId |
| DSH-E08 | ❌ 仍存在 | approval owner 代决 helper 仍 `identity.list(channel)` + userId，不筛 accountId |
| DSH-E09 | ❌ 仍存在 | questions owner 代答 helper 同样忽略 accountId |
| DSH-E10 | ❌ 仍存在 | inbound dedup key 仍 `dedup:<channel>:<messageId>`，无 accountId |
| DSH-E11 | ❌ 仍存在 | 拒绝回执 throttle 仍未按 accountId 隔离 |
| DSH-E12 | ❌ 仍存在 | 清 required secret 后 resolve 失败时仍保留旧 live runtime，旧凭据可继续在本进程使用 |
| DSH-E13 | ❌ 风险扩大 | notifier peer 仍锁 0.1.7；官方 DSH master 当前已是 0.2.1-alpha.1，且 0.2.0-rc.2 已出现 |
| DSH-E14 | ❌ 仍存在 | compatibility matrix 仍写“没找到 dshIm send/listBots/listTargets upstream contract”，已与 dsh-im 4.34.2 事实冲突 |
| DSH-E15 | ❌ 仍存在 | host compat gate 只验证 repo 内 peer/matrix/workshop 三份声明一致，不检查 upstream freshness |
| DSH-E16 | ❌ 仍存在 | DOM CI 仍 `npm install --no-package-lock` + React/jsdom semver range，不可复现 |
| DSH-E17 | ❌ 仍是供应链边界 | Cloudflare opt-in 仍会运行时 npm 安装并执行 Wrangler，无 lock/integrity pin |
| DSH-E18 | ❌ 仍存在 | 仓库仍未见 SECURITY.md / Dependabot / CODEOWNERS / repo-defined CodeQL 安全工作流 |
| DSH-E19 | ❌ 仍存在 | Native 仍无自身更新检查/升级状态面 |

---

# 2. 本轮新增 / 新暴露问题

## DSH-F01 — P1 — dsh-im v1 checked contract 的 fingerprint 字段读错，真实 bridge 会把支持 bot 判成“不支持”

当前 notifier：

[`src/control-plane/dsh-im-bridge.mjs`](https://github.com/THEWOLFWALKER/dsh-notifier/blob/2542a3107e7d3795e6ba5b294a7a5b82052c3431/src/control-plane/dsh-im-bridge.mjs)

`botProjection()` 读取：

```js
const accountFingerprint = str(
  description?.accountFingerprint ?? description?.fingerprint
)
```

并据此判断：

```js
checked =
  accountFingerprint !== null
  && capabilities.includes('proactive-text-checked')
```

但当前 dsh-im `4.34.2` 的真实 contract v1 返回的是：

```js
{
  version: 1,
  botId,
  channel,
  connected,
  capabilities: ['proactive-text-checked'],
  account: {
    fingerprint
  }
}
```

dsh-im 自己的 `sendChecked()` 也明确校验：

```js
if (account.account?.fingerprint !== expectedFingerprint)
  throw deliveryError('account-changed')
```

证据：

- [dsh-im delivery-service.mjs](https://github.com/xmanrui/dsh-im/blob/ecf6c85b72b213bcc937e379cf125d210d447401/plugin-src/host/delivery-service.mjs)
- [dsh-im PROACTIVE_DELIVERY.md](https://github.com/xmanrui/dsh-im/blob/ecf6c85b72b213bcc937e379cf125d210d447401/PROACTIVE_DELIVERY.md)

真实 dsh-im service 的 `description.account.fingerprint` 有值，但 notifier 读取的两个字段都是 `undefined`，所以 `checked=false`。随后 `listTargets()` / `send()` 都会把真实支持 checked delivery 的 bot 当成 `not-supported`。

---

## DSH-F02 — P1 — dsh-im bridge 测试桩复制了错误 contract，CI 正在锁定错误字段

当前测试：

[`test/v015-stage-s14-dsh-im-bridge.test.mjs`](https://github.com/THEWOLFWALKER/dsh-notifier/blob/2542a3107e7d3795e6ba5b294a7a5b82052c3431/test/v015-stage-s14-dsh-im-bridge.test.mjs)

mock `describeBot()` 返回：

```js
{
  botId,
  channel: 'telegram',
  accountFingerprint: FP,
  connected: true,
  capabilities: ['proactive-text-checked']
}
```

这恰好就是 notifier 自己错误理解的 shape。

真实 dsh-im 返回：

```js
{
  ...
  account: { fingerprint: FP }
}
```

因此当前测试能证明的是：

> notifier bridge 与 notifier 自造 mock 一致。

不能证明：

> notifier bridge 与 dsh-im v1 一致。

这是“测试自证”问题的新现实样本。

---

## DSH-F03 — P1 — Cloudflare Telegram 使用 YAML-only token 时，`secretReference` 会在 claim 落盘后把自己的 token 来源切断

当前：

[`src/cloudflare/deployment.mjs`](https://github.com/THEWOLFWALKER/dsh-notifier/blob/2542a3107e7d3795e6ba5b294a7a5b82052c3431/src/cloudflare/deployment.mjs)

token 读取：

```js
const token = () => {
  const ref = store.get('cloudflare:deployment:telegram')?.secretReference
  return String(
    (ref ? store.get(ref)?.botToken
         : outboundConfig.raw('telegram')?.botToken) ?? ''
  ).trim()
}
```

首次 `deploy()` 会先从 `outboundConfig.raw('telegram')` 读到 YAML token；但 claim 持久化后：

```js
record.secretReference =
  payload.botToken
    ? 'telegram:account'
    : (previous?.secretReference ?? 'channel:telegram:outbound')
```

YAML-only 场景没有 `channel:telegram:outbound` state row，下一次 `token()` 因为已经有 ref，就不再 fallback 到 `outboundConfig.raw()`，直接得到空串。

而同一轮 deployment 后面马上比较：

```js
fingerprint(currentToken) !== current.configSecretGeneration
```

所以这个问题可在**同一次部署**里触发，不需要等重启。

现有 Cloudflare test rig 的 `yamlRows` 是空 Map，没有覆盖 YAML-only token。

---

## DSH-F04 — P1 — Cloudflare durable job 没有实际 `failed` 终态，永久错误被永久标成 `recovery-required`

代码多处把 terminal 定义为：

```text
done
failed
cancel-requested
```

但当前 deployment service 没有任何一处写：

```js
state: 'failed'
```

所有 durable exception，只要不是显式 cancel，都进入：

```js
state: 'recovery-required'
recoveryRequired: true
```

包括确定性本地冲突，例如 credential generation mismatch / bad-request / conflict。

因此“可恢复的不确定云状态”和“确定永久失败”没有被状态机真正分开。

---

## DSH-F05 — P1 — Cloudflare 永久失败 job 可形成不可取消的 retry livelock

`deploy()` 会优先找任何非 terminal job：

```js
if (pending) return resume(pending)
```

所以 durable `recovery-required` 会被每次重试继续 resume。

但公开 `cancel()` 只处理当前内存 `job`。当一次失败已经 settle 后：

```text
job = null
durable row = recovery-required
```

此时 cancel 不会改 durable row。下一次 deploy 又会把同一 row 捞回来。

如果失败原因是永久性的，例如 secret generation 已变化，就会形成同一 durable claim 的重复冲突循环。

---

## DSH-F06 — P1 — Native “当前任务”模型与项目允许多 owner 的身份模型互相冲突

读模型：

[`src/native/private-chat-view.mjs`](https://github.com/THEWOLFWALKER/dsh-notifier/blob/2542a3107e7d3795e6ba5b294a7a5b82052c3431/src/native/private-chat-view.mjs)

```js
const ownerOf = rows =>
  rows.find(row => row?.role === 'owner') ?? null
```

多个 owner 时，会取列表里的第一位当“已确认本人”。

但动作：

[`src/native/actions.mjs`](https://github.com/THEWOLFWALKER/dsh-notifier/blob/2542a3107e7d3795e6ba5b294a7a5b82052c3431/src/native/actions.mjs)

`selectTask()` 要求：

```js
const owners = members.list()
  .filter(row => row?.role === 'owner')

if (owners.length !== 1)
  throw badRequest('请先确认使用者')
```

身份层本身允许多个 owner，只阻止删除最后一个 owner。

所以两个 owner 时：

- summary 仍会显示 verified；
- current task 读模型会挑一个 owner；
- `native.selectTask` 永远拒绝。

现有 Native boundary tests 没有 multi-owner + selectTask 用例。

---

## DSH-F07 — P1 — Recovery 收口后，成员管理 / 删除成员 / 撤销配对码在产品 UI 中失去入口

Recovery server 当前明确只保留 read-only recovery routes；member CRUD / pairing revoke 等 daily routes 已删除。

但当前 `client.js`：

```text
native.updateUser    -> 0 次调用
native.removeUser    -> 0 次调用
native.revokePairing -> 0 次调用
```

服务端方法仍存在。

当前形成：

```text
后端能力存在
Native UI 不可达
Recovery UI 已删除
```

因此 Stage 4 的 Recovery 收口同时切掉了这一段用户操作闭环。

---

## DSH-F08 — P2 — Remote `/log` owner 判断仍是 channel-scoped，不是 account-scoped

[`src/inbound/conversation.mjs`](https://github.com/THEWOLFWALKER/dsh-notifier/blob/2542a3107e7d3795e6ba5b294a7a5b82052c3431/src/inbound/conversation.mjs)

```js
return identity.list(envelope.channel).some(
  row =>
    String(row?.userId) === String(envelope.userId)
    && row?.role === 'owner'
)
```

没有比较 `accountId`。

同一 channel 中，如果 user X 在 bot/account A 是 owner、在 B 不是 owner，B 的 `/log` gate 仍可能被 A 的 owner binding 满足。

---

## DSH-F09 — P2 — approval / question 的 owner fallback 仍存在同类跨 account 借权

Approval：

[`src/approval/router.mjs`](https://github.com/THEWOLFWALKER/dsh-notifier/blob/2542a3107e7d3795e6ba5b294a7a5b82052c3431/src/approval/router.mjs)

Questions：

[`src/questions/router.mjs`](https://github.com/THEWOLFWALKER/dsh-notifier/blob/2542a3107e7d3795e6ba5b294a7a5b82052c3431/src/questions/router.mjs)

两者 owner helper 都只做：

```text
identity.list(channel)
+ userId
+ role === owner
```

没有 accountId。

Control Core 的最终 source binding 已 account-aware，但 owner fallback 资格仍可从同 channel 的另一 account 借角色。

---

## DSH-F10 — P2 — Surface allowlist 与真实 UI call graph 仍不一致

当前 Stage 4 声称 daily backend 只保留当前 UI 真实方法，但 allowlist 仍含：

```text
dshIm.status
dshIm.listBots
dshIm.listTargets
dshIm.send
```

当前 `client.js` 对 `dshIm.*` 是 0 次调用。

Native method table 还存在但当前 client 不调用：

```text
native.updateUser
native.removeUser
native.revokePairing
native.wait
```

client 的更新等待实际走的是 `surface.wait`。

所以当前只做到了：

> 服务端方法表内部自洽。

还没有做到：

> 服务端 allowlist == 当前前端真实调用集合。

---

## DSH-F11 — P2 — dsh-im `unknown` 虽不再记成 failed/ok，但 Activity 仍用成功式标题 + info level

Secondary service 现在对 ambiguous send 记录 `status: unknown`，这是正确进步。

但 Activity title 固定为：

```text
Sent via dsh-im (accepted is not delivered)
已通过 dsh-im 发送（接受 ≠ 送达）
```

而 `status:'unknown'` 不会进入 error/warn，仍落为 info。

一个“是否已发出完全不确定”的结果仍显示成“已通过 dsh-im 发送”。

---

## DSH-F12 — P2 — Native rail 的截断顺序仍可隐藏需要处理的渠道

[`src/native/read-model.mjs`](https://github.com/THEWOLFWALKER/dsh-notifier/blob/2542a3107e7d3795e6ba5b294a7a5b82052c3431/src/native/read-model.mjs)

先：

```js
const rail = all.filter(row => row.state !== 'not-set')
```

再：

```js
rail.slice(0, 12)
```

而 channel list 没有按 `needs-attention` / `connecting` 排序。

配置渠道超过 12 时，第 13 个异常渠道可以被 rail 隐藏在 12 个 ready 渠道之后。

---

## DSH-F13 — P2 — Private-only admission 对非 QQ 的未知 chatType 是 fail-open

[`src/control/session-arbiter.mjs`](https://github.com/THEWOLFWALKER/dsh-notifier/blob/2542a3107e7d3795e6ba5b294a7a5b82052c3431/src/control/session-arbiter.mjs)

QQ 未知 chatType 会进入 unknown，并被拒绝。

但非 QQ：

```js
if (type 是已知 group 值) return 'group'
return 'private'
```

也就是说未来 provider 新增未识别 chat type 时，默认被当成 private，而不是 fail-closed。

当前 Telegram / Feishu / DingTalk 的已知 shape 能正确识别，所以这是协议演进风险，不是当前已知 provider 的现成群聊绕过。

---

## DSH-F14 — P2 — `dev` 与 `main` 已双向分叉

当前 main-only commit：

```text
9d69dd7a  更新 README.md (#47)
```

只改 README，不是运行时事故。

但发布分支关系已从“dev 单向领先”变成双向 diverged，后续机械同步存在 README 反向覆盖/merge conflict 风险。

---

## DSH-F15 — P2 — Host compatibility freshness 风险进一步扩大

当前官方 `deepseek-ai/deepseek-harness` master：

```text
package version = 0.2.1-alpha.1
```

notifier compatibility 仍只声明：

```text
0.1.7-alpha.1
0.1.7-alpha.2
0.1.7-rc.1
0.1.7-rc.2
```

compatibility matrix snapshot 仍是 `2026-09-25`。

---

## DSH-F16 — P3 — Compatibility matrix 的 dsh-im 说明仍与当前 4.34.2 公开契约相反

当前 notifier 文档仍写：

```text
No current upstream contract was found for
ctx.dshIm.send/listBots/listTargets
```

但 dsh-im 4.34.2 当前公开：

```text
contractVersion: 1
describeBot
sendChecked
send
listTargets
listBots
```

而 notifier 自己已经写了对应 bridge。

当前是：

```text
代码承认真实 contract
测试声称 contract v1
兼容文档仍说没找到 contract
```

三套事实冲突。

---

# 3. 修复确实做对的部分

- Runtime outbound freeze 回归：dev 已真正改掉。
- Cloudflare secret duplication：deployment metadata 已不再直接持久 botToken/gatewayKey。
- dsh-im unsafe 普通 send fallback：已删除，要求 checked contract。
- 猜测式 dsh-im importer：整个删除。
- Private-only group admission：主链已接通，不是只写测试。
- current-task authority：已升级为 account-aware principal。
- Native channel UX：已有 brand / 用户名 / usage / group / 四态用户状态 / secret presence-only。
- Recovery backend：daily CRUD 确实从 Recovery 路由表删除。

---

# 4. 当前最值得警惕的共同模式

## 4.1 修复测试仍会复制实现假设

本轮最典型：

```text
真实 dsh-im:
account.fingerprint

notifier mock:
accountFingerprint

notifier implementation:
accountFingerprint
```

测试全绿，但三者只有后两者彼此一致。

## 4.2 account-aware 迁移仍未贯穿所有状态域

已 account-aware：

```text
Identity
current-task principal
Control Core source
部分 delivery evidence
```

仍 account-blind：

```text
task-selection pending
approval owner fallback
question owner fallback
remote /log owner gate
dedup
reply throttle
```

## 4.3 Recovery-only 收口产生“后端存在 / UI 不可达”

当前：

```text
native.updateUser       后端有 / 前端无
native.removeUser       后端有 / 前端无
native.revokePairing    后端有 / 前端无
dshIm.*                 后端有 / 前端无
```

## 4.4 Cloudflare recovery 把“不确定”与“确定失败”混成一个 durable 状态

当前所有非 cancel 异常统一进 `recovery-required`，但代码预留的 `failed` 状态从不写入。

---

# 5. 本轮新问题索引

| ID | 严重度 | 主题 |
|---|---|---|
| DSH-F01 | P1 | dsh-im account fingerprint contract 接错 |
| DSH-F02 | P1 | dsh-im mock 测试锁定错误 contract |
| DSH-F03 | P1 | Cloudflare YAML-only token reference 自断 |
| DSH-F04 | P1 | durable job 无实际 failed 终态 |
| DSH-F05 | P1 | recovery-required 永久 job retry/cancel livelock |
| DSH-F06 | P1 | Native current-task 与 multi-owner 身份模型冲突 |
| DSH-F07 | P1 | Recovery 收口后成员管理/撤销配对 UI 断链 |
| DSH-F08 | P2 | `/log` owner gate 忽略 accountId |
| DSH-F09 | P2 | approval/question owner fallback 忽略 accountId |
| DSH-F10 | P2 | Surface allowlist 与真实前端 call graph 漂移 |
| DSH-F11 | P2 | dsh-im unknown 仍展示成功式 Activity |
| DSH-F12 | P2 | Native rail 截断可隐藏异常渠道 |
| DSH-F13 | P2 | 非 QQ 未知 chatType 在 private-only 策略下 fail-open |
| DSH-F14 | P2 | dev/main 双向分叉 |
| DSH-F15 | P2 | DSH compatibility freshness 进一步扩大 |
| DSH-F16 | P3 | compatibility matrix 的 dsh-im 事实已过时 |

---

# 6. 当前验收判断

这一批修复**确实有明显结构进步**，不是假修。

但当前 dev 仍不能视为“上一轮问题全部闭环”。

当前 CI green 能证明：

> 当前仓库定义的测试 / DOM / release guard / channel matrix 自洽。

不能证明：

> 真实 dsh-im v1 contract、Cloudflare YAML-only 路径、多 owner Native 路径、跨 account owner fallback 已正确。

---

# 7. 证据入口

当前 dsh-notifier：

- `https://github.com/THEWOLFWALKER/dsh-notifier/tree/2542a3107e7d3795e6ba5b294a7a5b82052c3431`
- `https://github.com/THEWOLFWALKER/dsh-notifier/commit/2542a3107e7d3795e6ba5b294a7a5b82052c3431`

关键文件：

- `https://github.com/THEWOLFWALKER/dsh-notifier/blob/2542a3107e7d3795e6ba5b294a7a5b82052c3431/src/control-plane/dsh-im-bridge.mjs`
- `https://github.com/THEWOLFWALKER/dsh-notifier/blob/2542a3107e7d3795e6ba5b294a7a5b82052c3431/test/v015-stage-s14-dsh-im-bridge.test.mjs`
- `https://github.com/THEWOLFWALKER/dsh-notifier/blob/2542a3107e7d3795e6ba5b294a7a5b82052c3431/src/cloudflare/deployment.mjs`
- `https://github.com/THEWOLFWALKER/dsh-notifier/blob/2542a3107e7d3795e6ba5b294a7a5b82052c3431/src/native/actions.mjs`
- `https://github.com/THEWOLFWALKER/dsh-notifier/blob/2542a3107e7d3795e6ba5b294a7a5b82052c3431/src/native/private-chat-view.mjs`
- `https://github.com/THEWOLFWALKER/dsh-notifier/blob/2542a3107e7d3795e6ba5b294a7a5b82052c3431/src/native/read-model.mjs`
- `https://github.com/THEWOLFWALKER/dsh-notifier/blob/2542a3107e7d3795e6ba5b294a7a5b82052c3431/src/inbound/conversation.mjs`
- `https://github.com/THEWOLFWALKER/dsh-notifier/blob/2542a3107e7d3795e6ba5b294a7a5b82052c3431/src/approval/router.mjs`
- `https://github.com/THEWOLFWALKER/dsh-notifier/blob/2542a3107e7d3795e6ba5b294a7a5b82052c3431/src/questions/router.mjs`
- `https://github.com/THEWOLFWALKER/dsh-notifier/blob/2542a3107e7d3795e6ba5b294a7a5b82052c3431/src/control/session-arbiter.mjs`
- `https://github.com/THEWOLFWALKER/dsh-notifier/blob/2542a3107e7d3795e6ba5b294a7a5b82052c3431/src/inbound/store.mjs`
- `https://github.com/THEWOLFWALKER/dsh-notifier/blob/2542a3107e7d3795e6ba5b294a7a5b82052c3431/src/interaction/ledger.mjs`
- `https://github.com/THEWOLFWALKER/dsh-notifier/blob/2542a3107e7d3795e6ba5b294a7a5b82052c3431/src/control-plane/config-portability.mjs`
- `https://github.com/THEWOLFWALKER/dsh-notifier/blob/2542a3107e7d3795e6ba5b294a7a5b82052c3431/src/control-plane/remote-url.mjs`
- `https://github.com/THEWOLFWALKER/dsh-notifier/blob/2542a3107e7d3795e6ba5b294a7a5b82052c3431/src/admin/server.mjs`
- `https://github.com/THEWOLFWALKER/dsh-notifier/blob/2542a3107e7d3795e6ba5b294a7a5b82052c3431/src/control-surface/surface-allowlist.mjs`
- `https://github.com/THEWOLFWALKER/dsh-notifier/blob/2542a3107e7d3795e6ba5b294a7a5b82052c3431/docs/developer/compatibility-matrix.md`

竞品契约参考（仅对照）：

- `https://github.com/xmanrui/dsh-im/blob/ecf6c85b72b213bcc937e379cf125d210d447401/plugin-src/host/delivery-service.mjs`
- `https://github.com/xmanrui/dsh-im/blob/ecf6c85b72b213bcc937e379cf125d210d447401/PROACTIVE_DELIVERY.md`

DSH Host operator/admission 参考：

- `https://github.com/deepseek-ai/deepseek-harness/blob/5badb15009ae1756c3afe0ae0cef1faafc290ccc/packages/client/connection/src/rpc-host.ts`
- `https://github.com/deepseek-ai/deepseek-harness/blob/5badb15009ae1756c3afe0ae0cef1faafc290ccc/packages/client/connection/README.md`
