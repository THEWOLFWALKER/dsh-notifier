# dsh-notifier dev 修复复核 + 第二轮继续 Review

> 审查对象：`THEWOLFWALKER/dsh-notifier` **dev**  
> 当前 HEAD：`2542a3107e7d3795e6ba5b294a7a5b82052c3431`（`docs(workstream): record P5 commit`）  
> 对比上一轮基线：`c890d2c154f237b255ac925e00ab019016692de0` → 当前 dev，共 **16 个提交**。  
> 最新 GitHub Actions：run #187 **success**。当前记录：Node **2447/2447**、DOM **41/41**。  
> 本报告只汇报当前仍成立、修复后新出现、以及证据仍未闭环的问题；**不提供修复方案**。

## 结论

这次修复是实质性的，上一轮多个核心 P1 已确认消失；但当前 dev 仍检出 **201 项**当前问题/隐患，其中 **P1 69 项、P2 130 项、P3 2 项**。

特别需要区分：当前实现完成的是“**入站控制只允许私聊**”，并没有完成“**项目不再支持任何群聊**”；出站群聊通知仍明确保留。

## 已确认修掉的上一轮核心问题（不计入本轮问题数）

| 项目 | 证据 | 当前复核 |
|---|---|---|
| Advanced Console 日常写操作面 | `31352579 / 6c9e72c` | 已收敛为 Recovery read-only，旧日常 sessions/bindings/members/pairing RPC 被移除/拦截。 |
| Recovery server 可被 caller 绑定 0.0.0.0 | `3154f618` | factory 现硬编码 127.0.0.1，并有 override 回归测试。 |
| Native selectTask 漏注册 | `e70b42a0` | method table 已注册 native.selectTask 并锁 exact-set invariant。 |
| Runtime state transition 每次推进 epoch | `6f33b87e` | 普通 update 不再推进 generation；replace/remove/replaceAll 才推进。 |
| 已识别群聊进入控制链 | `7d2cc85c` | privateControlAdmission 已在 identity/task routing 前拒绝已识别 group。 |
| 无显式任务自动挑最近/唯一会话 | `Stage 3` | agent-router 已移除 implicit latest/unique fallback。 |
| current-task 绑定不含 accountId | `6f33b87e` | 键已升级为 channel+accountId+userId。 |
| Cloud job 纯进程内、重启即丢 | `6f33b87e / 845699b3` | 已有 durable claim/checkpoint/startup recovery。 |
| Cloud deployment metadata 直接重复保存 botToken/gatewayKey | `6f33b87e` | record 改为 secretReference/fingerprint。 |
| dsh-im 猜测式 API/import fallback | `128ff9a9` | 仅接受 checked contract v1，guessed importer 已删。 |
| 未发货 cloud-storage fake/未来契约 | `6b9109b3` | 已从 package/docs 删除。 |
| Pairing mint/revoke 锁外整表覆盖 | `当前 pairing.mjs` | 代码已走 commitCodes + fresh transaction；仅文档仍旧。 |
| route:sessions sibling lost update | `Stage 3` | router/session-registry 已在 transaction fresh merge。 |
| Native 旧 daily controller | `6c9e72c` | 旧 browser controller/state/nav 已删除。 |

## 本轮统计

| 维度 | 数量 |
|---|---:|
| 总计 | **201** |
| P1 | **69** |
| P2 | **130** |
| P3 | **2** |
| 残留 | 138 |
| 新发现 | 51 |
| 证据缺口 | 10 |
| 文档漂移 | 2 |

## 当前问题清单

### A. 产品边界与 Native v2

| # | 级别 | 状态 | 类型 | 位置 | 当前问题 | 影响 |
|---:|:---:|:---:|---|---|---|---|
| 1 | P1 | 残留 | 产品偏差 | `HANDOFF.md + src/inbound/qq-gw.mjs` | 当前只禁止入站群聊控制；交接文档仍明确保留 outbound group notifications，QQ 仍有 notifyGroups 与 /v2/groups 路径。 | 与项目“后续仅私聊、不再支持任何群聊”的既定边界不一致。 |
| 2 | P1 | 新发现 | 状态错误 | `src/native/channel-view.mjs::rows` | channels.list() 抛错被 catch 成空数组。 | 真实读取故障会伪装成“尚未配置渠道”。 |
| 3 | P1 | 新发现 | 状态错误 | `src/native/channel-view.mjs::memberRows` | members.list() 抛错被 catch 成空数组。 | 真实成员故障会伪装成“没有使用者/默认账号”。 |
| 4 | P1 | 新发现 | 状态错误 | `src/native/private-chat-view.mjs::safeList` | members/questions/tasks 任一读源抛错都返回 []。 | 私聊页把系统故障伪装成无成员、无待处理、无任务。 |
| 5 | P1 | 新发现 | 状态错误 | `src/native/read-model.mjs::storageView` | storageStatus() 抛错回退 {}，随后 canSave=true。 | 无法判断存储状态时反而宣称“设置会保存”。 |
| 6 | P2 | 新发现 | 状态错误 | `src/native/read-model.mjs::isEnabled` | 读取 channels 失败时返回 false。 | 真实私聊故障会显示成“私聊未开启”。 |
| 7 | P1 | 新发现 | 状态聚合 | `src/native/channel-view.mjs::channelState` | 通知和私聊同时配置时，只要任一方向 active 就可进入 ready。 | 一个方向已坏、另一个方向正常时，整体状态可掩盖局部故障。 |
| 8 | P2 | 新发现 | 投影错误 | `src/native/channel-view.mjs::accountIdsOf` | 账号集合只从 member rows 推导；读不到成员时强制补 default。 | 真实非 default 账号可被投影成 default。 |
| 9 | P2 | 新发现 | 隐私/UX | `src/native/channel-view.mjs::accountView` | 非 default accountId 直接进入浏览器 payload 并作为 displayName。 | 内部账号标识成为浏览器和 UI 可见文本。 |
| 10 | P2 | 新发现 | 静默截断 | `src/native/read-model.mjs` | 已配置渠道 rail 上限固定 12，而产品支持 28 个出站渠道。 | 同时配置超过 12 个渠道时必然截断。 |
| 11 | P1 | 新发现 | 契约失效 | `client.js` | 服务端返回 snapshot.truncated，但当前客户端没有任何 truncated 消费逻辑。 | 服务端虽声明显式截断，用户端实际上仍静默丢数据。 |
| 12 | P1 | 新发现 | 计数错误 | `client.js::Overview` | 待处理横幅使用 native.pending.length，而 pending 本身最多 20。 | 待处理超过 20 条时主页会低报真实数量。 |
| 13 | P2 | 新发现 | API契约 | `src/native/read-model.mjs::pending` | native.pending 截到 20 条但不返回 total/truncated。 | 单独调用时调用方不知道还有更多事项。 |
| 14 | P2 | 新发现 | 静默截断 | `src/native/private-chat-view.mjs::taskCandidates` | 私聊首次向导候选任务固定 slice(0,10)，没有 total/truncated。 | 活跃任务超过 10 个时其余任务消失。 |
| 15 | P2 | 新发现 | UX | `client.js::PrivateChat` | 任务选择页没有“还有更多”提示。 | TASK_CAP 截断对用户不可见。 |
| 16 | P1 | 新发现 | 跨层冲突 | `private-chat-view.mjs + actions.mjs::selectTask` | 读模型找到任意第一个 owner 就 verified=true；写动作要求 owners.length===1。 | 存在两个 owner 行时 UI 显示已确认，但所有任务选择都失败。 |
| 17 | P2 | 新发现 | ID碰撞 | `src/native/private-chat-view.mjs::users` | 成员缺 key 时仍生成 opaqueUserId(空字符串)。 | 多个损坏成员会得到相同浏览器 ID。 |
| 18 | P2 | 新发现 | ID碰撞 | `src/native/private-chat-view.mjs::setup` | pending member 缺 key 时也用空字符串生成 ID。 | 多个损坏待确认身份不可区分。 |
| 19 | P2 | 新发现 | 不可操作项 | `src/native/private-chat-view.mjs::memberKeyOf` | UI 可展示缺 key 的成员，但 memberKeyOf 明确跳过空 key。 | 会出现“看得到但永远无法操作”的成员行。 |
| 20 | P2 | 新发现 | 信息暴露 | `src/native/private-chat-view.mjs::titleOf` | task 无 workspace 时直接把完整 taskRef 作为标题。 | 内部任务引用进入浏览器与 UI。 |
| 21 | P2 | 新发现 | 快照不一致 | `src/native/read-model.mjs::snapshot` | privateChat.summary 与 pendingItems 分别重复读取上游，不在同一快照。 | 数据变化时 pendingCount、列表、verified/currentTask 可彼此矛盾。 |
| 22 | P1 | 新发现 | 参数校验 | `src/native/actions.mjs::removeChannel` | direction 只有精确 inbound 才走入站，其他任意值都当 outbound。 | 未知/拼错 direction 可能删除错误方向配置。 |
| 23 | P1 | 新发现 | 审计语义 | `src/native/actions.mjs::testChannel` | 测试 unknown 仍记 channel-test-ok/status:ok；只有 failed 才记失败。 | 结果未知在活动记录里被写成成功。 |
| 24 | P2 | 残留 | 测试错位 | `src/native/actions.mjs::testChannel` | desired config 与 active runtime diverged 时，测试对象不一定是当前实际运行配置。 | 测试成功不能证明正在运行的 runtime 正常。 |
| 25 | P1 | 残留 | 世代污染 | `src/control-surface/health.mjs::recordTest` | 测试健康证据不携带 runtime generation。 | hot replace 竞速时旧配置测试结果可落入新 runtime 健康。 |
| 26 | P2 | 新发现 | 审计语义 | `src/native/actions.mjs::settlePending` | alreadyHandled 与实际 settle 都会写 question-settled/status:ok。 | “别人已经处理”会伪装成本次成功处理。 |
| 27 | P2 | 新发现 | 观测噪声 | `src/native/actions.mjs save/remove inbound` | saved:false / deleted:false 也会 touch revision 并写 activity。 | 失败/无变化同样制造成功风格的更新信号。 |
| 28 | P2 | 新发现 | 结果忽略 | `src/native/actions.mjs member actions` | 成员动作主要只看是否抛错，不统一检查 false/失败返回。 | authority 若用返回值表达失败，Native 仍可能返回成功。 |
| 29 | P2 | 新发现 | 多身份冲突 | `src/native/actions.mjs::selectTask` | 任务选择要求全局恰好一个 owner。 | 同一 owner 在多个渠道/账号有多条 owner 绑定时 Native 无法选任务。 |
| 30 | P2 | 残留 | 观测丢失 | `src/native/actions.mjs` | revision/activity 写失败全部吞掉。 | 业务已成功时客户端仍可能没有更新/活动证据。 |

### B. Control Core / 私聊安全边界

| # | 级别 | 状态 | 类型 | 位置 | 当前问题 | 影响 |
|---:|:---:|:---:|---|---|---|---|
| 31 | P1 | 残留 | fail-open | `src/control/session-arbiter.mjs::chatScopeOf` | 非 QQ 只识别少数群聊枚举；其他未知/空 chatType 一律 private。 | 新 provider 群类型或缺字段可能绕过仅私聊入口。 |
| 32 | P1 | 残留 | fail-open | `src/control/session-arbiter.mjs::privateControlAdmission` | 只有 QQ unknown chat scope 会 fail-closed。 | 不同 provider 的私聊安全边界强度不一致。 |
| 33 | P1 | 残留 | fail-open | `src/control/entry.mjs::paired` | identity 为 null/undefined 时直接 paired=true。 | 身份服务装配遗漏时配对层完全失效。 |
| 34 | P1 | 残留 | 账号隔离 | `src/control/entry.mjs::paired` | paired 仅比较 channel+userId，不比较 accountId。 | 同渠道多账号下同 userId 可通过这一层。 |
| 35 | P1 | 残留 | 去重碰撞 | `src/control/entry.mjs::eventIdOf` | 缺 provider eventId 时合成 ID 不包含 accountId/sessionId。 | 不同账号/会话在同毫秒可共用 dedup key。 |
| 36 | P2 | 残留 | 编码碰撞 | `src/control/entry.mjs::eventIdOf` | 合成 ID 用冒号直接拼字段，分量不转义。 | 字段含冒号时 tuple 编码存在碰撞。 |
| 37 | P1 | 残留 | 有效期放宽 | `src/control/entry.mjs::pendingMeta` | pending 缺时间戳时合成 now-1 与新的 10 分钟 expiresAt。 | 损坏/旧记录会重新获得有效窗口。 |
| 38 | P2 | 残留 | 策略版本放宽 | `src/control/entry.mjs::pendingMeta` | policyVersion 缺失时最终可回落字面量 1。 | 旧/损坏记录可能被当成当前策略。 |
| 39 | P2 | 残留 | 来源伪装 | `src/control/entry.mjs::pendingMeta` | source 缺失默认 mobile。 | 不完整来源被审计成明确 mobile。 |
| 40 | P1 | 残留 | 策略降级 | `src/control/entry.mjs resolver selection` | 注入两个不同 resolver 时静默禁用动态 resolver，回落 base policy。 | 预期会话级限制可能被悄悄丢弃。 |
| 41 | P1 | 残留 | 策略降级 | `src/control/entry.mjs::resolverOverlay` | 畸形 overlay 只记 ignored，随后继续使用 base policy。 | 坏掉的更严格 overlay 可导致权限面扩大。 |
| 42 | P1 | 残留 | 异步契约 | `src/control/session-arbiter.mjs::handle` | onSettle 按同步函数处理，Promise 会立即被视为成功。 | 异步 reject 捕不到，可出现已接受但真实结算失败。 |
| 43 | P2 | 残留 | 内存 | `src/control/session-arbiter.mjs` | settled 是无容量/TTL Set。 | 长生命周期会话持续积累 eventId。 |
| 44 | P2 | 残留 | 静默截断 | `src/control/session-arbiter.mjs::normalizeApprovalMembers` | approvalMembers 超过 64 直接截断。 | 第 65 个以后权限无显式失败。 |
| 45 | P1 | 残留 | 默认权限 | `src/control/session-arbiter.mjs::normalizeSessionPolicy` | 缺失 capabilities 时 observe/approve/stop 默认 true。 | 部分损坏策略可能比预期更宽。 |
| 46 | P2 | 残留 | 授权寿命 | `src/control/session-arbiter.mjs` | expiresAt 默认 null。 | 长期 session 可长期保留控制授权。 |
| 47 | P2 | 残留 | 注册覆盖 | `src/control/entry.mjs::register` | 同 command 再注册会覆盖旧 handler。 | 重复装配时 owner 取决于最后注册者。 |
| 48 | P2 | 残留 | 内部旁路 | `src/control/entry.mjs` | input 自带 settle 可替代注册 spec.settle。 | 内部调用者可以改变规范结算路径。 |
| 49 | P2 | 残留 | 重放窗口 | `src/control/handled-events.mjs` | handled event 仍只在进程内。 | 重启后该层已处理 ID 全部丢失。 |
| 50 | P2 | 残留 | 重放窗口 | `src/control/handled-events.mjs` | 去重有固定 TTL。 | TTL 后同一 provider event 可再次进入处理链。 |
| 51 | P2 | 残留 | 重放窗口 | `src/control/handled-events.mjs` | 去重表有容量上限。 | 高流量可在 TTL 前提前淘汰旧 eventId。 |

### C. 路由 / Conversation / 当前任务

| # | 级别 | 状态 | 类型 | 位置 | 当前问题 | 影响 |
|---:|:---:|:---:|---|---|---|---|
| 52 | P1 | 残留 | fail-silent | `src/routing/agent-router.mjs::safeGet` | store 读取异常统一回落 fallback/空表。 | 真实持久化故障可表现为没有绑定/没有默认路由。 |
| 53 | P2 | 残留 | 数据丢失 | `src/routing/agent-router.mjs::readMap` | 损坏 route 表被当成 {}。 | 后续合法写可能以空表为基底丢掉畸形 sibling 数据。 |
| 54 | P1 | 新发现 | 账号隔离 | `src/routing/agent-router.mjs::resolveInbound` | accountId 缺省仍是 default。 | 调用链遗漏 accountId 时会落入 default 绑定空间而不是拒绝。 |
| 55 | P2 | 新发现 | 规范化不一致 | `src/routing/agent-router.mjs` | current-task key 会 lower/trim channel，但 route:channels 默认路由读取使用原始 channel。 | 大小写/空白漂移可导致显式默认路由查不到。 |
| 56 | P2 | 新发现 | 裂键 | `src/routing/agent-router.mjs::setChannelDefault` | 只校验非空，不把 channel/agentKey trim 后存储。 | 带前后空白的等价值可形成不同 route key。 |
| 57 | P2 | 新发现 | 裂键 | `src/routing/agent-router.mjs::setAgentBinding` | agent/workspace key 同样保留原始空白。 | 同名工作区可被分裂成多条记录。 |
| 58 | P2 | 新发现 | 裂键 | `src/routing/agent-router.mjs::normalizeAgentsTable` | 整表替换也保留原始 key。 | CLI/Admin 整表写与其他路径可形成不同键语义。 |
| 59 | P2 | 新发现 | 宽容误解析 | `src/routing/agent-router.mjs::normalizeQuiet` | 字符串仅 true 视为 true，其他任意字符串都静默变 false。 | 拼错配置不会报错而会改变静音语义。 |
| 60 | P2 | 残留 | 兼容半提交 | `src/routing/agent-router.mjs::replaceBindings` | legacy/no-transact store 同时替换两张表仍可能部分提交。 | 函数返回失败但状态可能已经写了一半。 |
| 61 | P2 | 残留 | copy-on-read失效 | `src/routing/agent-router.mjs::deepCopyPlain` | JSON clone 失败时直接返回原 value。 | 非 JSON/损坏数据下 snapshot 可泄露 live 引用。 |
| 62 | P2 | 残留 | 双重行为 | `src/inbound/conversation.mjs::handleCommand` | 未知 /command 会先回未识别，再返回 false 让原文本继续进入模型。 | 一次输入同时产生控制回执与模型消息。 |
| 63 | P2 | 残留 | 命令歧义 | `src/inbound/conversation.mjs` | 普通文本以 ! 开头仍可触发 steer。 | 代码片段/感叹文本与控制命令共用前缀。 |
| 64 | P2 | 残留 | 本地化 | `src/inbound/conversation.mjs` | 当前仍存在硬编码中文失败文案。 | 英文环境出现混合语言。 |
| 65 | P2 | 残留 | 顺序语义 | `src/inbound/conversation.mjs::fireAsync` | 总线无法 await 的投递继续 fire-and-forget。 | 下载/路由耗时不同的消息不保证最终注入顺序。 |
| 66 | P2 | 残留 | 降级改变语义 | `src/inbound/conversation.mjs registry/router wrappers` | registry/router 异常被吞成 undefined/降级链。 | 内部故障可改变目标会话却只表现成无路由。 |
| 67 | P2 | 残留 | 内部ID暴露 | `src/inbound/conversation.mjs commands` | /status、/agent、/tasks 等会在私聊返回 session/task 引用或前缀。 | 聊天记录/截图包含内部标识。 |

### D. 通知路由 / Runtime / Health

| # | 级别 | 状态 | 类型 | 位置 | 当前问题 | 影响 |
|---:|:---:|:---:|---|---|---|---|
| 68 | P1 | 残留 | 配置语义 | `src/routing.mjs::routeTargets` | 某 level 显式空数组仍走 entries.length===0 -> 广播全部渠道。 | 无法表达“这个级别不发送”。 |
| 69 | P1 | 残留 | 配置语义 | `src/routing.mjs::resolveRouting` | 未知 channel 名仍会把 routing 标成 configured。 | 拼写错误可把该 level 变成 0 个目标而非配置错误。 |
| 70 | P1 | 残留 | 重复发送 | `src/routing.mjs::routeTargets` | 同 level 重复 channel entry 不去重。 | 重复配置会真实重复发送。 |
| 71 | P1 | 残留 | 消息覆写 | `src/routing.mjs` | entry overrides 不限键，直接浅合并 message。 | 路由项可覆盖 title/content/level/group 等核心字段。 |
| 72 | P2 | 残留 | 静默归一 | `src/routing.mjs::normalizeLevel` | 未知 level 静默归 active。 | 拼写错误被隐藏。 |
| 73 | P1 | 残留 | 参数错误 | `src/routing.mjs::retryPolicyOf` | retry.attempts 没有数值/整数校验，非法字符串可变 NaN。 | sendWithRetry 循环可一次都不执行并抛 undefined。 |
| 74 | P2 | 残留 | 参数错误 | `src/routing.mjs::retryPolicyOf` | 非法 retry.backoffMs 可变 NaN。 | 退避可退化成无等待。 |
| 75 | P2 | 残留 | 可用性 | `src/routing.mjs::sendWithRetry` | provider retryAfterMs 无最大上限。 | 异常值可让发送 Promise 挂很久。 |
| 76 | P2 | 残留 | 惊群 | `src/routing.mjs::sendWithRetry` | 指数退避无 jitter。 | 多实例故障时易同步重试。 |
| 77 | P2 | 残留 | 生命周期 | `src/routing.mjs::sendWithRetry` | retry sleep 没有 AbortSignal。 | 关闭/取消期间仍需等退避。 |
| 78 | P2 | 残留 | 重试分类 | `src/routing.mjs::retryAdviceOf` | 未知错误默认 SAFE。 | 未标 noRetry 的确定性认证/参数错误会被重试。 |
| 79 | P1 | 残留 | 世代误推进 | `src/runtime/channel-manager.mjs::replaceAll` | replaceAll 对所有 live type 推进 epoch，不判断该 runtime 是否实际变化。 | 批量收敛可无条件清空各渠道旧健康证据。 |
| 80 | P1 | 残留 | 迟到状态 | `src/runtime/channel-manager.mjs::setState` | generation 仅在调用方提供时做 fence。 | 未携 generation 的迟到异步状态仍可覆盖当前状态。 |
| 81 | P2 | 残留 | revision fence | `src/runtime/channel-manager.mjs::update` | appliedRevision 只在 incoming revision 存在时检查。 | 无 revision update 可覆盖已有较新 revision 状态。 |
| 82 | P2 | 残留 | 观察重复 | `src/runtime/channel-manager.mjs::subscribe` | 每个 manager listener 都再向 source 注册，同时 manager 也发 runtime event。 | 观察者面对两类事件，source listener 数线性增长。 |
| 83 | P1 | 残留 | 健康语义 | `src/control-surface/health.mjs` | provider accepted 仍足以把渠道标 healthy。 | 平台接受请求被提升为整体健康。 |
| 84 | P2 | 残留 | 陈旧健康 | `src/control-surface/health.mjs` | 成功证据默认保留 24h，且无主动探测。 | 渠道早已断开但无新发送时仍可能 healthy。 |
| 85 | P2 | 残留 | 重启失忆 | `src/control-surface/health.mjs` | 健康历史纯进程内。 | 重启会清除近期失败/unknown。 |
| 86 | P2 | 残留 | 时间污染 | `src/control-surface/health.mjs::recordSend` | 可解析的未来 record.time 不做上限钳制。 | 未来时间可长期压过正常证据。 |
| 87 | P2 | 残留 | 窗口消耗 | `src/control-surface/health.mjs::recordSend` | confirmed send 会同时插入 accepted 与 delivered 两条记录。 | 一次真实发送占两个 history 槽。 |
| 88 | P2 | 残留 | 世代边界 | `src/control-surface/health.mjs::recordSend` | 只拒绝 carried epoch < current，未来 epoch 不拒绝也不推进。 | 观察者乱序时可短暂接纳不属于当前世代的证据。 |
| 89 | P1 | 残留 | 生命周期异步 | `src/adapters/sender.mjs` | stateful start/stop/dispose 经同步 invoke 调用，不 await Promise。 | 异步生命周期 rejection 无法被当前 try/catch 正确处理。 |
| 90 | P2 | 残留 | 契约漂移 | `src/adapters/sender.mjs` | 注释写 retire 后旧 resolved 可重建新 epoch；代码 WeakSet 永久拒绝旧 resolved。 | 实现与维护说明相反。 |
| 91 | P1 | 残留 | 结果分类 | `src/adapters/sender.mjs late result` | provider 可能已产生外部效果后，retire 把晚到结果改成 CHANNEL_RETIRED + noRetry。 | 上层更像确定失败处理，但外部效果可能已经发生。 |
| 92 | P2 | 残留 | 诊断失真 | `src/adapters/sender.mjs::activeCount` | retire 立即递减 activeCount，即使异步清理实际仍未完成/失败。 | 资源统计可能比真实生命周期更乐观。 |

### E. state.json / 持久化 / 并发

| # | 级别 | 状态 | 类型 | 位置 | 当前问题 | 影响 |
|---:|:---:|:---:|---|---|---|---|
| 93 | P1 | 残留 | 引用逃逸 | `src/inbound/store.mjs::get` | get() 仍直接返回 state[key] 对象引用。 | 调用方可绕过事务与落盘直接修改进程内 canonical state。 |
| 94 | P1 | 残留 | 性能 | `src/inbound/store.mjs` | 核心 store 仍大量使用同步 fs API。 | state IO 直接阻塞 DSH Node 事件循环。 |
| 95 | P1 | 残留 | 性能 | `src/inbound/store.mjs::acquireLock` | 锁竞争用 Atomics.wait 同步 sleep。 | 并发写时宿主主线程可停顿数百毫秒。 |
| 96 | P1 | 残留 | 写放大 | `src/inbound/store.mjs::transact` | 单键变化仍序列化并 rename 整个 state.json。 | state 增长后高频小写的 IO/CPU 放大明显。 |
| 97 | P1 | 残留 | durability语义 | `src/inbound/store.mjs::transact` | temp+rename 后直接 durable:true，没有 fsync 文件和目录。 | durable 不等价于掉电级持久化保证。 |
| 98 | P1 | 残留 | 隔离失效 | `src/inbound/store.mjs::cloneState` | JSON clone 失败退化浅拷贝。 | 嵌套引用可穿透 detached draft 边界。 |
| 99 | P2 | 残留 | 跨进程陈旧 | `src/inbound/store.mjs::size` | size() 不 refreshIfChanged。 | 其他进程写 state 后 size 可返回旧值。 |
| 100 | P2 | 残留 | 返回语义 | `src/inbound/store.mjs::delete` | delete() 返回调用前 existed，不表达事务是否成功。 | 误用时落盘失败也可被当成删除成功。 |
| 101 | P2 | 残留 | 错误不可区分 | `src/inbound/store.mjs::sweepPrefix` | 无过期数据和事务失败都返回 0。 | 清理失败从返回值不可识别。 |
| 102 | P2 | 残留 | 跨进程检测 | `src/inbound/store.mjs::refreshIfChanged` | 变化主要依赖 mtimeMs。 | 低时间分辨率/同时间戳写入存在漏刷风险。 |
| 103 | P1 | 残留 | 状态复活 | `src/inbound/store.mjs::transact` | 运行中 state 文件被外部删除时用内存 state 作为 base 重建。 | 管理员删除 state.json 重置可能把旧状态重新写回来。 |
| 104 | P1 | 残留 | 权限 | `src/inbound/store.mjs` | chmod 0600 失败仍只告警并继续。 | 凭证文件实际权限可能比安全假设更宽。 |
| 105 | P2 | 残留 | 取证缺口 | `src/inbound/store.mjs` | 损坏文件超过 8MB 时跳过 forensic copy。 | 最大型异常损坏没有自动副本。 |
| 106 | P2 | 残留 | 备份陈旧 | `src/inbound/store.mjs::backup` | 同 label 已有历史 backup 就直接复用。 | 后续同 label 迁移的备份可能不是本次操作前状态。 |
| 107 | P2 | 残留 | 资源上限 | `src/inbound/store.mjs` | state.json 没有全局字节上限。 | 漏掉局部 cap 的业务域可拖慢整个 store。 |
| 108 | P2 | 残留 | 锁恢复 | `src/inbound/store.mjs::recoverableLock` | 锁 owner 只用 PID 探活；PID 被 OS 复用后陈锁会被当活锁。 | 写路径可能长期 STATE_BUSY。 |
| 109 | P1 | 残留 | 恢复覆盖 | `src/inbound/store.mjs::transact` | 运行期磁盘损坏会移走坏文件并用当前内存 state 重建。 | 内存若陈旧，恢复会固化陈旧快照。 |
| 110 | P1 | 新发现 | 兼容语义错误 | `src/inbound/store.mjs::mergeDurable` | 无 transact 的 legacy 分支直接 setDurable(key,patch)，并没有 merge 原值。 | 兼容分支会丢兄弟字段，违背函数字段合并契约。 |
| 111 | P2 | 残留 | schema | `src/inbound/store.mjs` | store 顶层只验证 JSON object，不做全局 per-key schema。 | 旧版/手工畸形值延迟到业务层才爆。 |
| 112 | P2 | 新发现 | 恢复语义不一致 | `src/inbound/store.mjs::loadBoot/tryLoad` | 启动时空文件视为正常空态；运行期读空文件则视为 corrupt。 | 同一磁盘状态在启动/运行中得到不同结论。 |
| 113 | P2 | 新发现 | 错误分类 | `src/inbound/store.mjs::acquireLock` | 创建/打开 lockfile 的各种异常统一进入抢锁重试。 | 权限/文件系统错误可能先表现成锁忙。 |
| 114 | P2 | 残留 | 故障域 | `src/inbound/store.mjs` | 身份、路由、凭证、interaction、Cloud job、cursor 等仍共享一个 state.json。 | 单文件损坏/权限/锁争用同时影响多个业务域。 |
| 115 | P2 | 残留 | 兼容语义 | `src/inbound/store.mjs::setDurable/deleteDurable` | legacy store 仍允许用 undefined 返回或简单 delete 调用推断 durable 成功。 | 非标准 store 可获得过于乐观的持久化结论。 |

### F. Cloudflare / 自动部署 / Tunnel

| # | 级别 | 状态 | 类型 | 位置 | 当前问题 | 影响 |
|---:|:---:|:---:|---|---|---|---|
| 116 | P1 | 残留 | 回滚不完整 | `src/cloudflare/deployment.mjs::link/unbind` | Telegram link 写 apiBase/gatewayKey/botToken/可能 chatId，但 backup/恢复范围并非完全对称。 | 解绑不保证恢复部署前全部 Telegram 凭证与目标状态。 |
| 117 | P1 | 残留 | 回滚不完整 | `src/cloudflare/deployment.mjs inbound link` | 入站 Telegram 也可能写 botToken，解绑主要围绕网关字段。 | 入站凭证可能在“已解绑”后仍保留部署时值。 |
| 118 | P1 | 残留 | 状态先行 | `src/cloudflare/deployment.mjs::link` | durable record 可先 bound:true，后续才 applyCommitted。 | runtime apply 失败时磁盘仍可能宣称已绑定。 |
| 119 | P1 | 残留 | 状态先行 | `src/cloudflare/deployment.mjs::unbind` | 持久化先清 bound，再做 runtime 收敛。 | apply 失败时 UI/磁盘已显示解绑，旧 runtime 可能仍在使用网关。 |
| 120 | P1 | 残留 | 健康误判 | `src/cloudflare/deployment.mjs` | Telegram Worker 健康主要验证 /healthz 模板/部署标识。 | Worker ready 不代表 Telegram upstream/token/真实投递可用。 |
| 121 | P2 | 残留 | 状态陈旧 | `src/cloudflare/deployment.mjs::status` | 持久化 health:ready 不会因后续 bot token 删除/轮换自动失效。 | 页面可继续显示陈旧健康。 |
| 122 | P1 | 残留 | secret ref陈旧 | `src/cloudflare/deployment.mjs token resolution` | 存在 secretReference 时优先读该引用；引用存在但值缺失可压住其他有效来源。 | 残留 ref 会让部署认为没有 token。 |
| 123 | P2 | 残留 | 本地垃圾 | `src/cloudflare/deployment.mjs` | 部署工作目录长期保留。 | 重复部署/失败会累积模板和 Wrangler 配置。 |
| 124 | P2 | 残留 | 公网面 | `Cloudflare worker config` | 自动部署固定 workers.dev 公网端点。 | 默认创建额外公网攻击面。 |
| 125 | P2 | 残留 | 供应链 | `src/cloudflare/wrangler-runner.mjs::prepare` | 运行时动态 npm install 固定版本 Wrangler，且无 lockfile。 | 结果依赖当时 npm 网络和传递依赖解析。 |
| 126 | P2 | 残留 | 可写目录 | `src/cloudflare/wrangler-runner.mjs` | Wrangler 安装到插件目录 tools。 | 只读/受管插件目录会让功能失败。 |
| 127 | P2 | 残留 | 脆弱解析 | `src/cloudflare/deployment.mjs::loginDevice` | 设备登录依赖 Wrangler CLI 文案/授权 URL 形状。 | CLI 文案或 Cloudflare 登录流程变化会打断自动化。 |
| 128 | P2 | 新发现 | 自动副作用 | `src/cloudflare/deployment.mjs startup recovery` | 宿主启动会自动继续未完成 durable cloud job。 | 旧的不确定云操作可在下次启动继续产生外部副作用。 |
| 129 | P2 | 新发现 | 重复恢复 | `src/cloudflare/deployment.mjs recovery-required` | recovery-required 非终态，可跨重启持续进入恢复链。 | 长期失败作业可能每次启动都被再次处理。 |
| 130 | P1 | 新发现 | 取消失败 | `src/cloudflare/deployment.mjs::cancel` | 先 saveJob 再 controller.abort；saveJob 抛错时 abort 不执行。 | 用户点击取消但外部部署仍继续。 |
| 131 | P2 | 残留 | dispose | `src/cloudflare/deployment.mjs::dispose` | cli/tunnel dispose 没有等待异步完成。 | 插件已 dispose 后外部清理仍可能继续。 |
| 132 | P2 | 残留 | 认证状态 | `src/cloudflare/deployment.mjs` | Cloudflare account/login 投影主要进程内。 | 重启后 deployment record 与当前管理身份状态暂时分裂。 |
| 133 | P2 | 残留 | 账号锁定 | `src/cloudflare/deployment.mjs` | existing deployment 绑定原 accountId。 | Cloudflare 账号所有权变化后旧记录易僵化。 |
| 134 | P2 | 残留 | 资源泄漏/费用 | `src/cloudflare/deployment.mjs` | 失败、解绑、取消都保留已创建 Worker/D1 等资源。 | 反复尝试会积累云资源。 |
| 135 | P1 | 残留 | 状态误报 | `extensions/cloudflare-tunnel/src/supervisor.mjs` | cloudflared 只要触发 spawn 就立即标 running。 | running 只证明进程启动，不证明 tunnel 连通。 |
| 136 | P1 | 残留 | 停止误报 | `extensions/cloudflare-tunnel/src/supervisor.mjs::stop` | drain 超时时先 finishStop(true) 再 SIGKILL。 | 强杀失败也可能已向调用方报告 stopped。 |
| 137 | P2 | 残留 | 错误隐藏 | `extensions/cloudflare-tunnel/src/supervisor.mjs::killProc` | kill 异常全部吞掉。 | 无法确认 cloudflared 是否真正终止。 |
| 138 | P2 | 残留 | 退避历史污染 | `extensions/cloudflare-tunnel/src/supervisor.mjs` | restartCount 成功 spawn 后不清零。 | 历史故障会持续抬高以后重连退避。 |
| 139 | P2 | 残留 | 未处理Promise | `extensions/cloudflare-tunnel/src/supervisor.mjs::scheduleReconnect` | timer 中 void start(lastConfig)，没有 catch。 | 自动重连 start rejection 可能成为未处理 Promise rejection。 |

### G. Provider 层残留与真机证据

| # | 级别 | 状态 | 类型 | 位置 | 当前问题 | 影响 |
|---:|:---:|:---:|---|---|---|---|
| 140 | P1 | 残留 | QQ真机 | `#26 + src/inbound/qq-gw.mjs::postMarkdownWithKeyboard` | QQ markdown+keyboard 仍不携带 msg_id，而普通被动回复支持 msg_id。 | 当前仍没有关闭“正文有、按钮无”的真机证据。 |
| 141 | P1 | 残留 | 能力过宣称 | `src/inbound/qq-gw.mjs` | 仍硬编码 capabilities.buttons=true。 | 上层把未完成真机闭环的 QQ keyboard 当确定能力。 |
| 142 | P2 | 残留 | 截断 | `src/inbound/qq-gw.mjs::postMarkdownWithKeyboard` | 超长 markdown 只取首块，没有显式截断标记。 | 审批/问题上下文会静默丢后半段。 |
| 143 | P2 | 残留 | 连接竞态 | `src/inbound/qq-gw.mjs::connect` | open/message 有 ws===conn guard，但 close handler 没有同等旧连接 guard。 | 旧连接迟到 close 可能触发 cleanup/reconnect 干扰新连接。 |
| 144 | P2 | 残留 | 错误假设 | `src/inbound/qq-gw.mjs` | WebSocket error 处理器假定随后一定 close。 | 不产生预期 close 的异常形态缺直接重连触发。 |
| 145 | P2 | 残留 | 僵尸连接 | `src/inbound/qq-gw.mjs heartbeat` | 心跳 sendFrame 失败不会总是立刻关闭 socket。 | OPEN 但不可写的连接可能更晚才被淘汰。 |
| 146 | P2 | 证据缺口 | 真机 | `docs/developer/memory/risks.md` | QQ HELLO watchdog、mention/media payload、keyboard rendering 仍被列为 provider-level evidence gap。 | 本地契约测试不能替代真实 QQ 客户端。 |
| 147 | P1 | 残留 | 状态误报 | `src/inbound/telegram-bot.mjs::clientState` | running=true 就返回 connected，第一次 getUpdates 尚未成功也一样。 | 持续网络失败期间仍可显示 connected。 |
| 148 | P1 | 残留 | 热循环 | `src/inbound/telegram-bot.mjs::loop` | update 已处理但 offset 落盘失败只 break 内层 for，不进入 catch/backoff。 | 持久化故障时可高频重复拉取/处理同批 update。 |
| 149 | P1 | 残留 | poison update | `src/inbound/telegram-bot.mjs::loop` | 单个 update 持续处理失败会阻止 offset 跨过它。 | 后续消息可能长期被同一坏 update 阻塞/重复带回。 |
| 150 | P2 | 残留 | 限流退避 | `src/inbound/telegram-bot.mjs` | api 解析 429 retry_after，但 poll loop catch 使用固定 backoffMs。 | getUpdates 限流不能按 provider 指定窗口退避。 |
| 151 | P2 | 残留 | 生命周期 | `src/inbound/telegram-bot.mjs::stop` | stop 不 abort 在途 getUpdates，最长等待约 35 秒。 | 热重载/卸载资源释放延迟明显。 |
| 152 | P2 | 残留 | 进程内卡片 | `src/inbound/callback-refs.mjs` | Telegram callback 短引用只保存在内存。 | 重启前已发按钮仍可见，但点击引用已失效。 |
| 153 | P2 | 残留 | 容量 | `src/inbound/callback-refs.mjs` | callback refs 有硬容量上限。 | 高并发审批/问题卡片会提前淘汰或降级。 |
| 154 | P2 | 残留 | 旧卡片放宽 | `src/inbound/feishu-bot.mjs::sourceChatAllowed` | 旧卡片缺 srcChat 时仍明确兼容放行。 | 遗留卡片来源会话校验弱于新卡片。 |
| 155 | P2 | 残留 | 旧卡片放宽 | `src/inbound/feishu-bot.mjs CARD_TTL` | 旧卡片缺 iat 时没有新卡片同等 15 分钟 TTL。 | 遗留卡片交互窗口更长。 |
| 156 | P2 | 残留 | SDK形状假设 | `src/inbound/feishu-bot.mjs::createTimedHttpInstance` | 只检查 base.request，随后无条件调用 get/delete/head/options/post/put/patch。 | SDK 导出形状变化时运行期才失败。 |
| 157 | P2 | 证据缺口 | 真机 | `docs/developer/memory/risks.md` | Feishu P2P payload path 仍是 provider evidence gap。 | operator/open_chat_id 等关键字段未由当前工作树证明真机一致。 |
| 158 | P2 | 残留 | ACK先行 | `src/inbound/dingtalk-stream.mjs::handleFrame` | 业务帧先 ack，再解析/处理 data。 | 二次 parse/业务处理失败后服务端已不会重推。 |
| 159 | P2 | 证据缺口 | 真机 | `docs/developer/memory/risks.md` | DingTalk Stream soak 仍是 provider evidence gap。 | ACK/重连/长时间运行主要由本地契约覆盖。 |
| 160 | P2 | 残留 | 重复副作用 | `src/inbound/dingtalk-stream.mjs::sendReply` | sessionWebhook 异常后立即主动 push；前一次请求若已被接受但响应丢失无法证明没发送。 | 同一回复可能重复出现。 |
| 161 | P2 | 证据缺口 | 安全 | `docs/developer/memory/risks.md` | WxPusher forged-UID provider behavior 仍明确未闭环。 | 身份来源强度缺真实对抗样本。 |
| 162 | P2 | 证据缺口 | 验收 | `docs/developer/v015-final-acceptance.md` | 当前验收明确没有 live Telegram/APNs device 和完整 DSH host。 | Stage 4 本地通过不能当真机/完整宿主闭环。 |

### H. Secondary Surface / dsh-im Bridge

| # | 级别 | 状态 | 类型 | 位置 | 当前问题 | 影响 |
|---:|:---:|:---:|---|---|---|---|
| 163 | P1 | 新发现 | 部分成功误报 | `src/control-surface/secondary-service.mjs::portability.commit` | 配置 commit 后 revision.touch/activity.record 若抛错，外层统一返回失败。 | 用户可能重试已经成功提交的导入。 |
| 164 | P1 | 新发现 | 外部副作用误报 | `src/control-surface/secondary-service.mjs::dshIm.send` | 外部 send 完成后同步 activity.record；activity 抛错会让 RPC 整体失败。 | 消息可能已发送，客户端却重试。 |
| 165 | P2 | 新发现 | 能力探测不足 | `src/control-surface/secondary-service.mjs portability` | 所有 portability 方法只以 exportConfig 存在作为总 gate。 | 部分实现缺其他方法时变成内部错误而非 not-supported。 |
| 166 | P2 | 新发现 | 资源上限 | `src/control-plane/dsh-im-bridge.mjs::listBots` | host 返回 bots 数量没有 cap。 | 异常 service 可制造巨大响应和大量 describe 调用。 |
| 167 | P2 | 新发现 | 资源上限 | `src/control-plane/dsh-im-bridge.mjs::listTargets` | targets 数量也没有 cap。 | 巨大列表直接进入 RPC/浏览器。 |
| 168 | P2 | 新发现 | 延迟放大 | `src/control-plane/dsh-im-bridge.mjs::listBots` | 每个 bot 串行 describeBot，单个调用各有 timeout。 | 大 bot 列表可放大到 N×timeout。 |
| 169 | P2 | 新发现 | 超时后副作用 | `src/control-plane/dsh-im-bridge.mjs::withDeadline` | Promise.race 超时只发 abort signal；host service 若忽略 signal，底层仍继续。 | RPC 已返回 timeout/unknown 后 sendChecked 仍可能稍后真实发送。 |
| 170 | P2 | 新发现 | 字段上限 | `src/control-plane/dsh-im-bridge.mjs projections` | bot/target label、targetId 等字符串没有长度 cap。 | 异常 host service 可把超长文本推向 UI。 |
| 171 | P2 | 证据缺口 | 上游兼容 | `docs/developer/memory/risks.md` | checked v1 bridge 尚未用当前真实 dsh-im host 验证。 | 本仓库模拟契约不能证明当前上游兼容。 |

### I. Recovery Console / Admin Server

| # | 级别 | 状态 | 类型 | 位置 | 当前问题 | 影响 |
|---:|:---:|:---:|---|---|---|---|
| 172 | P2 | 残留 | 额外服务面 | `cordis.patch.yml + src/admin/server.mjs` | Advanced Console 已 read-only，但默认安装仍启动独立 loopback HTTP server。 | 仍有独立 ticket/session/cookie/Origin/Host 生命周期与攻击面。 |
| 173 | P2 | 新发现 | 降级契约 | `src/admin/server.mjs ticket exchange` | session 创建能力缺失时，票据交换存在“accepted 但没有可用 session”的降级形态。 | UI 可看到认证交换成功但 diagnostics 仍不可用。 |
| 174 | P2 | 残留 | 缓存隐私 | `src/admin/server.mjs` | Recovery HTML/diagnostics 没有统一显式 no-store。 | 浏览器或反代可能缓存诊断内容。 |
| 175 | P3 | 残留 | 请求面 | `src/admin/server.mjs` | GET 路由仍走通用 body 读取。 | 本地 server 接受不必要的 GET body。 |
| 176 | P3 | 残留 | Origin范围 | `src/admin/server.mjs` | loopback allowlist 同时接受 http/https origin 变体。 | 实际 transport 外仍多接受一组本地 Origin 组合。 |

### J. CI / 发布门禁 / 文档

| # | 级别 | 状态 | 类型 | 位置 | 当前问题 | 影响 |
|---:|:---:|:---:|---|---|---|---|
| 177 | P1 | 残留 | CI覆盖 | `.github/workflows/ci.yml` | 注释写三平台，matrix 实际只有 Ubuntu/macOS。 | Windows 仍无 CI。 |
| 178 | P1 | 残留 | CI覆盖 | `.github/workflows/ci.yml + package.json` | engines 是 >=22，CI 只跑 Node 22。 | Node 23+ 回归不会被默认 CI 拦截。 |
| 179 | P1 | 残留 | 门禁断裂 | `.github/workflows/ci.yml` | CI 仍不执行 npm run verify:release。 | npm pack、exports、发布边界可在 Actions 全绿时完全没跑。 |
| 180 | P1 | 残留 | 门禁断裂 | `.github/workflows/ci.yml` | CI 也不执行 verify-host-compat。 | 交接里的 host compatibility 是手工证据，不是持续强制门禁。 |
| 181 | P1 | 残留 | 真实依赖缺口 | `.github/workflows/ci.yml` | 根测试不 npm install optionalDependencies。 | 真实 Feishu SDK/qrcode-terminal 安装链不由核心 CI 证明。 |
| 182 | P2 | 残留 | 不可复现 | `test/dom CI` | DOM workspace 使用 npm install --no-package-lock。 | 同一提交不同日期可解析出不同测试依赖。 |
| 183 | P2 | 残留 | 覆盖率 | `.github/workflows/ci.yml` | 没有 coverage threshold。 | 2447 tests 数量不能证明关键跨层路径覆盖。 |
| 184 | P2 | 残留 | 默认测试不完整 | `scripts/run-tests.mjs` | npm test 明确排除 test/dom。 | 本地只跑默认测试不会跑 41 个真实 React DOM 用例。 |
| 185 | P2 | 残留 | 质量计数口径 | `package.json` | dshQuality.testCount=2447 只对应根 Node suite，不含 DOM。 | 单一 testCount 不能代表 CI 实际测试总量。 |
| 186 | P1 | 残留 | 分支治理 | `GitHub dev branch protection` | dev protected，但 required status checks enforcement=off，contexts/checks 为空。 | CI 不是写入 dev 的强制前置条件。 |
| 187 | P2 | 残留 | 来源完整性 | `GitHub dev HEAD` | 当前 HEAD commit 为 unsigned。 | 没有提交签名这一层来源证明。 |
| 188 | P2 | 残留 | 版本识别 | `package.json` | dev 已是大规模 v0.15 工作，但 package version 仍 0.13.1。 | 直接打包/本地安装 dev 的版本诊断会带稳定版旧号。 |
| 189 | P2 | 新发现 | manifest重复 | `package.json::files` | docs/user/README.md 在 files 数组出现两次。 | 发布清单已经出现维护漂移。 |
| 190 | P2 | 残留 | 公开兼容面 | `package.json::exports` | 仍公开 ./internal -> ./src/index.mjs。 | 外部消费者可依赖内部实现，形成事实兼容负担。 |
| 191 | P2 | 残留 | 公开兼容面 | `package.json::exports` | ./testing 仍是正式 exports。 | 测试 helper 也成为外部可依赖 surface。 |
| 192 | P2 | 残留 | 元数据证据 | `package.json::dshWorkshop.evidence` | install/failureIsolation/hotReload/remove 全部为 null。 | lifecycle 宣称与机器可读 evidence 未闭环。 |
| 193 | P1 | 新发现 | 门禁语义 | `scripts/run-tests.mjs --count` | --count 只取测试总数，不以测试失败作为退出依据。 | 单独 verify:release 不能证明测试通过，只能证明计数相等。 |
| 194 | P1 | 新发现 | 门禁组合 | `CI + verify-release` | CI 跑测试但不跑 release guard；release guard 算数量但不要求测试成功。 | 两套门禁只有人工按正确顺序运行时才形成完整闭环。 |
| 195 | P2 | 文档漂移 | 技术事实 | `docs/developer/state-writer-registry.md` | Deferrals 仍写 pairing mint/revoke 为旧 read-modify-write；当前 pairing 已事务化。 | writer registry 对当前代码事实过期。 |
| 196 | P1 | 新发现 | 文档损坏 | `docs/developer/state-writer-registry.md writer-fitness` | src/routing/task-selection.mjs 行后混入 Cloud deployment 表格字段，Markdown 行结构损坏。 | 机器/人工读取 allowlist 会得到错误 authority 记录。 |
| 197 | P2 | 文档漂移 | 自相矛盾 | `docs/developer/state-writer-registry.md` | 正文说所有 multi-owner keys 已 converged，同时又保留 pairing deferral pending。 | 同一文档不能作为一致的收口状态摘要。 |
| 198 | P2 | 证据缺口 | 验收 | `docs/developer/v015-final-acceptance.md` | P5 明确没有 live Cloudflare、Telegram/APNs device 或完整 DSH host。 | 当前 dev 不能视为真实环境全闭环。 |
| 199 | P2 | 证据缺口 | 视觉 | `docs/developer/memory/risks.md` | Native v2 仍缺真实 DSH host dark/light/mobile walkthrough。 | fixture React 截图不等价真实宿主视觉验收。 |
| 200 | P2 | 证据缺口 | 宿主事件 | `docs/developer/memory/risks.md` | Host scoped error delivery 仍有 outstanding real-host regression。 | 宿主事件作用域关键行为仍缺真实回归。 |
| 201 | P2 | 证据缺口 | 兼容 | `docs/developer/memory/risks.md` | optional peer range 的 in-range/out-of-range real boot preflight 仍窄于源码兼容检查。 | 声明兼容的宿主版本未逐一真实 boot 闭环。 |

## 已明确不再重复计入的旧问题

- Advanced Console 仍承担日常 Members / Sessions / Bindings / Pairing 写操作：当前已收口为 Recovery read-only。
- Recovery server 可被 caller 改成 `0.0.0.0`：当前已硬编码 loopback。
- RuntimeChannelManager 每一次 starting/online 都推进 epoch：当前已修。
- current-task 不区分 accountId / 无选择自动挑最近会话：主路径已修。
- Cloud deployment record 直接保存 botToken/gatewayKey：当前已改 secretReference/fingerprint。
- pairing mint/revoke 旧锁外 read-modify-write：代码已修，本轮只保留文档漂移。
- dsh-im guessed importer / 普通 send fallback：当前已删除。

## 审查边界

依据当前 dev 源码、`c890d2c...dev` 16 提交差异、HANDOFF / acceptance / risks / writer registry、最新 Actions 与 branch protection 状态。没有把 fixture/mock 当真机证据；仓库 acceptance 自己也明确没有 live Cloudflare、Telegram/APNs device 与完整 DSH host，因此这些按“证据缺口”记录。
